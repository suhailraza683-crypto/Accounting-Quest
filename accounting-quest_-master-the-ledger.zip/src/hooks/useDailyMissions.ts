import { useState, useEffect, useCallback } from 'react';
import { DailyMission, DailyMissionsData, MissionType } from '../types.ts';

const MISSIONS_STORAGE_KEY = 'accounting_quest_daily_missions_v1';

function getTodayString(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

const DEFAULT_MISSIONS_TEMPLATE: Omit<DailyMission, 'current' | 'completed' | 'claimed'>[] = [
  {
    id: 'm_answer_5',
    type: 'answer_count',
    title: 'Daily Practice Routine',
    description: 'Answer 5 accounting questions correctly in any game mode.',
    target: 5,
    xpReward: 150,
    icon: '📝',
  },
  {
    id: 'm_streak_5',
    type: 'streak_target',
    title: 'Double-Entry Precision',
    description: 'Achieve a continuous answer streak of 5 correct answers.',
    target: 5,
    xpReward: 200,
    icon: '🔥',
  },
  {
    id: 'm_journal_sim',
    type: 'play_level2',
    title: 'Voucher & Journal Master',
    description: 'Complete and verify 2 transactions in the Level 2 Journal Simulator.',
    target: 2,
    xpReward: 220,
    icon: '📑',
  },
  {
    id: 'm_adjustment_calc',
    type: 'play_level3',
    title: 'Final Accounts Adjuster',
    description: 'Successfully solve a year-end adjustment in Level 3.',
    target: 1,
    xpReward: 250,
    icon: '⚖️',
  },
  {
    id: 'm_boss_defeat',
    type: 'boss_defeat',
    title: 'Audit Showdown Champion',
    description: 'Defeat the Chief Statutory Auditor in Level 4 Time-Attack.',
    target: 1,
    xpReward: 400,
    icon: '👑',
  },
];

function generateFreshMissions(): DailyMission[] {
  return DEFAULT_MISSIONS_TEMPLATE.map((template) => ({
    ...template,
    current: 0,
    completed: false,
    claimed: false,
  }));
}

export function useDailyMissions(
  onRewardEarned: (xp: number, missionTitle?: string) => void,
  onMissionCompleted?: (mission: DailyMission) => void
) {
  const [missionsData, setMissionsData] = useState<DailyMissionsData>(() => {
    const today = getTodayString();
    try {
      const saved = localStorage.getItem(MISSIONS_STORAGE_KEY);
      if (saved) {
        const parsed: DailyMissionsData = JSON.parse(saved);
        if (parsed.lastUpdatedDate === today && Array.isArray(parsed.missions) && parsed.missions.length > 0) {
          return parsed;
        }
      }
    } catch {
      // fallback
    }
    return {
      lastUpdatedDate: today,
      missions: generateFreshMissions(),
    };
  });

  // Check for day rollover
  useEffect(() => {
    const today = getTodayString();
    if (missionsData.lastUpdatedDate !== today) {
      const refreshed: DailyMissionsData = {
        lastUpdatedDate: today,
        missions: generateFreshMissions(),
      };
      setMissionsData(refreshed);
      try {
        localStorage.setItem(MISSIONS_STORAGE_KEY, JSON.stringify(refreshed));
      } catch {
        // ignore
      }
    }
  }, [missionsData.lastUpdatedDate]);

  // Save changes
  useEffect(() => {
    try {
      localStorage.setItem(MISSIONS_STORAGE_KEY, JSON.stringify(missionsData));
    } catch {
      // ignore
    }
  }, [missionsData]);

  // Track mission progress helper
  const updateProgress = useCallback(
    (type: MissionType, amount = 1, isAbsoluteStreak = false) => {
      setMissionsData((prev) => {
        let changed = false;
        const justCompleted: DailyMission[] = [];

        const nextMissions = prev.missions.map((m) => {
          if (m.type !== type || m.completed) return m;

          let newCurrent = isAbsoluteStreak ? Math.max(m.current, amount) : m.current + amount;
          if (newCurrent > m.target) newCurrent = m.target;

          const completed = newCurrent >= m.target;
          if (newCurrent !== m.current || completed !== m.completed) {
            changed = true;
            const updated = {
              ...m,
              current: newCurrent,
              completed,
            };
            if (!m.completed && completed) {
              justCompleted.push(updated);
            }
            return updated;
          }
          return m;
        });

        if (!changed) return prev;

        if (justCompleted.length > 0 && onMissionCompleted) {
          justCompleted.forEach((m) => onMissionCompleted(m));
        }

        return {
          ...prev,
          missions: nextMissions,
        };
      });
    },
    [onMissionCompleted]
  );

  const claimReward = useCallback(
    (missionId: string) => {
      setMissionsData((prev) => {
        const targetMission = prev.missions.find((m) => m.id === missionId);
        if (!targetMission || !targetMission.completed || targetMission.claimed) {
          return prev;
        }

        onRewardEarned(targetMission.xpReward, targetMission.title);

        return {
          ...prev,
          missions: prev.missions.map((m) =>
            m.id === missionId ? { ...m, claimed: true } : m
          ),
        };
      });
    },
    [onRewardEarned]
  );

  const claimAllRewards = useCallback(() => {
    setMissionsData((prev) => {
      let totalXp = 0;
      const updated = prev.missions.map((m) => {
        if (m.completed && !m.claimed) {
          totalXp += m.xpReward;
          return { ...m, claimed: true };
        }
        return m;
      });

      if (totalXp > 0) {
        onRewardEarned(totalXp, 'All Completed Missions');
        return {
          ...prev,
          missions: updated,
        };
      }
      return prev;
    });
  }, [onRewardEarned]);

  const completedCount = missionsData.missions.filter((m) => m.completed).length;
  const unclaimedCount = missionsData.missions.filter((m) => m.completed && !m.claimed).length;

  return {
    missions: missionsData.missions,
    completedCount,
    unclaimedCount,
    totalCount: missionsData.missions.length,
    claimReward,
    claimAllRewards,
    updateProgress,
  };
}
