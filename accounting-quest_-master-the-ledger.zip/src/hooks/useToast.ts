import { useState, useCallback, useRef } from 'react';
import { ToastItem, FloatingXpItem, DailyMission, ToastType } from '../types.ts';

const MAX_TOASTS = 4;
const FLOATING_XP_DURATION = 2200; // ms to match floatUpAndFade animation
const DEFAULT_TOAST_DURATION = 4000; // ms

export function useToast() {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [floatingXps, setFloatingXps] = useState<FloatingXpItem[]>([]);
  const timerMapRef = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
    const timer = timerMapRef.current.get(id);
    if (timer) {
      clearTimeout(timer);
      timerMapRef.current.delete(id);
    }
  }, []);

  const addToast = useCallback(
    (toast: {
      type: ToastType;
      title: string;
      message?: string;
      xpAmount?: number;
      streak?: number;
      multiplier?: number;
      icon?: string;
      durationMs?: number;
    }) => {
      const id = 'toast_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      const durationMs = toast.durationMs ?? DEFAULT_TOAST_DURATION;

      const newToast: ToastItem = {
        id,
        type: toast.type,
        title: toast.title,
        message: toast.message,
        xpAmount: toast.xpAmount,
        streak: toast.streak,
        multiplier: toast.multiplier,
        icon: toast.icon,
        timestamp: Date.now(),
        durationMs,
      };

      setToasts((prev) => {
        // Keep list bounded
        const updated = [newToast, ...prev];
        if (updated.length > MAX_TOASTS) {
          const removed = updated.slice(MAX_TOASTS);
          removed.forEach((item) => {
            const timer = timerMapRef.current.get(item.id);
            if (timer) {
              clearTimeout(timer);
              timerMapRef.current.delete(item.id);
            }
          });
          return updated.slice(0, MAX_TOASTS);
        }
        return updated;
      });

      // Schedule auto-dismiss
      const timer = setTimeout(() => {
        removeToast(id);
      }, durationMs);

      timerMapRef.current.set(id, timer);
      return id;
    },
    [removeToast]
  );

  // Trigger floating XP overlay and XP gain toast
  const triggerXpGain = useCallback(
    (amount: number, reason = 'XP Gained', multiplier = 1, streak = 0) => {
      if (amount <= 0) return;

      const floatId = 'float_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      const newFloatingItem: FloatingXpItem = {
        id: floatId,
        amount,
        multiplier,
        streak,
        label: reason,
        timestamp: Date.now(),
      };

      // Add to floating XP animation queue
      setFloatingXps((prev) => [...prev.slice(-3), newFloatingItem]);

      // Remove after animation completes
      setTimeout(() => {
        setFloatingXps((prev) => prev.filter((item) => item.id !== floatId));
      }, FLOATING_XP_DURATION);

      // Add corresponding toast notification
      const streakText = multiplier > 1 ? ` • ${multiplier.toFixed(1)}x Streak Multiplier` : '';
      addToast({
        type: 'xp_gain',
        title: `+${amount} XP Earned`,
        message: `${reason}${streakText}`,
        xpAmount: amount,
        multiplier,
        streak,
        icon: '✨',
        durationMs: 3500,
      });
    },
    [addToast]
  );

  // Trigger mission completed notification
  const triggerMissionCompleted = useCallback(
    (mission: DailyMission) => {
      addToast({
        type: 'mission_completed',
        title: 'Daily Mission Completed!',
        message: `${mission.title} (+${mission.xpReward} XP Ready to Claim)`,
        xpAmount: mission.xpReward,
        icon: mission.icon || '🎯',
        durationMs: 5000,
      });
    },
    [addToast]
  );

  const clearAll = useCallback(() => {
    timerMapRef.current.forEach((timer) => clearTimeout(timer));
    timerMapRef.current.clear();
    setToasts([]);
    setFloatingXps([]);
  }, []);

  return {
    toasts,
    floatingXps,
    addToast,
    removeToast,
    triggerXpGain,
    triggerMissionCompleted,
    clearAll,
  };
}
