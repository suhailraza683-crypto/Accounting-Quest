import { useState, useEffect, useCallback, useRef } from 'react';
import { PlayerStats, RankTier, XpGainEvent } from '../types.ts';

const STORAGE_KEY = 'accounting_quest_save_v1';

function getTodayDateString(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function getYesterdayDateString(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

const todayStr = getTodayDateString();

const defaultStats: PlayerStats = {
  xp: 0,
  score: 0,
  currentStreak: 0,
  highestStreak: 0,
  totalAnswered: 0,
  totalCorrect: 0,
  levelHighScores: {
    level1: 0,
    level2: 0,
    level3: 0,
    level4: 0,
  },
  completedChapters: [],
  bossesDefeated: 0,
  unlockedBadges: [],
  loginStreak: 1,
  lastLoginDate: todayStr,
  loginHistory: [todayStr],
};

export function getRankTier(xp: number): { tier: RankTier; nextXp: number; progress: number; badgeColor: string } {
  if (xp >= 8000) {
    return { tier: 'Master of the Ledger', nextXp: 8000, progress: 100, badgeColor: 'from-amber-400 to-yellow-500' };
  }
  if (xp >= 5000) {
    const progress = Math.min(100, Math.round(((xp - 5000) / 3000) * 100));
    return { tier: 'Chief Financial Officer', nextXp: 8000, progress, badgeColor: 'from-purple-500 to-indigo-600' };
  }
  if (xp >= 3000) {
    const progress = Math.min(100, Math.round(((xp - 3000) / 2000) * 100));
    return { tier: 'Financial Controller', nextXp: 5000, progress, badgeColor: 'from-cyan-500 to-blue-600' };
  }
  if (xp >= 1500) {
    const progress = Math.min(100, Math.round(((xp - 1500) / 1500) * 100));
    return { tier: 'Senior Accountant', nextXp: 3000, progress, badgeColor: 'from-emerald-500 to-teal-600' };
  }
  if (xp >= 500) {
    const progress = Math.min(100, Math.round(((xp - 500) / 1000) * 100));
    return { tier: 'Junior Bookkeeper', nextXp: 1500, progress, badgeColor: 'from-blue-400 to-cyan-500' };
  }
  const progress = Math.min(100, Math.round((xp / 500) * 100));
  return { tier: 'Accounting Intern', nextXp: 500, progress, badgeColor: 'from-slate-400 to-slate-500' };
}

export function getStreakMultiplier(streak: number): number {
  if (streak >= 10) return 5.0;
  if (streak >= 7) return 3.0;
  if (streak >= 5) return 2.0;
  if (streak >= 3) return 1.5;
  return 1.0;
}

export function useGameState(
  onXpGained?: (event: XpGainEvent) => void,
  onRankUp?: (newRank: RankTier) => void,
  onBadgeUnlocked?: (badgeId: string, name: string, icon: string) => void
) {
  const [stats, setStats] = useState<PlayerStats>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...defaultStats,
          ...parsed,
          loginStreak: typeof parsed.loginStreak === 'number' ? parsed.loginStreak : 1,
          lastLoginDate: parsed.lastLoginDate || todayStr,
          loginHistory: Array.isArray(parsed.loginHistory) && parsed.loginHistory.length > 0 ? parsed.loginHistory : [todayStr],
        };
      }
    } catch {
      // ignore
    }
    return defaultStats;
  });

  const hasCheckedStreakRef = useRef(false);

  // Check login consistency on mount
  useEffect(() => {
    if (hasCheckedStreakRef.current) return;
    hasCheckedStreakRef.current = true;

    setStats((prev) => {
      const currentToday = getTodayDateString();
      const currentYesterday = getYesterdayDateString();

      if (prev.lastLoginDate === currentToday) {
        // Already logged in today
        return prev;
      }

      let updatedStreak = prev.loginStreak || 1;
      if (prev.lastLoginDate === currentYesterday) {
        // Consecutive day!
        updatedStreak += 1;
      } else {
        // Broken streak, restart at 1
        updatedStreak = 1;
      }

      const updatedHistory = Array.from(new Set([...(prev.loginHistory || []), currentToday]));
      const newBadges = [...(prev.unlockedBadges || [])];

      if (updatedStreak >= 7 && !newBadges.includes('consistency_badge')) {
        newBadges.push('consistency_badge');
        if (onBadgeUnlocked) {
          onBadgeUnlocked('consistency_badge', 'Consistency Badge', '🗓️');
        }
        if (onXpGained) {
          onXpGained({
            amount: 250,
            reason: '7-Day Streak Consistency Badge Awarded!',
          });
        }
      }

      return {
        ...prev,
        loginStreak: updatedStreak,
        lastLoginDate: currentToday,
        loginHistory: updatedHistory,
        unlockedBadges: newBadges,
      };
    });
  }, [onBadgeUnlocked, onXpGained]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
    } catch {
      // ignore
    }
  }, [stats]);

  const checkRankPromotion = useCallback((oldXp: number, newXp: number) => {
    if (!onRankUp) return;
    const oldTier = getRankTier(oldXp).tier;
    const newTier = getRankTier(newXp).tier;
    if (oldTier !== newTier) {
      onRankUp(newTier);
    }
  }, [onRankUp]);

  const recordAnswer = useCallback((isCorrect: boolean, baseScore = 100, baseExp = 25) => {
    setStats((prev) => {
      if (isCorrect) {
        const nextStreak = prev.currentStreak + 1;
        const multiplier = getStreakMultiplier(nextStreak);
        const earnedScore = Math.round(baseScore * multiplier);
        const earnedXp = Math.round(baseExp * multiplier);
        const highestStreak = Math.max(prev.highestStreak, nextStreak);
        const newXp = prev.xp + earnedXp;

        const newBadges = [...prev.unlockedBadges];
        if (nextStreak >= 5 && !newBadges.includes('streak_5')) {
          newBadges.push('streak_5');
          if (onBadgeUnlocked) onBadgeUnlocked('streak_5', 'Hot Streak', '🔥');
        }
        if (nextStreak >= 10 && !newBadges.includes('streak_10')) {
          newBadges.push('streak_10');
          if (onBadgeUnlocked) onBadgeUnlocked('streak_10', 'Ledger Mastermind', '⚡');
        }
        if (newXp >= 1500 && !newBadges.includes('rank_senior')) {
          newBadges.push('rank_senior');
        }
        if (newXp >= 5000 && !newBadges.includes('rank_cfo')) {
          newBadges.push('rank_cfo');
        }

        if (onXpGained && earnedXp > 0) {
          onXpGained({
            amount: earnedXp,
            reason: multiplier > 1 ? `Correct Entry • Streak ${nextStreak}!` : 'Correct Accounting Entry',
            streak: nextStreak,
            multiplier,
          });
        }

        checkRankPromotion(prev.xp, newXp);

        return {
          ...prev,
          xp: newXp,
          score: prev.score + earnedScore,
          currentStreak: nextStreak,
          highestStreak,
          totalAnswered: prev.totalAnswered + 1,
          totalCorrect: prev.totalCorrect + 1,
          unlockedBadges: newBadges,
        };
      } else {
        return {
          ...prev,
          currentStreak: 0,
          totalAnswered: prev.totalAnswered + 1,
        };
      }
    });
  }, [onXpGained, onBadgeUnlocked, checkRankPromotion]);

  const updateHighScore = useCallback((level: 'level1' | 'level2' | 'level3' | 'level4', score: number) => {
    setStats((prev) => ({
      ...prev,
      levelHighScores: {
        ...prev.levelHighScores,
        [level]: Math.max(prev.levelHighScores[level] || 0, score),
      },
    }));
  }, []);

  const markChapterCompleted = useCallback((chapterId: number) => {
    setStats((prev) => {
      if (!prev.completedChapters.includes(chapterId)) {
        return {
          ...prev,
          completedChapters: [...prev.completedChapters, chapterId],
        };
      }
      return prev;
    });
  }, []);

  const recordBossDefeated = useCallback(() => {
    setStats((prev) => {
      const newBadges = [...prev.unlockedBadges];
      if (!newBadges.includes('boss_slayer')) {
        newBadges.push('boss_slayer');
        if (onBadgeUnlocked) onBadgeUnlocked('boss_slayer', 'Audit Conqueror', '🛡️');
      }
      const newXp = prev.xp + 500;

      if (onXpGained) {
        onXpGained({
          amount: 500,
          reason: 'Auditor Boss Defeated!',
        });
      }

      checkRankPromotion(prev.xp, newXp);

      return {
        ...prev,
        bossesDefeated: prev.bossesDefeated + 1,
        xp: newXp,
        score: prev.score + 2500,
        unlockedBadges: newBadges,
      };
    });
  }, [onXpGained, onBadgeUnlocked, checkRankPromotion]);

  const addXp = useCallback((xpGain: number, scoreGain = 0, reason = 'Bonus XP') => {
    setStats((prev) => {
      const newXp = prev.xp + xpGain;
      const newBadges = [...prev.unlockedBadges];
      if (newXp >= 1500 && !newBadges.includes('rank_senior')) newBadges.push('rank_senior');
      if (newXp >= 5000 && !newBadges.includes('rank_cfo')) newBadges.push('rank_cfo');

      if (onXpGained && xpGain > 0) {
        onXpGained({
          amount: xpGain,
          reason,
        });
      }

      checkRankPromotion(prev.xp, newXp);

      return {
        ...prev,
        xp: newXp,
        score: prev.score + scoreGain,
        unlockedBadges: newBadges,
      };
    });
  }, [onXpGained, checkRankPromotion]);

  // Advance simulation by 1 day (e.g. for testing & verifying the 7-day streak and Consistency Badge award)
  const advanceSimulationDay = useCallback(() => {
    setStats((prev) => {
      const nextStreak = (prev.loginStreak || 0) + 1;
      const fakeDate = new Date();
      fakeDate.setDate(fakeDate.getDate() + nextStreak);
      const fakeDateStr = fakeDate.toISOString().split('T')[0];

      const newBadges = [...prev.unlockedBadges];
      const newlyHitSeven = nextStreak >= 7 && !newBadges.includes('consistency_badge');

      if (newlyHitSeven) {
        newBadges.push('consistency_badge');
        if (onBadgeUnlocked) {
          onBadgeUnlocked('consistency_badge', 'Consistency Badge', '🗓️');
        }
      }

      const streakBonusXp = newlyHitSeven ? 250 : 35;
      const newXp = prev.xp + streakBonusXp;

      if (onXpGained) {
        onXpGained({
          amount: streakBonusXp,
          reason: newlyHitSeven 
            ? '🏆 7-Day Consistency Badge Unlocked!' 
            : `Day ${nextStreak} Check-in Streak!`,
        });
      }

      checkRankPromotion(prev.xp, newXp);

      return {
        ...prev,
        loginStreak: nextStreak,
        lastLoginDate: fakeDateStr,
        loginHistory: [...(prev.loginHistory || []), fakeDateStr],
        unlockedBadges: newBadges,
        xp: newXp,
      };
    });
  }, [onBadgeUnlocked, onXpGained, checkRankPromotion]);

  // Claim today's daily streak bonus
  const claimDailyCheckIn = useCallback(() => {
    setStats((prev) => {
      const streakCount = prev.loginStreak || 1;
      const bonus = Math.min(streakCount * 25, 200);
      const newXp = prev.xp + bonus;

      if (onXpGained) {
        onXpGained({
          amount: bonus,
          reason: `Daily Streak Check-In (${streakCount} Day Streak!)`,
        });
      }

      checkRankPromotion(prev.xp, newXp);

      return {
        ...prev,
        xp: newXp,
      };
    });
  }, [onXpGained, checkRankPromotion]);

  const resetProgress = useCallback(() => {
    setStats(defaultStats);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
  }, []);

  const rankInfo = getRankTier(stats.xp);
  const currentMultiplier = getStreakMultiplier(stats.currentStreak);

  return {
    stats,
    rankInfo,
    currentMultiplier,
    recordAnswer,
    updateHighScore,
    markChapterCompleted,
    recordBossDefeated,
    addXp,
    resetProgress,
    advanceSimulationDay,
    claimDailyCheckIn,
  };
}
