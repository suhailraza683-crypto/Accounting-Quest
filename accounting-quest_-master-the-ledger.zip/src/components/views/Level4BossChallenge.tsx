import React, { useState, useEffect, useMemo, useRef } from 'react';
import { BossQuestion } from '../../types.ts';
import { BOSS_QUESTIONS, CHAPTERS } from '../../data.ts';
import { 
  ArrowLeft, 
  Flame, 
  Swords, 
  Shield, 
  Timer, 
  Award, 
  Trophy, 
  RotateCcw, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  Zap,
  BookMarked
} from 'lucide-react';

interface Level4BossChallengeProps {
  selectedChapterIds: number[];
  onReturnHome: () => void;
  recordAnswer: (isCorrect: boolean, baseScore?: number, baseExp?: number) => void;
  updateHighScore: (level: 'level4', score: number) => void;
  recordBossDefeated: () => void;
  currentStreak: number;
  currentMultiplier: number;
  sound: {
    playCorrect: () => void;
    playWrong: () => void;
    playCombo: () => void;
    playClick: () => void;
    playBossHit: () => void;
    playVictory: () => void;
  };
  onOpenGlossary?: (termQuery?: string) => void;
}

export const Level4BossChallenge: React.FC<Level4BossChallengeProps> = ({
  selectedChapterIds,
  onReturnHome,
  recordAnswer,
  updateHighScore,
  recordBossDefeated,
  currentStreak,
  currentMultiplier,
  sound,
  onOpenGlossary,
}) => {
  // Questions pool
  const questions: BossQuestion[] = useMemo(() => {
    const filtered = BOSS_QUESTIONS.filter((q) => selectedChapterIds.includes(q.chapterId));
    return filtered.length > 0 ? filtered : BOSS_QUESTIONS;
  }, [selectedChapterIds]);

  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [bossHp, setBossHp] = useState<number>(100);
  const [playerShields, setPlayerShields] = useState<number>(3);
  const [gameState, setGameState] = useState<'playing' | 'victory' | 'defeat'>('playing');
  const [bossScore, setBossScore] = useState<number>(0);

  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [timeLeft, setTimeLeft] = useState<number>(15);
  const [bossHitEffect, setBossHitEffect] = useState<boolean>(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const currentQ = questions[currentIndex % questions.length];
  const currentChapter = CHAPTERS.find((c) => c.id === currentQ.chapterId);

  // Timer countdown
  useEffect(() => {
    if (gameState !== 'playing' || isAnswered) return;

    setTimeLeft(currentQ.timeLimitSec);

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          handleTimeout();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [currentIndex, gameState, isAnswered]);

  const handleTimeout = () => {
    sound.playWrong();
    setIsAnswered(true);
    recordAnswer(false);

    setPlayerShields((prev) => {
      const next = prev - 1;
      if (next <= 0) {
        setGameState('defeat');
      }
      return next;
    });
  };

  const handleSelectOption = (idx: number) => {
    if (isAnswered || gameState !== 'playing') return;
    if (timerRef.current) clearInterval(timerRef.current);

    sound.playClick();
    setSelectedOption(idx);
    setIsAnswered(true);

    const isCorrect = idx === currentQ.correctIndex;

    if (isCorrect) {
      sound.playCorrect();
      sound.playBossHit();
      setBossHitEffect(true);
      setTimeout(() => setBossHitEffect(false), 600);

      const earned = Math.round(400 * currentMultiplier);
      setBossScore((prev) => {
        const next = prev + earned;
        updateHighScore('level4', next);
        return next;
      });

      recordAnswer(true, 400, 60);

      setBossHp((prev) => {
        const next = Math.max(0, prev - currentQ.bossDamage);
        if (next === 0) {
          sound.playVictory();
          setGameState('victory');
          recordBossDefeated();
        }
        return next;
      });
    } else {
      sound.playWrong();
      recordAnswer(false);

      setPlayerShields((prev) => {
        const next = prev - 1;
        if (next <= 0) {
          setGameState('defeat');
        }
        return next;
      });
    }
  };

  const handleNext = () => {
    sound.playClick();
    setSelectedOption(null);
    setIsAnswered(false);
    setCurrentIndex((prev) => prev + 1);
  };

  const restartBattle = () => {
    sound.playClick();
    setBossHp(100);
    setPlayerShields(3);
    setBossScore(0);
    setGameState('playing');
    setSelectedOption(null);
    setIsAnswered(false);
    setCurrentIndex(0);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b-2 border-slate-200">
        <button
          onClick={onReturnHome}
          className="btn-tactile flex items-center gap-1.5 px-3.5 py-1.5 rounded-2xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold border-2 border-slate-200 border-b-4 border-b-slate-300 active:border-b-2 transition-all shadow-xs"
        >
          <ArrowLeft className="w-4 h-4 text-rose-600" />
          <span>Exit Arena</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 rounded-2xl text-xs font-black bg-rose-100 text-rose-800 border border-rose-200 flex items-center gap-1.5 shadow-xs">
            <Swords className="w-4 h-4 text-rose-600" />
            <span>Boss Battle: The Statutory Auditor</span>
          </span>
        </div>

        <div className="flex items-center gap-3 text-xs font-bold">
          {onOpenGlossary && (
            <button
              onClick={() => onOpenGlossary()}
              className="btn-tactile flex items-center gap-1 px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border-2 border-indigo-200 border-b-4 border-b-indigo-300 active:border-b-2 transition-all shadow-xs"
              title="Open Glossary & Reference"
            >
              <BookMarked className="w-3.5 h-3.5 text-indigo-600" />
              <span className="hidden sm:inline">Glossary</span>
            </button>
          )}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border-2 border-slate-200 text-slate-700 shadow-xs">
            <Award className="w-4 h-4 text-rose-500" />
            <span className="text-slate-500 font-semibold">Score:</span>
            <span className="font-black text-slate-900">{bossScore}</span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 border-2 border-amber-200 text-amber-900 shadow-xs">
            <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span className="text-amber-700 font-semibold">Streak:</span>
            <span className="font-black text-amber-900">{currentStreak}</span>
          </div>
        </div>
      </div>

      {/* BOSS & PLAYER STATUS BARS */}
      <div className="grid sm:grid-cols-2 gap-4">
        {/* Boss Panel */}
        <div className={`relative p-5 rounded-2xl border-2 transition-all duration-300 bg-white ${
          bossHitEffect 
            ? 'border-rose-500 ring-4 ring-rose-300 bg-rose-50/70 translate-x-1 animate-shake-wrong' 
            : 'border-rose-100 shadow-[0_8px_24px_-4px_rgba(244,63,94,0.12)]'
        }`}>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2.5">
              <span className="text-3xl p-1.5 rounded-xl bg-rose-50 border border-rose-200 shadow-xs">👨‍💼</span>
              <div>
                <h4 className="text-xs font-black text-rose-700 tracking-wide uppercase">
                  Chief Statutory Auditor
                </h4>
                <span className="text-[11px] text-slate-500 font-medium">Strict NCERT Ledger Enforcer</span>
              </div>
            </div>
            <span className="text-xs font-mono font-black text-rose-600">{bossHp} / 100 HP</span>
          </div>

          <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden p-0.5 border border-slate-200">
            <div 
              className="h-full bg-gradient-to-r from-amber-400 via-rose-500 to-red-600 rounded-full transition-all duration-300"
              style={{ width: `${bossHp}%` }}
            />
          </div>
        </div>

        {/* Player Health & Timer Panel */}
        <div className="p-5 rounded-2xl bg-white border-2 border-indigo-100 shadow-[0_8px_24px_-4px_rgba(99,102,241,0.12)] flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-black text-slate-600 block uppercase tracking-wider">
              Player Shields (Lives):
            </span>
            <div className="flex items-center gap-2">
              {[1, 2, 3].map((shieldNum) => (
                <Shield
                  key={shieldNum}
                  className={`w-7 h-7 transition-all ${
                    shieldNum <= playerShields
                      ? 'text-indigo-600 fill-indigo-100'
                      : 'text-slate-200 opacity-40'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Time Attack Clock */}
          <div className="text-right">
            <span className="text-xs font-black text-slate-500 flex items-center gap-1 justify-end">
              <Timer className="w-3.5 h-3.5 text-amber-500" />
              Time Remaining:
            </span>
            <div className={`text-2xl font-black font-mono transition-colors ${
              timeLeft <= 5 ? 'text-rose-600 animate-pulse scale-110' : 'text-slate-900'
            }`}>
              {timeLeft}s
            </div>
          </div>
        </div>
      </div>

      {/* GAME OVER: VICTORY SCREEN */}
      {gameState === 'victory' && (
        <div className="card-bouncy p-8 sm:p-10 rounded-[28px] bg-white border-2 border-emerald-300 shadow-[0_16px_40px_-8px_rgba(16,185,129,0.2)] text-center space-y-4 animate-fadeIn">
          <div className="w-16 h-16 rounded-3xl bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center text-3xl shadow-sm border border-emerald-200">
            👑
          </div>
          <h3 className="text-2xl sm:text-3xl font-black text-slate-900">
            Auditor Defeated! Ledger Balanced! 🎉
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto font-medium">
            Your accounting mastery passed every verification! The Chief Auditor signed off without a single qualified remark.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 py-2 font-bold">
            <div className="px-5 py-2.5 rounded-2xl bg-slate-50 border-2 border-slate-200 text-xs">
              <span className="text-slate-500 block text-[11px]">Final Arena Score</span>
              <span className="text-base font-black text-amber-700">{bossScore} pts</span>
            </div>
            <div className="px-5 py-2.5 rounded-2xl bg-indigo-50 border-2 border-indigo-200 text-xs">
              <span className="text-indigo-600 block text-[11px]">Bonus Awarded</span>
              <span className="text-base font-black text-indigo-800">+500 XP</span>
            </div>
          </div>
          <div className="pt-2 flex justify-center gap-3">
            <button
              onClick={restartBattle}
              className="btn-tactile px-5 py-2.5 rounded-2xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-black border-2 border-slate-200 border-b-4 border-b-slate-300 active:border-b-2 transition-all flex items-center gap-1.5 shadow-xs"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Fight Again</span>
            </button>
            <button
              onClick={onReturnHome}
              className="btn-tactile px-6 py-2.5 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-black border-b-4 border-emerald-700 active:border-b-0 transition-all shadow-sm"
            >
              Return to Menu
            </button>
          </div>
        </div>
      )}

      {/* GAME OVER: DEFEAT SCREEN */}
      {gameState === 'defeat' && (
        <div className="card-bouncy p-8 sm:p-10 rounded-[28px] bg-white border-2 border-rose-300 shadow-[0_16px_40px_-8px_rgba(244,63,94,0.18)] text-center space-y-4 animate-fadeIn">
          <div className="w-16 h-16 rounded-3xl bg-rose-100 text-rose-600 mx-auto flex items-center justify-center text-3xl shadow-sm border border-rose-200">
            ⚠️
          </div>
          <h3 className="text-2xl sm:text-3xl font-black text-slate-900">
            Audit Discrepancy! Out of Shields
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto font-medium">
            The Chief Auditor uncovered ledger errors and timed out your filings. Brush up on your chapters and try again!
          </p>
          <div className="pt-2 flex justify-center gap-3">
            <button
              onClick={restartBattle}
              className="btn-tactile px-6 py-2.5 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-black border-b-4 border-rose-700 active:border-b-0 transition-all flex items-center gap-1.5 shadow-sm"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retry Boss Battle</span>
            </button>
            <button
              onClick={onReturnHome}
              className="btn-tactile px-5 py-2.5 rounded-2xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-black border-2 border-slate-200 border-b-4 border-b-slate-300 active:border-b-2 transition-all shadow-xs"
            >
              Review Handbook
            </button>
          </div>
        </div>
      )}

      {/* ACTIVE BATTLE CARD - Arcade Console */}
      {gameState === 'playing' && (
        <div className="card-bouncy p-6 sm:p-8 rounded-[28px] bg-white border-2 border-rose-100 shadow-[0_12px_36px_-6px_rgba(244,63,94,0.12)] space-y-4">
          <div className="flex items-center justify-between text-xs font-bold">
            <span className="px-3 py-1 rounded-full bg-rose-100 text-rose-800 border border-rose-200 font-black">
              {currentChapter?.shortTitle || 'Comprehensive Rapid Question'}
            </span>
            <span className="text-slate-500 font-mono font-bold">
              Damage: -{currentQ.bossDamage} HP
            </span>
          </div>

          <h3 className="text-lg sm:text-xl font-black text-slate-900 leading-snug">
            {currentQ.question}
          </h3>

          {/* Options with Tactile 3D Buttons */}
          <div className="space-y-3 pt-1">
            {currentQ.options.map((opt, idx) => {
              const isSelected = selectedOption === idx;
              const isCorrect = idx === currentQ.correctIndex;

              let styles = 'bg-white hover:bg-slate-50 border-slate-200 border-b-4 border-b-slate-300 text-slate-800 shadow-xs';
              let animationClass = '';

              if (isAnswered) {
                if (isCorrect) {
                  styles = 'bg-emerald-50 border-emerald-500 border-b-4 border-b-emerald-600 text-emerald-950 font-black ring-2 ring-emerald-500/20';
                  animationClass = 'animate-pop-correct';
                } else if (isSelected && !isCorrect) {
                  styles = 'bg-rose-50 border-rose-500 border-b-4 border-b-rose-600 text-rose-950 font-black ring-2 ring-rose-500/20';
                  animationClass = 'animate-shake-wrong';
                } else {
                  styles = 'opacity-35 border-slate-200 bg-slate-50 text-slate-400';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(idx)}
                  disabled={isAnswered}
                  className={`btn-tactile w-full p-4 rounded-2xl border-2 text-left text-xs sm:text-sm font-semibold transition-all duration-150 flex items-start gap-3.5 ${styles} ${animationClass}`}
                >
                  <span className={`w-6 h-6 rounded-xl text-xs font-black flex items-center justify-center shrink-0 mt-0.5 ${
                    isAnswered && isCorrect
                      ? 'bg-emerald-600 text-white'
                      : isAnswered && isSelected && !isCorrect
                      ? 'bg-rose-600 text-white'
                      : 'bg-slate-100 text-slate-700'
                  }`}>
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span className="flex-1 leading-relaxed">{opt}</span>
                  {isAnswered && isCorrect && (
                    <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  )}
                  {isAnswered && isSelected && !isCorrect && (
                    <XCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Answer Breakdown */}
          {isAnswered && (
            <div className="pt-5 border-t-2 border-slate-100 space-y-4 animate-fadeIn">
              <div
                className={`p-5 rounded-2xl border-2 text-xs space-y-1.5 font-medium ${
                  selectedOption === currentQ.correctIndex
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-950 animate-pop-correct'
                    : 'bg-rose-50 border-rose-300 text-rose-950 animate-shake-wrong'
                }`}
              >
                <div className="flex items-center gap-2">
                  {selectedOption === currentQ.correctIndex ? (
                    <Zap className="w-5 h-5 text-emerald-600" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-rose-600" />
                  )}
                  <h4 className="font-black text-sm sm:text-base">
                    {selectedOption === currentQ.correctIndex
                      ? `Critical Hit! -${currentQ.bossDamage} Boss HP (+${Math.round(400 * currentMultiplier)} pts)`
                      : 'Shield Damaged by 1!'}
                  </h4>
                </div>
                <p className="leading-relaxed">{currentQ.explanation}</p>
                <div className="flex flex-wrap items-center justify-between gap-2 pt-1 font-semibold">
                  <span className="inline-block text-[11px] text-slate-600 font-mono">
                    Ref: {currentQ.ncertReference}
                  </span>
                  {onOpenGlossary && (
                    <button
                      onClick={() => onOpenGlossary()}
                      className="text-[11px] font-bold text-rose-700 hover:text-rose-900 underline flex items-center gap-1"
                    >
                      <span>Check NCERT Rule in Glossary</span>
                    </button>
                  )}
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={handleNext}
                  className="btn-tactile px-6 py-2.5 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white font-black text-xs border-b-4 border-rose-700 active:border-b-0 shadow-md flex items-center gap-2"
                >
                  <span>Next Attack</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
