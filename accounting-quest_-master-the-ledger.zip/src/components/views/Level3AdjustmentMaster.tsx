import React, { useState, useMemo } from 'react';
import { AdjustmentQuestion, LifelineState } from '../../types.ts';
import { ADJUSTMENT_QUESTIONS, CHAPTERS } from '../../data.ts';
import { 
  ArrowLeft, 
  HelpCircle, 
  SkipForward, 
  Percent, 
  CheckCircle, 
  XCircle, 
  Flame, 
  Award, 
  ChevronRight,
  Sliders,
  Scale,
  Calculator,
  Lightbulb,
  BookMarked
} from 'lucide-react';

interface Level3AdjustmentMasterProps {
  selectedChapterIds: number[];
  onReturnHome: () => void;
  recordAnswer: (isCorrect: boolean, baseScore?: number, baseExp?: number) => void;
  updateHighScore: (level: 'level3', score: number) => void;
  currentStreak: number;
  currentMultiplier: number;
  sound: {
    playCorrect: () => void;
    playWrong: () => void;
    playCombo: () => void;
    playClick: () => void;
  };
  onOpenGlossary?: (termQuery?: string) => void;
}

export const Level3AdjustmentMaster: React.FC<Level3AdjustmentMasterProps> = ({
  selectedChapterIds,
  onReturnHome,
  recordAnswer,
  updateHighScore,
  currentStreak,
  currentMultiplier,
  sound,
  onOpenGlossary,
}) => {
  const questions: AdjustmentQuestion[] = useMemo(() => {
    const filtered = ADJUSTMENT_QUESTIONS.filter((q) => selectedChapterIds.includes(q.chapterId));
    return filtered.length > 0 ? filtered : ADJUSTMENT_QUESTIONS;
  }, [selectedChapterIds]);

  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [levelScore, setLevelScore] = useState<number>(0);

  // Lifelines
  const [lifelines, setLifelines] = useState<LifelineState>({
    fiftyFiftyUsed: false,
    hintUsed: false,
    skipUsed: false,
  });
  const [hiddenOptions, setHiddenOptions] = useState<number[]>([]);
  const [showHint, setShowHint] = useState<boolean>(false);

  const currentQ = questions[currentIndex % questions.length];
  const currentChapter = CHAPTERS.find((c) => c.id === currentQ.chapterId);

  const handleSelectOption = (index: number) => {
    if (isAnswered) return;
    sound.playClick();
    setSelectedAnswer(index);
    setIsAnswered(true);

    const isCorrect = index === currentQ.correctIndex;
    if (isCorrect) {
      sound.playCorrect();
      if ((currentStreak + 1) % 3 === 0) sound.playCombo();
      const earned = Math.round(300 * currentMultiplier);
      setLevelScore((prev) => {
        const next = prev + earned;
        updateHighScore('level3', next);
        return next;
      });
      recordAnswer(true, 300, 50);
    } else {
      sound.playWrong();
      recordAnswer(false);
    }
  };

  const handleNextQuestion = () => {
    sound.playClick();
    setSelectedAnswer(null);
    setIsAnswered(false);
    setHiddenOptions([]);
    setShowHint(false);
    setCurrentIndex((prev) => prev + 1);
  };

  // Lifelines
  const useFiftyFifty = () => {
    if (lifelines.fiftyFiftyUsed || isAnswered) return;
    sound.playClick();
    const wrongIndices = currentQ.options
      .map((_, i) => i)
      .filter((i) => i !== currentQ.correctIndex);
    const toHide = wrongIndices.slice(0, 2);
    setHiddenOptions(toHide);
    setLifelines((prev) => ({ ...prev, fiftyFiftyUsed: true }));
  };

  const useHint = () => {
    if (lifelines.hintUsed) return;
    sound.playClick();
    setShowHint(true);
    setLifelines((prev) => ({ ...prev, hintUsed: true }));
  };

  const useSkip = () => {
    if (lifelines.skipUsed) return;
    sound.playClick();
    setLifelines((prev) => ({ ...prev, skipUsed: true }));
    handleNextQuestion();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn">
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b-2 border-slate-200">
        <button
          onClick={onReturnHome}
          className="btn-tactile flex items-center gap-1.5 px-3.5 py-1.5 rounded-2xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold border-2 border-slate-200 border-b-4 border-b-slate-300 active:border-b-2 transition-all shadow-xs"
        >
          <ArrowLeft className="w-4 h-4 text-sky-600" />
          <span>Back to Menu</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 rounded-2xl text-xs font-black bg-sky-100 text-sky-800 border border-sky-200 flex items-center gap-1.5 shadow-xs">
            <Sliders className="w-4 h-4 text-sky-600" />
            <span>Level 3: Adjustment Master</span>
          </span>
        </div>

        <div className="flex items-center gap-3 text-xs font-bold">
          {onOpenGlossary && (
            <button
              onClick={() => onOpenGlossary(currentQ.title)}
              className="btn-tactile flex items-center gap-1 px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border-2 border-indigo-200 border-b-4 border-b-indigo-300 active:border-b-2 transition-all shadow-xs"
              title="Open Glossary & Reference"
            >
              <BookMarked className="w-3.5 h-3.5 text-indigo-600" />
              <span className="hidden sm:inline">Glossary</span>
            </button>
          )}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border-2 border-slate-200 text-slate-700 shadow-xs">
            <Award className="w-4 h-4 text-sky-500" />
            <span className="text-slate-500 font-semibold">Score:</span>
            <span className="font-black text-slate-900">{levelScore}</span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 border-2 border-amber-200 text-amber-900 shadow-xs">
            <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span className="text-amber-700 font-semibold">Streak:</span>
            <span className="font-black text-amber-900">{currentStreak}</span>
          </div>
        </div>
      </div>

      {/* Lifelines Bar */}
      <div className="flex items-center justify-between p-3.5 rounded-2xl bg-white border-2 border-slate-200/80 shadow-xs text-xs font-bold">
        <span className="text-slate-600 font-extrabold flex items-center gap-1.5">
          <span>⚡ Tactical Lifelines:</span>
        </span>
        <div className="flex items-center gap-2">
          <button
            onClick={useFiftyFifty}
            disabled={lifelines.fiftyFiftyUsed || isAnswered}
            className={`btn-tactile flex items-center gap-1.5 px-3 py-1.5 rounded-xl border-2 transition-all ${
              lifelines.fiftyFiftyUsed
                ? 'opacity-40 border-slate-200 bg-slate-100 text-slate-400 cursor-not-allowed'
                : 'bg-sky-50 hover:bg-sky-100 border-sky-200 border-b-4 border-b-sky-300 active:border-b-2 text-sky-800 font-black shadow-xs'
            }`}
            title="Eliminate two wrong answers"
          >
            <Percent className="w-3.5 h-3.5" />
            <span>50 / 50</span>
          </button>

          <button
            onClick={useHint}
            disabled={lifelines.hintUsed}
            className={`btn-tactile flex items-center gap-1.5 px-3 py-1.5 rounded-xl border-2 transition-all ${
              lifelines.hintUsed
                ? 'opacity-40 border-slate-200 bg-slate-100 text-slate-400 cursor-not-allowed'
                : 'bg-amber-50 hover:bg-amber-100 border-amber-200 border-b-4 border-b-amber-300 active:border-b-2 text-amber-800 font-black shadow-xs'
            }`}
            title="Show calculation formula hint"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Hint</span>
          </button>

          <button
            onClick={useSkip}
            disabled={lifelines.skipUsed}
            className={`btn-tactile flex items-center gap-1.5 px-3 py-1.5 rounded-xl border-2 transition-all ${
              lifelines.skipUsed
                ? 'opacity-40 border-slate-200 bg-slate-100 text-slate-400 cursor-not-allowed'
                : 'bg-white hover:bg-slate-50 border-slate-200 border-b-4 border-b-slate-300 active:border-b-2 text-slate-700 font-black shadow-xs'
            }`}
            title="Skip question"
          >
            <SkipForward className="w-3.5 h-3.5" />
            <span>Skip</span>
          </button>
        </div>
      </div>

      {/* Hint Banner */}
      {showHint && currentQ.calculationSnippet && (
        <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-200 text-amber-900 text-xs flex items-start gap-3 animate-fadeIn shadow-xs">
          <Lightbulb className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
          <div>
            <strong className="block font-black text-amber-950 mb-0.5">Adjustment Calculation Logic:</strong>
            <span className="font-medium text-amber-900 leading-relaxed">{currentQ.calculationSnippet}</span>
          </div>
        </div>
      )}

      {/* Case Scenario & Question - Arcade Card */}
      <div className="card-bouncy p-6 sm:p-8 rounded-[28px] bg-white border-2 border-sky-100 shadow-[0_12px_36px_-6px_rgba(14,165,233,0.12)] space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-bold">
          <span className="px-3 py-1 rounded-full bg-sky-100 text-sky-800 border border-sky-200 font-black">
            {currentChapter?.shortTitle || 'Financial Statement Adjustments'}
          </span>
          <span className="text-slate-500 font-mono">
            Adjustment {(currentIndex % questions.length) + 1} of {questions.length}
          </span>
        </div>

        {/* Trial Balance & Adjustment Context Box */}
        <div className="p-5 rounded-2xl bg-slate-50 border-2 border-slate-200/80 space-y-2">
          <div className="flex items-center gap-2 text-xs text-sky-700 font-black">
            <Scale className="w-4 h-4 text-sky-600" />
            <span>Trial Balance Extract & Additional Information:</span>
          </div>
          <p className="text-base sm:text-lg font-bold text-slate-800 leading-relaxed">
            {currentQ.scenario}
          </p>
        </div>

        <h3 className="text-lg sm:text-xl font-black text-slate-900 leading-snug">
          {currentQ.question}
        </h3>

        {/* Options Grid with Tactile 3D Buttons */}
        <div className="space-y-3 pt-1">
          {currentQ.options.map((opt, idx) => {
            const isHidden = hiddenOptions.includes(idx);
            const isSelected = selectedAnswer === idx;
            const isCorrect = idx === currentQ.correctIndex;

            let styles = 'bg-white hover:bg-slate-50 border-slate-200 border-b-4 border-b-slate-300 text-slate-800 shadow-xs';
            let animationClass = '';

            if (isAnswered) {
              if (isCorrect) {
                styles = 'bg-emerald-50 border-emerald-500 border-b-4 border-b-emerald-600 text-emerald-950 font-black ring-2 ring-emerald-500/20';
                animationClass = 'animate-pop-correct';
              } else if (isSelected && !isCorrect) {
                styles = 'bg-rose-50 border-rose-500 border-b-4 border-b-rose-600 text-rose-950 font-black ring-2 ring-rose-500/20';
                animationClass = 'animate-shake-wrong';
              } else {
                styles = 'opacity-35 border-slate-200 bg-slate-50 text-slate-400';
              }
            }

            if (isHidden) {
              return (
                <div
                  key={idx}
                  className="p-4 rounded-2xl border-2 border-dashed border-slate-200 text-slate-400 text-xs italic bg-slate-50/50 text-center font-medium"
                >
                  (Eliminated by 50/50)
                </div>
              );
            }

            return (
              <button
                key={idx}
                onClick={() => handleSelectOption(idx)}
                disabled={isAnswered}
                className={`btn-tactile w-full p-4 rounded-2xl border-2 text-left text-xs sm:text-sm font-semibold transition-all duration-200 flex items-start gap-3.5 ${styles} ${animationClass}`}
              >
                <span className={`w-6 h-6 rounded-xl text-xs font-black flex items-center justify-center shrink-0 mt-0.5 ${
                  isAnswered && isCorrect
                    ? 'bg-emerald-600 text-white'
                    : isAnswered && isSelected && !isCorrect
                    ? 'bg-rose-600 text-white'
                    : 'bg-slate-100 text-slate-700'
                }`}>
                  {String.fromCharCode(65 + idx)}
                </span>
                <span className="flex-1 leading-relaxed">{opt}</span>
                {isAnswered && isCorrect && (
                  <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                )}
                {isAnswered && isSelected && !isCorrect && (
                  <XCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                )}
              </button>
            );
          })}
        </div>

        {/* Dual Effect Feedback & Final Accounts Presentation */}
        {isAnswered && (
          <div className="pt-5 border-t-2 border-slate-100 space-y-4 animate-fadeIn">
            {/* Visual presentation box */}
            <div className="grid sm:grid-cols-2 gap-3 text-xs font-medium">
              <div className="p-4 rounded-2xl bg-sky-50/60 border-2 border-sky-100 space-y-1.5">
                <span className="font-black text-sky-800 flex items-center gap-1.5 text-xs">
                  <Calculator className="w-4 h-4 text-sky-600" />
                  Trading / P&L Account Impact:
                </span>
                <p className="text-slate-700 leading-relaxed font-semibold">
                  {currentQ.tradingOrPLImpact}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-emerald-50/60 border-2 border-emerald-100 space-y-1.5">
                <span className="font-black text-emerald-800 flex items-center gap-1.5 text-xs">
                  <Scale className="w-4 h-4 text-emerald-600" />
                  Balance Sheet Presentation:
                </span>
                <p className="text-slate-700 leading-relaxed font-semibold">
                  {currentQ.balanceSheetImpact}
                </p>
              </div>
            </div>

            {/* Explanation banner */}
            <div
              className={`p-5 rounded-2xl border-2 space-y-1.5 text-xs font-medium ${
                selectedAnswer === currentQ.correctIndex
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-950 animate-pop-correct'
                  : 'bg-rose-50 border-rose-300 text-rose-950 animate-shake-wrong'
              }`}
            >
              <div className="flex items-center gap-2">
                {selectedAnswer === currentQ.correctIndex ? (
                  <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
                ) : (
                  <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
                )}
                <h4 className="font-black text-sm sm:text-base">
                  {selectedAnswer === currentQ.correctIndex
                    ? `🎉 Masterful Adjustment! +${Math.round(300 * currentMultiplier)} Points`
                    : '💡 Adjustment Review'}
                </h4>
              </div>
              <p className="leading-relaxed">{currentQ.explanation}</p>
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 font-semibold">
                <span className="inline-block text-[11px] text-slate-600 font-mono">
                  Ref: {currentQ.ncertReference}
                </span>
                {onOpenGlossary && (
                  <button
                    onClick={() => onOpenGlossary(currentQ.title)}
                    className="text-[11px] font-bold text-sky-700 hover:text-sky-900 underline flex items-center gap-1"
                  >
                    <span>Look up "{currentQ.title}" in Glossary</span>
                  </button>
                )}
              </div>
            </div>

            <div className="flex justify-end">
              <button
                onClick={handleNextQuestion}
                className="btn-tactile px-6 py-2.5 rounded-2xl bg-sky-500 hover:bg-sky-600 text-white font-black text-xs border-b-4 border-sky-700 active:border-b-0 shadow-md flex items-center gap-2"
              >
                <span>Next Adjustment</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
