import React, { useMemo } from 'react';
import { X, Trophy, Medal, User, TrendingUp } from 'lucide-react';
import { PlayerStats } from '../../types.ts';

interface LeaderboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  playerStats: PlayerStats;
}

// Generate mock leaderboard data
const generateMockData = (playerXp: number) => {
  const mockPlayers = [
    { name: 'GAAPGuru', xp: 9500 },
    { name: 'AuditPro', xp: 8200 },
    { name: 'TaxTitan', xp: 7100 },
    { name: 'LedgerLegend', xp: 6800 },
    { name: 'DebitMaster', xp: 5500 },
    { name: 'FiscalFiend', xp: 4200 },
    { name: 'CreditWhiz', xp: 3800 },
    { name: 'BalanceBuddy', xp: 2900 },
    { name: 'EntryExpert', xp: 1500 },
  ];

  const sorted = [...mockPlayers, { name: 'You', xp: playerXp }].sort((a, b) => b.xp - a.xp);
  return sorted.slice(0, 10);
};

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  isOpen,
  onClose,
  playerStats,
}) => {
  if (!isOpen) return null;

  const leaderboard = useMemo(() => generateMockData(playerStats.xp), [playerStats.xp]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white border-2 border-indigo-100 rounded-[28px] w-full max-w-lg flex flex-col shadow-[0_20px_50px_rgba(0,0,0,0.15)] overflow-hidden text-slate-800">
        
        {/* Header */}
        <div className="px-6 py-4 border-b-2 border-slate-100 flex items-center justify-between bg-slate-50/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-50 border-2 border-amber-100 text-amber-700 shadow-xs">
              <Trophy className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <h2 className="text-lg font-black text-slate-900">Global Leaderboard</h2>
              <p className="text-xs text-slate-500 font-medium">Top 10 Accounting Masters</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-400 hover:text-slate-700 border border-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 space-y-3">
          {leaderboard.map((player, index) => {
            const isSelf = player.name === 'You';
            const rank = index + 1;
            
            return (
              <div 
                key={index} 
                className={`flex items-center gap-4 p-4 rounded-2xl border-2 ${
                  isSelf 
                    ? 'bg-indigo-50 border-indigo-200 shadow-xs ring-2 ring-indigo-200/50' 
                    : 'bg-white border-slate-100'
                }`}
              >
                {/* Rank */}
                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center font-black text-sm shrink-0 ${
                  rank === 1 ? 'bg-amber-100 text-amber-900' :
                  rank === 2 ? 'bg-slate-200 text-slate-700' :
                  rank === 3 ? 'bg-orange-100 text-orange-900' :
                  'bg-slate-50 text-slate-500'
                }`}>
                  {rank <= 3 ? <Medal className="w-5 h-5" /> : rank}
                </div>

                {/* Avatar/Name */}
                <div className="flex-1 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-xs">
                    <User className="w-4 h-4 text-slate-400" />
                  </div>
                  <span className={`font-black text-sm ${isSelf ? 'text-indigo-900' : 'text-slate-700'}`}>
                    {player.name}
                  </span>
                </div>

                {/* XP */}
                <div className="text-right">
                  <div className="flex items-center justify-end gap-1 font-black text-emerald-600">
                    <TrendingUp className="w-3.5 h-3.5" />
                    {player.xp.toLocaleString()}
                  </div>
                  <div className="text-[10px] font-bold text-slate-400 uppercase">XP</div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t-2 border-slate-100 bg-slate-50/60 text-center">
          <button
            onClick={onClose}
            className="btn-tactile px-6 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs border-b-4 border-indigo-800 active:border-b-0 shadow-sm"
          >
            Back to Arena
          </button>
        </div>
      </div>
    </div>
  );
};
