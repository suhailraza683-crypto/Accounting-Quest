import React from 'react';
import { Chapter, PlayerStats, RankTier, DailyMission } from '../../types.ts';
import { CHAPTERS } from '../../data.ts';
import { GLOSSARY_TERMS } from '../../glossaryData.ts';
import { DailyMissionsCard } from './DailyMissionsCard.tsx';
import { CalendarStreakVisualizer } from './CalendarStreakVisualizer.tsx';
import { 
  CheckSquare, 
  Square, 
  Sparkles, 
  BookMarked, 
  BookOpen,
  FileSpreadsheet, 
  Sliders, 
  Swords, 
  Trophy, 
  ArrowRight,
  Flame,
  Check,
  Bot,
  Search,
  ExternalLink,
  Zap,
  Play
} from 'lucide-react';

interface HomeViewProps {
  selectedChapterIds: number[];
  onToggleChapter: (id: number) => void;
  onSelectAllChapters: () => void;
  onSelectCategory: (category: 'Foundations' | 'Recording' | 'Final Accounts') => void;
  onClearChapters: () => void;
  onStartLevel: (levelNum: 1 | 2 | 3 | 4) => void;
  stats: PlayerStats;
  rankInfo: { tier: RankTier; nextXp: number; progress: number; badgeColor: string };
  onOpenStudyGuide: () => void;
  onOpenGlossary: () => void;
  onOpenChat: () => void;
  missions: DailyMission[];
  completedCount: number;
  unclaimedCount: number;
  totalMissionsCount: number;
  onClaimMissionReward: (id: string) => void;
  onClaimAllMissionRewards: () => void;
  onAdvanceSimulationDay: () => void;
  onClaimDailyCheckIn: () => void;
}

// Chapter icon helper for playful badge design
const getChapterIcon = (chNum: number): string => {
  switch (chNum) {
    case 1: return '📖';
    case 2: return '🏷️';
    case 3: return '⚖️';
    case 4: return '⏳';
    case 5: return '🧮';
    case 6: return '📜';
    case 7: return '🧾';
    case 8: return '✍️';
    case 9: return '🏦';
    case 10: return '🔄';
    case 11: return '🔍';
    case 12: return '📉';
    default: return '📊';
  }
};

export const HomeView: React.FC<HomeViewProps> = ({
  selectedChapterIds,
  onToggleChapter,
  onSelectAllChapters,
  onSelectCategory,
  onClearChapters,
  onStartLevel,
  stats,
  rankInfo,
  onOpenStudyGuide,
  onOpenGlossary,
  onOpenChat,
  missions,
  completedCount,
  unclaimedCount,
  totalMissionsCount,
  onClaimMissionReward,
  onClaimAllMissionRewards,
  onAdvanceSimulationDay,
  onClaimDailyCheckIn,
}) => {
  const isAllSelected = selectedChapterIds.length === CHAPTERS.length;
  const selectedCount = selectedChapterIds.length;

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Playful Hero Banner */}
      <div className="relative overflow-hidden rounded-[28px] bg-gradient-to-br from-indigo-50 via-white to-violet-50/60 border-2 border-indigo-100 p-6 sm:p-8 md:p-10 shadow-[0_12px_36px_-6px_rgba(99,102,241,0.12)]">
        {/* Soft pastel decorative blurs */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-200/30 rounded-full blur-3xl -z-10 pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 w-72 h-72 bg-emerald-200/25 rounded-full blur-3xl -z-10 pointer-events-none" />

        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border-2 border-indigo-200 text-indigo-700 text-xs font-black shadow-xs">
            <Sparkles className="w-4 h-4 text-indigo-500" />
            <span>Interactive NCERT Class 11 Game Arena</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-tight">
            Master the Double-Entry Ledger with{' '}
            <span className="bg-gradient-to-r from-indigo-600 via-violet-600 to-emerald-500 bg-clip-text text-transparent">
              Playful Quests!
            </span>
          </h2>

          <p className="text-sm sm:text-base text-slate-600 leading-relaxed font-medium">
            Pick your chapters, build blazing answer streaks 🔥, balance real Debit & Credit journal entries, solve final adjustments, and beat the Audit Boss!
          </p>

          {/* Quick status bar */}
          <div className="pt-2 flex flex-wrap items-center gap-2.5 text-xs font-bold">
            <div className="px-3.5 py-2 rounded-2xl bg-white border-2 border-slate-200 text-slate-700 flex items-center gap-2 shadow-xs">
              <span className="text-slate-400 font-semibold">Rank:</span>
              <span className="text-indigo-600 font-extrabold">{rankInfo.tier}</span>
            </div>

            <div className="px-3.5 py-2 rounded-2xl bg-amber-50 border-2 border-amber-200 text-amber-900 flex items-center gap-2 shadow-xs">
              <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
              <span className="text-amber-700 font-semibold">Total Score:</span>
              <span className="text-amber-900 font-extrabold">{stats.score.toLocaleString()} pts</span>
            </div>

            <button
              onClick={onOpenChat}
              className="btn-tactile px-3.5 py-2 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-black border-b-4 border-emerald-700 active:border-b-0 shadow-sm flex items-center gap-1.5"
            >
              <Bot className="w-4 h-4 text-white" />
              <span>Ask Professor Ledger (AI)</span>
            </button>

            <button
              onClick={onOpenGlossary}
              className="btn-tactile px-3.5 py-2 rounded-2xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-black border-2 border-indigo-200 border-b-4 border-b-indigo-300 active:border-b-2 shadow-sm flex items-center gap-1.5"
            >
              <BookMarked className="w-4 h-4 text-indigo-600" />
              <span>Accounting Glossary</span>
            </button>

            <button
              onClick={onOpenStudyGuide}
              className="btn-tactile px-3.5 py-2 rounded-2xl bg-white hover:bg-slate-50 text-slate-700 font-bold border-2 border-slate-200 border-b-4 border-b-slate-300 active:border-b-2 shadow-sm flex items-center gap-1.5"
            >
              <BookOpen className="w-4 h-4 text-slate-500" />
              <span>Handbook</span>
            </button>
          </div>
        </div>
      </div>

      {/* 7-DAY CALENDAR STREAK VISUALIZER */}
      <CalendarStreakVisualizer
        loginStreak={stats.loginStreak}
        unlockedBadges={stats.unlockedBadges}
        lastLoginDate={stats.lastLoginDate}
        onAdvanceSimulationDay={onAdvanceSimulationDay}
        onClaimDailyCheckIn={onClaimDailyCheckIn}
      />

      {/* DAILY MISSIONS BOARD */}
      <DailyMissionsCard
        missions={missions}
        completedCount={completedCount}
        unclaimedCount={unclaimedCount}
        totalCount={totalMissionsCount}
        onClaimReward={onClaimMissionReward}
        onClaimAllRewards={onClaimAllMissionRewards}
      />

      {/* SECTION 1: CHAPTER SELECTION SYSTEM */}
      <section className="space-y-4">
        {/* Prominent Chapter Filter / Subject Toggle */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b-2 border-slate-200/80">
          <div>
            <div className="flex items-center gap-2.5">
              <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                1. Select Target Chapters
              </h3>
              <span className="px-3 py-1 rounded-full text-xs font-black bg-indigo-100 text-indigo-700 border border-indigo-200">
                {selectedCount} of {CHAPTERS.length} Selected
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Customize your curriculum. Practice one topic or the complete NCERT Class 11 syllabus.
            </p>
          </div>

          {/* Selection Filter Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs font-bold">
            <button
              onClick={onSelectAllChapters}
              className={`btn-tactile px-3.5 py-1.5 rounded-xl border-2 transition-all ${
                isAllSelected
                  ? 'bg-indigo-600 text-white border-indigo-700 border-b-4 border-b-indigo-800 shadow-sm'
                  : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200 border-b-4 border-b-slate-300'
              }`}
            >
              Full Syllabus (All 12)
            </button>
            <button
              onClick={() => onSelectCategory('Foundations')}
              className="btn-tactile px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border-2 border-slate-200 border-b-4 border-b-slate-300 transition-all"
            >
              Foundations (1-4)
            </button>
            <button
              onClick={() => onSelectCategory('Recording')}
              className="btn-tactile px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border-2 border-slate-200 border-b-4 border-b-slate-300 transition-all"
            >
              Recording (5-11)
            </button>
            <button
              onClick={() => onSelectCategory('Final Accounts')}
              className="btn-tactile px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border-2 border-slate-200 border-b-4 border-b-slate-300 transition-all"
            >
              Final Accounts (12-13)
            </button>
            {selectedCount > 0 && (
              <button
                onClick={onClearChapters}
                className="px-2.5 py-1.5 text-xs text-slate-400 hover:text-rose-500 font-bold transition-colors"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Chapters Grid with bright, colorful badge-like selection tiles */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3.5">
          {CHAPTERS.map((ch: Chapter) => {
            const isSelected = selectedChapterIds.includes(ch.id);
            const icon = getChapterIcon(ch.chapterNumber);

            return (
              <div
                key={ch.id}
                onClick={() => onToggleChapter(ch.id)}
                className={`card-bouncy cursor-pointer relative p-4 rounded-2xl border-2 text-left transition-all duration-200 flex flex-col justify-between ${
                  isSelected
                    ? 'bg-white border-indigo-500 shadow-[0_8px_20px_-4px_rgba(99,102,241,0.2)] ring-2 ring-indigo-500/20'
                    : 'bg-white/80 border-slate-200/90 hover:border-slate-300 hover:bg-white text-slate-500 shadow-xs'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xl p-1.5 rounded-xl bg-indigo-50/70 border border-indigo-100/80 shadow-xs">
                        {icon}
                      </span>
                      <span className="text-xs font-black px-2 py-0.5 rounded-lg bg-slate-100 text-slate-700">
                        Ch {ch.chapterNumber}
                      </span>
                    </div>

                    <div className="text-indigo-600">
                      {isSelected ? (
                        <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                          <Check className="w-4 h-4 stroke-[3]" />
                        </div>
                      ) : (
                        <div className="w-6 h-6 rounded-lg border-2 border-slate-300 bg-white" />
                      )}
                    </div>
                  </div>

                  <h4 className={`text-sm font-extrabold leading-snug ${isSelected ? 'text-slate-900' : 'text-slate-700'}`}>
                    {ch.title}
                  </h4>

                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed font-medium">
                    {ch.description}
                  </p>
                </div>

                <div className="mt-3.5 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] font-semibold">
                  <span className="text-slate-400">{ch.category}</span>
                  {isSelected && (
                    <span className="text-emerald-600 font-extrabold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5 stroke-[3]" /> Selected
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {selectedCount === 0 && (
          <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-200 text-amber-900 text-xs text-center flex items-center justify-center gap-2 font-bold">
            <span>⚠️ Select at least one chapter to activate game training modes!</span>
            <button
              onClick={onSelectAllChapters}
              className="underline font-black text-amber-800 hover:text-amber-950"
            >
              Select All Chapters
            </button>
          </div>
        )}
      </section>

      {/* SECTION 2: GAMEPLAY LEVELS */}
      <section className="space-y-4 pt-2">
        <div className="flex items-center justify-between pb-3 border-b-2 border-slate-200/80">
          <div>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              2. Launch Training Level
            </h3>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Four gamified training arenas inspired by arcade challenges and official NCERT guidelines.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Level 1: Term Matcher & Flashcards */}
          <div 
            onClick={() => selectedCount > 0 && onStartLevel(1)}
            className={`card-bouncy relative rounded-3xl p-6 border-2 transition-all duration-200 flex flex-col justify-between ${
              selectedCount > 0
                ? 'cursor-pointer bg-white border-indigo-200 hover:border-indigo-400 shadow-[0_10px_25px_-5px_rgba(99,102,241,0.12)]'
                : 'opacity-50 cursor-not-allowed bg-slate-50 border-slate-200'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-3.5">
                <div className="p-3 rounded-2xl bg-indigo-50 border-2 border-indigo-100 text-indigo-600 shadow-xs">
                  <BookMarked className="w-6 h-6" />
                </div>
                <span className="text-xs font-black px-3 py-1 rounded-full bg-indigo-100 text-indigo-800">
                  Level 1 • Quiz & Flashcards
                </span>
              </div>

              <h4 className="text-lg font-black text-slate-900 group-hover:text-indigo-600 transition-colors">
                Term Matcher & 3D Flashcards
              </h4>
              <p className="text-xs sm:text-sm text-slate-500 mt-1.5 leading-relaxed font-medium">
                Test concepts, definitions, and Golden Rules (Personal, Real, Nominal). Toggle between interactive flashcards and rapid-fire streak quizzes.
              </p>
            </div>

            <div className="mt-6 pt-3.5 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-600 font-bold flex items-center gap-1.5">
                <Trophy className="w-4 h-4 text-amber-500" />
                High Score: {stats.levelHighScores.level1} pts
              </span>
              <button 
                disabled={selectedCount === 0}
                className="btn-tactile px-4 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs border-b-4 border-indigo-800 active:border-b-0 shadow-sm flex items-center gap-1.5"
              >
                <span>Play Level 1</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Level 2: Journal Entry & Voucher Simulator */}
          <div 
            onClick={() => selectedCount > 0 && onStartLevel(2)}
            className={`card-bouncy relative rounded-3xl p-6 border-2 transition-all duration-200 flex flex-col justify-between ${
              selectedCount > 0
                ? 'cursor-pointer bg-white border-emerald-200 hover:border-emerald-400 shadow-[0_10px_25px_-5px_rgba(16,185,129,0.12)]'
                : 'opacity-50 cursor-not-allowed bg-slate-50 border-slate-200'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-3.5">
                <div className="p-3 rounded-2xl bg-emerald-50 border-2 border-emerald-100 text-emerald-600 shadow-xs">
                  <FileSpreadsheet className="w-6 h-6" />
                </div>
                <span className="text-xs font-black px-3 py-1 rounded-full bg-emerald-100 text-emerald-800">
                  Level 2 • Simulator
                </span>
              </div>

              <h4 className="text-lg font-black text-slate-900 group-hover:text-emerald-600 transition-colors">
                Journal Entry & Voucher Simulator
              </h4>
              <p className="text-xs sm:text-sm text-slate-500 mt-1.5 leading-relaxed font-medium">
                Analyze real business transactions, pick exact Debit and Credit accounts, specify Golden Rules, and identify Debit, Credit, or Transfer vouchers.
              </p>
            </div>

            <div className="mt-6 pt-3.5 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-600 font-bold flex items-center gap-1.5">
                <Trophy className="w-4 h-4 text-emerald-500" />
                High Score: {stats.levelHighScores.level2} pts
              </span>
              <button 
                disabled={selectedCount === 0}
                className="btn-tactile px-4 py-2 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-xs border-b-4 border-emerald-700 active:border-b-0 shadow-sm flex items-center gap-1.5"
              >
                <span>Play Level 2</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Level 3: Adjustment Master */}
          <div 
            onClick={() => selectedCount > 0 && onStartLevel(3)}
            className={`card-bouncy relative rounded-3xl p-6 border-2 transition-all duration-200 flex flex-col justify-between ${
              selectedCount > 0
                ? 'cursor-pointer bg-white border-sky-200 hover:border-sky-400 shadow-[0_10px_25px_-5px_rgba(14,165,233,0.12)]'
                : 'opacity-50 cursor-not-allowed bg-slate-50 border-slate-200'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-3.5">
                <div className="p-3 rounded-2xl bg-sky-50 border-2 border-sky-100 text-sky-600 shadow-xs">
                  <Sliders className="w-6 h-6" />
                </div>
                <span className="text-xs font-black px-3 py-1 rounded-full bg-sky-100 text-sky-800">
                  Level 3 • Dual Effect & Calculations
                </span>
              </div>

              <h4 className="text-lg font-black text-slate-900 group-hover:text-sky-600 transition-colors">
                Adjustment Master (Final Accounts)
              </h4>
              <p className="text-xs sm:text-sm text-slate-500 mt-1.5 leading-relaxed font-medium">
                Solve closing stock valuation (cost vs net realizable value), calculate prepaid/outstanding expenses, accrued income, and debtors provision percentages.
              </p>
            </div>

            <div className="mt-6 pt-3.5 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-600 font-bold flex items-center gap-1.5">
                <Trophy className="w-4 h-4 text-sky-500" />
                High Score: {stats.levelHighScores.level3} pts
              </span>
              <button 
                disabled={selectedCount === 0}
                className="btn-tactile px-4 py-2 rounded-2xl bg-sky-500 hover:bg-sky-600 text-white font-black text-xs border-b-4 border-sky-700 active:border-b-0 shadow-sm flex items-center gap-1.5"
              >
                <span>Play Level 3</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Level 4: Boss Challenge */}
          <div 
            onClick={() => selectedCount > 0 && onStartLevel(4)}
            className={`card-bouncy relative rounded-3xl p-6 border-2 transition-all duration-200 flex flex-col justify-between ${
              selectedCount > 0
                ? 'cursor-pointer bg-white border-rose-200 hover:border-rose-400 shadow-[0_10px_25px_-5px_rgba(244,63,94,0.12)]'
                : 'opacity-50 cursor-not-allowed bg-slate-50 border-slate-200'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-3.5">
                <div className="p-3 rounded-2xl bg-rose-50 border-2 border-rose-100 text-rose-600 shadow-xs">
                  <Swords className="w-6 h-6" />
                </div>
                <span className="text-xs font-black px-3 py-1 rounded-full bg-rose-100 text-rose-800">
                  Level 4 • Time-Attack Boss Battle
                </span>
              </div>

              <h4 className="text-lg font-black text-slate-900 group-hover:text-rose-600 transition-colors">
                Boss Challenge: Audit Showdown
              </h4>
              <p className="text-xs sm:text-sm text-slate-500 mt-1.5 leading-relaxed font-medium">
                Face "The Senior Auditor" in a 15-second time limit per question! Rapid syllabus problems, combo multipliers, and Boss HP bar.
              </p>
            </div>

            <div className="mt-6 pt-3.5 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-600 font-bold flex items-center gap-1.5">
                <Trophy className="w-4 h-4 text-rose-500" />
                High Score: {stats.levelHighScores.level4} pts
              </span>
              <button 
                disabled={selectedCount === 0}
                className="btn-tactile px-4 py-2 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white font-black text-xs border-b-4 border-rose-700 active:border-b-0 shadow-sm flex items-center gap-1.5"
              >
                <span>Fight Boss</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 3: DEDICATED GLOSSARY & NCERT REFERENCE BANNER & PREVIEW */}
      <section className="space-y-4 pt-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b-2 border-slate-200/80">
          <div>
            <div className="flex items-center gap-2.5">
              <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                <BookMarked className="w-6 h-6 text-indigo-600" />
                <span>3. Glossary & NCERT Rule Reference</span>
              </h3>
              <span className="text-xs px-3 py-1 rounded-full font-black bg-indigo-100 text-indigo-700 border border-indigo-200">
                {GLOSSARY_TERMS.length} Terms
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Quick reference guide for every accounting term, definition, dual-aspect rules, and NCERT Class 11 citations.
            </p>
          </div>

          <button
            onClick={onOpenGlossary}
            className="btn-tactile px-4 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs border-b-4 border-indigo-800 active:border-b-0 transition-all flex items-center gap-2 shadow-sm self-start sm:self-auto"
          >
            <Search className="w-4 h-4" />
            <span>Open Full Glossary</span>
          </button>
        </div>

        {/* Featured Glossary Term Chips Preview */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {GLOSSARY_TERMS.slice(0, 6).map((term) => (
            <div
              key={term.id}
              onClick={onOpenGlossary}
              className="card-bouncy group cursor-pointer p-4 rounded-2xl bg-white hover:bg-indigo-50/40 border-2 border-slate-200/80 hover:border-indigo-300 transition-all flex flex-col justify-between space-y-2 shadow-xs"
            >
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-extrabold text-sm text-indigo-700 group-hover:text-indigo-800 transition-colors">
                    {term.term}
                  </h4>
                  <span className="text-[10px] px-2 py-0.5 rounded-lg font-black bg-slate-100 text-slate-600">
                    {term.category}
                  </span>
                </div>
                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed font-medium">
                  {term.definition}
                </p>
              </div>

              <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] font-semibold">
                <span className="text-slate-400 font-mono truncate max-w-[170px]">
                  {term.ncertGuideline}
                </span>
                <span className="text-indigo-600 group-hover:translate-x-0.5 transition-transform flex items-center gap-1 font-bold text-[11px]">
                  <span>View Rule</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
