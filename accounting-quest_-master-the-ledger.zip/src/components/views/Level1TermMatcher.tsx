import React, { useState, useMemo } from 'react';
import { TermQuestion, LifelineState } from '../../types.ts';
import { TERM_QUESTIONS, CHAPTERS } from '../../data.ts';
import { 
  ArrowLeft, 
  RotateCcw, 
  Sparkles, 
  HelpCircle, 
  SkipForward, 
  Percent, 
  CheckCircle, 
  XCircle, 
  Flame, 
  BookOpen, 
  Award,
  ChevronLeft,
  ChevronRight,
  Lightbulb
} from 'lucide-react';

interface Level1TermMatcherProps {
  selectedChapterIds: number[];
  onReturnHome: () => void;
  recordAnswer: (isCorrect: boolean, baseScore?: number, baseExp?: number) => void;
  updateHighScore: (level: 'level1', score: number) => void;
  currentStreak: number;
  currentMultiplier: number;
  sound: {
    playCorrect: () => void;
    playWrong: () => void;
    playCombo: () => void;
    playClick: () => void;
  };
  onOpenGlossary?: (termQuery?: string) => void;
}

export const Level1TermMatcher: React.FC<Level1TermMatcherProps> = ({
  selectedChapterIds,
  onReturnHome,
  recordAnswer,
  updateHighScore,
  currentStreak,
  currentMultiplier,
  sound,
  onOpenGlossary,
}) => {
  const [mode, setMode] = useState<'quiz' | 'flashcards'>('quiz');

  // Filter questions according to selected chapters
  const questions: TermQuestion[] = useMemo(() => {
    const filtered = TERM_QUESTIONS.filter((q) => selectedChapterIds.includes(q.chapterId));
    return filtered.length > 0 ? filtered : TERM_QUESTIONS;
  }, [selectedChapterIds]);

  // Quiz state
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [levelScore, setLevelScore] = useState<number>(0);
  const [levelCorrectCount, setLevelCorrectCount] = useState<number>(0);

  // Lifelines
  const [lifelines, setLifelines] = useState<LifelineState>({
    fiftyFiftyUsed: false,
    hintUsed: false,
    skipUsed: false,
  });
  const [hiddenOptions, setHiddenOptions] = useState<number[]>([]);
  const [showHint, setShowHint] = useState<boolean>(false);

  // Flashcards state
  const [isFlipped, setIsFlipped] = useState<boolean>(false);
  const [flashcardIndex, setFlashcardIndex] = useState<number>(0);

  const currentQ = questions[currentIndex % questions.length];
  const currentChapter = CHAPTERS.find((c) => c.id === currentQ.chapterId);
  const currentFlashcardQ = questions[flashcardIndex % questions.length];

  const handleSelectOption = (index: number) => {
    if (isAnswered) return;
    sound.playClick();
    setSelectedAnswer(index);
    setIsAnswered(true);

    const isCorrect = index === currentQ.correctIndex;
    if (isCorrect) {
      sound.playCorrect();
      if ((currentStreak + 1) % 3 === 0) {
        sound.playCombo();
      }
      const earned = Math.round(150 * currentMultiplier);
      setLevelScore((prev) => {
        const next = prev + earned;
        updateHighScore('level1', next);
        return next;
      });
      setLevelCorrectCount((prev) => prev + 1);
      recordAnswer(true, 150, 30);
    } else {
      sound.playWrong();
      recordAnswer(false);
    }
  };

  const handleNextQuestion = () => {
    sound.playClick();
    setSelectedAnswer(null);
    setIsAnswered(false);
    setHiddenOptions([]);
    setShowHint(false);
    setCurrentIndex((prev) => prev + 1);
  };

  // Lifelines actions
  const useFiftyFifty = () => {
    if (lifelines.fiftyFiftyUsed || isAnswered) return;
    sound.playClick();
    const wrongIndices = currentQ.options
      .map((_, i) => i)
      .filter((i) => i !== currentQ.correctIndex);
    // Hide up to two wrong options
    const toHide = wrongIndices.slice(0, 2);
    setHiddenOptions(toHide);
    setLifelines((prev) => ({ ...prev, fiftyFiftyUsed: true }));
  };

  const useHint = () => {
    if (lifelines.hintUsed) return;
    sound.playClick();
    setShowHint(true);
    setLifelines((prev) => ({ ...prev, hintUsed: true }));
  };

  const useSkip = () => {
    if (lifelines.skipUsed) return;
    sound.playClick();
    setLifelines((prev) => ({ ...prev, skipUsed: true }));
    handleNextQuestion();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn">
      {/* Top Bar Navigation & Mode Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b-2 border-slate-200">
        <button
          onClick={onReturnHome}
          className="btn-tactile flex items-center gap-1.5 px-3.5 py-1.5 rounded-2xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold border-2 border-slate-200 border-b-4 border-b-slate-300 active:border-b-2 transition-all shadow-xs"
        >
          <ArrowLeft className="w-4 h-4 text-indigo-600" />
          <span>Back to Menu</span>
        </button>

        <div className="flex items-center rounded-2xl bg-slate-100 p-1 border-2 border-slate-200 text-xs font-bold">
          <button
            onClick={() => {
              sound.playClick();
              setMode('quiz');
            }}
            className={`px-4 py-1.5 rounded-xl transition-all ${
              mode === 'quiz'
                ? 'bg-indigo-600 text-white shadow-xs font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Quiz Matcher
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setMode('flashcards');
              setIsFlipped(false);
            }}
            className={`px-4 py-1.5 rounded-xl transition-all ${
              mode === 'flashcards'
                ? 'bg-indigo-600 text-white shadow-xs font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Flashcards Deck
          </button>
        </div>

        {mode === 'quiz' && (
          <div className="flex items-center gap-3 text-xs font-bold">
            {onOpenGlossary && (
              <button
                onClick={() => onOpenGlossary(currentQ.term)}
                className="btn-tactile flex items-center gap-1 px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border-2 border-indigo-200 border-b-4 border-b-indigo-300 active:border-b-2 transition-all"
                title="Open term in Glossary & Reference"
              >
                <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
                <span className="hidden sm:inline">Glossary</span>
              </button>
            )}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border-2 border-slate-200 text-slate-700 shadow-xs">
              <Award className="w-4 h-4 text-indigo-500" />
              <span className="text-slate-500 font-semibold">Score:</span>
              <span className="font-black text-slate-900">{levelScore}</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 border-2 border-amber-200 text-amber-900 shadow-xs">
              <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
              <span className="text-amber-700 font-semibold">Streak:</span>
              <span className="font-black text-amber-900">{currentStreak}</span>
            </div>
          </div>
        )}
      </div>

      {/* QUIZ MODE */}
      {mode === 'quiz' && (
        <div className="space-y-6">
          {/* Lifelines Bar */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-white border-2 border-slate-200/80 shadow-xs text-xs font-bold">
            <span className="text-slate-600 font-extrabold flex items-center gap-1.5">
              <span>⚡ Tactical Lifelines:</span>
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={useFiftyFifty}
                disabled={lifelines.fiftyFiftyUsed || isAnswered}
                className={`btn-tactile flex items-center gap-1.5 px-3 py-1.5 rounded-xl border-2 transition-all ${
                  lifelines.fiftyFiftyUsed
                    ? 'opacity-40 border-slate-200 bg-slate-100 text-slate-400 cursor-not-allowed'
                    : 'bg-indigo-50 hover:bg-indigo-100 border-indigo-200 border-b-4 border-b-indigo-300 active:border-b-2 text-indigo-700 font-black shadow-xs'
                }`}
                title="Eliminate two incorrect options"
              >
                <Percent className="w-3.5 h-3.5" />
                <span>50 / 50</span>
              </button>

              <button
                onClick={useHint}
                disabled={lifelines.hintUsed}
                className={`btn-tactile flex items-center gap-1.5 px-3 py-1.5 rounded-xl border-2 transition-all ${
                  lifelines.hintUsed
                    ? 'opacity-40 border-slate-200 bg-slate-100 text-slate-400 cursor-not-allowed'
                    : 'bg-amber-50 hover:bg-amber-100 border-amber-200 border-b-4 border-b-amber-300 active:border-b-2 text-amber-800 font-black shadow-xs'
                }`}
                title="Show NCERT concept hint"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Hint</span>
              </button>

              <button
                onClick={useSkip}
                disabled={lifelines.skipUsed}
                className={`btn-tactile flex items-center gap-1.5 px-3 py-1.5 rounded-xl border-2 transition-all ${
                  lifelines.skipUsed
                    ? 'opacity-40 border-slate-200 bg-slate-100 text-slate-400 cursor-not-allowed'
                    : 'bg-white hover:bg-slate-50 border-slate-200 border-b-4 border-b-slate-300 active:border-b-2 text-slate-700 font-black shadow-xs'
                }`}
                title="Skip this question with no penalty"
              >
                <SkipForward className="w-3.5 h-3.5" />
                <span>Skip</span>
              </button>
            </div>
          </div>

          {/* Hint Dropdown if triggered */}
          {showHint && (
            <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-200 text-amber-900 text-xs flex items-start gap-3 animate-fadeIn shadow-xs">
              <Lightbulb className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
              <div>
                <strong className="block font-black text-amber-950 mb-0.5">NCERT Golden Clue:</strong>
                <span className="font-medium text-amber-900 leading-relaxed">{currentQ.flashcard.proTip}</span>
              </div>
            </div>
          )}

          {/* Question Card - Arcade Console */}
          <div className="card-bouncy p-6 sm:p-8 rounded-[28px] bg-white border-2 border-indigo-100 shadow-[0_12px_36px_-6px_rgba(99,102,241,0.12)] space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-bold">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full bg-indigo-100 text-indigo-700 border border-indigo-200 font-black">
                  {currentChapter?.shortTitle || 'Class 11 Accounting'}
                </span>
                <span className="text-slate-500">
                  Question {(currentIndex % questions.length) + 1} of {questions.length}
                </span>
              </div>
              {currentQ.ruleCategory && (
                <span className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 font-extrabold text-[11px]">
                  Category: {currentQ.ruleCategory} Account
                </span>
              )}
            </div>

            <h3 className="text-xl sm:text-2xl font-black text-slate-900 leading-snug">
              {currentQ.question}
            </h3>

            {/* Answer Options Grid with Tactile 3D Buttons */}
            <div className="grid sm:grid-cols-2 gap-3.5 pt-2">
              {currentQ.options.map((opt, idx) => {
                const isHidden = hiddenOptions.includes(idx);
                const isSelected = selectedAnswer === idx;
                const isCorrect = idx === currentQ.correctIndex;

                let btnStyles = 'bg-white hover:bg-indigo-50/50 border-2 border-slate-200 border-b-4 border-b-slate-300 hover:border-indigo-300 text-slate-800 shadow-xs';
                let animationClass = '';

                if (isAnswered) {
                  if (isCorrect) {
                    btnStyles = 'bg-emerald-50 border-2 border-emerald-500 border-b-4 border-b-emerald-600 text-emerald-950 font-black ring-2 ring-emerald-500/20';
                    animationClass = 'animate-pop-correct';
                  } else if (isSelected && !isCorrect) {
                    btnStyles = 'bg-rose-50 border-2 border-rose-500 border-b-4 border-b-rose-600 text-rose-950 font-black ring-2 ring-rose-500/20';
                    animationClass = 'animate-shake-wrong';
                  } else {
                    btnStyles = 'opacity-35 border-slate-200 bg-slate-50 text-slate-400';
                  }
                }

                if (isHidden) {
                  return (
                    <div
                      key={idx}
                      className="p-4 rounded-2xl border-2 border-dashed border-slate-200 text-slate-400 text-xs flex items-center justify-center italic bg-slate-50/50 font-medium"
                    >
                      (Option eliminated by 50/50)
                    </div>
                  );
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(idx)}
                    disabled={isAnswered}
                    className={`btn-tactile p-4 rounded-2xl text-left text-xs sm:text-sm font-semibold transition-all duration-200 flex items-start gap-3 ${btnStyles} ${animationClass}`}
                  >
                    <span className={`w-6 h-6 rounded-xl text-xs font-black flex items-center justify-center shrink-0 mt-0.5 ${
                      isAnswered && isCorrect
                        ? 'bg-emerald-600 text-white'
                        : isAnswered && isSelected && !isCorrect
                        ? 'bg-rose-600 text-white'
                        : 'bg-slate-100 text-slate-700'
                    }`}>
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <span className="flex-1 leading-relaxed">{opt}</span>
                    {isAnswered && isCorrect && (
                      <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    )}
                    {isAnswered && isSelected && !isCorrect && (
                      <XCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Answer Feedback & Rule Breakdown */}
            {isAnswered && (
              <div className="pt-5 border-t-2 border-slate-100 space-y-4 animate-fadeIn">
                <div
                  className={`p-4 sm:p-5 rounded-2xl border-2 flex items-start gap-3.5 ${
                    selectedAnswer === currentQ.correctIndex
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-950 animate-pop-correct'
                      : 'bg-rose-50 border-rose-300 text-rose-950 animate-shake-wrong'
                  }`}
                >
                  {selectedAnswer === currentQ.correctIndex ? (
                    <CheckCircle className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="w-6 h-6 text-rose-600 shrink-0 mt-0.5" />
                  )}
                  <div className="space-y-1.5 text-xs">
                    <h4 className="font-black text-sm sm:text-base">
                      {selectedAnswer === currentQ.correctIndex
                        ? `🎉 Spot on! +${Math.round(150 * currentMultiplier)} Points (${currentMultiplier}x Streak)`
                        : '❌ Incorrect Entry'}
                    </h4>
                    <p className="leading-relaxed font-medium">{currentQ.explanation}</p>
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1 font-semibold">
                      <span className="inline-block text-[11px] text-slate-600 font-mono">
                        Ref: {currentQ.ncertReference}
                      </span>
                      {onOpenGlossary && (
                        <button
                          onClick={() => onOpenGlossary(currentQ.term)}
                          className="text-[11px] font-bold text-indigo-700 hover:text-indigo-900 underline flex items-center gap-1"
                        >
                          <span>Look up "{currentQ.term}" in Glossary</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    onClick={handleNextQuestion}
                    className="btn-tactile px-6 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs border-b-4 border-indigo-800 active:border-b-0 shadow-md flex items-center gap-2"
                  >
                    <span>Next Question</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* FLASHCARD STUDY DECK MODE */}
      {mode === 'flashcards' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500">
            <span>Card {flashcardIndex + 1} of {questions.length}</span>
            <span>Click card to flip definition & rules</span>
          </div>

          {/* Interactive Flip Card with Playful Light Styling */}
          <div
            onClick={() => {
              sound.playClick();
              setIsFlipped(!isFlipped);
            }}
            className="card-bouncy cursor-pointer perspective min-h-[320px] w-full"
          >
            <div
              className={`relative w-full min-h-[340px] rounded-[28px] border-2 transition-all duration-300 p-8 flex flex-col justify-between shadow-[0_12px_36px_-6px_rgba(99,102,241,0.12)] ${
                isFlipped
                  ? 'bg-gradient-to-br from-indigo-50 via-white to-emerald-50 border-indigo-300 ring-2 ring-indigo-400/30'
                  : 'bg-white border-slate-200 hover:border-indigo-300'
              }`}
            >
              {/* Card Header */}
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 rounded-full text-xs font-black bg-indigo-100 text-indigo-800">
                  {CHAPTERS.find((c) => c.id === currentFlashcardQ.chapterId)?.shortTitle}
                </span>
                <span className="text-xs text-indigo-600 font-bold flex items-center gap-1.5">
                  <RotateCcw className="w-4 h-4 text-indigo-500" />
                  Flip Card
                </span>
              </div>

              {/* Card Body */}
              {!isFlipped ? (
                /* FRONT */
                <div className="my-auto text-center space-y-3 py-6">
                  <span className="text-xs font-black uppercase tracking-wider text-indigo-600">
                    Term / Concept
                  </span>
                  <h3 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
                    {currentFlashcardQ.term}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto font-medium">
                    Click to reveal NCERT definition, Golden Rule classification, and practical example.
                  </p>
                </div>
              ) : (
                /* BACK */
                <div className="space-y-4 py-2 text-xs">
                  <div>
                    <span className="font-black text-indigo-900 text-sm block mb-1">
                      Definition:
                    </span>
                    <p className="text-slate-700 leading-relaxed text-sm font-medium">
                      {currentFlashcardQ.flashcard.definition}
                    </p>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-3 pt-2">
                    <div className="p-3.5 rounded-2xl bg-white border-2 border-emerald-100 shadow-xs">
                      <span className="font-black text-emerald-700 block mb-1">Practical Example:</span>
                      <p className="text-slate-600 text-xs leading-relaxed font-medium">
                        {currentFlashcardQ.flashcard.example}
                      </p>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-white border-2 border-amber-100 shadow-xs">
                      <span className="font-black text-amber-700 block mb-1">Golden Rule / Logic:</span>
                      <p className="text-slate-600 text-xs leading-relaxed font-medium">
                        {currentFlashcardQ.flashcard.goldenRule}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Card Footer */}
              <div className="pt-4 border-t-2 border-slate-100 flex items-center justify-between text-xs font-semibold text-slate-400">
                <span className="font-mono text-[11px]">NCERT Ref: {currentFlashcardQ.ncertReference}</span>
                <span className="text-indigo-600 font-bold">Touch anywhere to flip</span>
              </div>
            </div>
          </div>

          {/* Flashcard Navigation */}
          <div className="flex items-center justify-center gap-3 pt-2">
            <button
              onClick={() => {
                sound.playClick();
                setIsFlipped(false);
                setFlashcardIndex((prev) => (prev > 0 ? prev - 1 : questions.length - 1));
              }}
              className="btn-tactile px-4 py-2 rounded-2xl bg-white hover:bg-slate-50 border-2 border-slate-200 border-b-4 border-b-slate-300 active:border-b-2 text-slate-700 transition-all flex items-center gap-1.5 text-xs font-black shadow-xs"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                setIsFlipped(!isFlipped);
              }}
              className="btn-tactile px-5 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black border-b-4 border-indigo-800 active:border-b-0 transition-all shadow-sm"
            >
              Flip Current Card
            </button>

            <button
              onClick={() => {
                sound.playClick();
                setIsFlipped(false);
                setFlashcardIndex((prev) => (prev + 1) % questions.length);
              }}
              className="btn-tactile px-4 py-2 rounded-2xl bg-white hover:bg-slate-50 border-2 border-slate-200 border-b-4 border-b-slate-300 active:border-b-2 text-slate-700 transition-all flex items-center gap-1.5 text-xs font-black shadow-xs"
            >
              <span>Next</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
