import React, { useState, useEffect } from 'react';
import { Chapter } from '../../types.ts';
import { CHAPTERS, GOLDEN_RULES_SUMMARY } from '../../data.ts';
import { GLOSSARY_TERMS } from '../../glossaryData.ts';
import { X, BookOpen, Sparkles, Scale, Search, CheckCircle, BookMarked, ArrowUpRight } from 'lucide-react';

interface StudyGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialChapterId?: number;
  onOpenGlossaryTerm?: (termName: string) => void;
}

export const StudyGuideModal: React.FC<StudyGuideModalProps> = ({ 
  isOpen, 
  onClose,
  initialChapterId = 1,
  onOpenGlossaryTerm
}) => {
  const [selectedChapterId, setSelectedChapterId] = useState<number>(initialChapterId);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'chapters' | 'goldenRules' | 'formulas' | 'glossary'>('chapters');

  useEffect(() => {
    if (initialChapterId) {
      setSelectedChapterId(initialChapterId);
    }
  }, [initialChapterId]);

  if (!isOpen) return null;

  const currentChapter = CHAPTERS.find((c) => c.id === selectedChapterId) || CHAPTERS[0];
  const chapterGlossaryItems = GLOSSARY_TERMS.filter((g) => g.chapterId === currentChapter.id);

  const filteredChapters = CHAPTERS.filter((c) =>
    c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.keyConcepts.some((k) => k.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white border-2 border-indigo-100 rounded-[28px] w-full max-w-4xl max-h-[90vh] flex flex-col shadow-[0_20px_50px_rgba(0,0,0,0.15)] overflow-hidden text-slate-800">
        {/* Header */}
        <div className="px-6 py-4 border-b-2 border-slate-100 flex items-center justify-between bg-slate-50/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-indigo-50 border-2 border-indigo-100 text-indigo-700 shadow-xs">
              <BookOpen className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <h2 className="text-lg font-black text-slate-900">NCERT Class 11 Accounting Handbook</h2>
              <p className="text-xs text-slate-500 font-medium">Fast revision summaries, golden rules & adjustment cheat-sheets</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-400 hover:text-slate-700 border border-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 pt-3 border-b-2 border-slate-100 flex gap-2 overflow-x-auto text-xs font-bold">
          <button
            onClick={() => setActiveTab('chapters')}
            className={`px-4 py-2 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'chapters'
                ? 'border-indigo-600 text-indigo-700 font-black'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Chapter Revisions</span>
          </button>
          <button
            onClick={() => setActiveTab('goldenRules')}
            className={`px-4 py-2 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'goldenRules'
                ? 'border-indigo-600 text-indigo-700 font-black'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Scale className="w-4 h-4" />
            <span>Golden Rules</span>
          </button>
          <button
            onClick={() => setActiveTab('formulas')}
            className={`px-4 py-2 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'formulas'
                ? 'border-indigo-600 text-indigo-700 font-black'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Core Formulas</span>
          </button>
          <button
            onClick={() => setActiveTab('glossary')}
            className={`px-4 py-2 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'glossary'
                ? 'border-indigo-600 text-indigo-700 font-black'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <BookMarked className="w-4 h-4" />
            <span>Glossary Rules</span>
          </button>
        </div>

        {/* Tab 1: Chapters Review */}
        {activeTab === 'chapters' && (
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden min-h-0">
            {/* Sidebar Chapter List */}
            <div className="w-full md:w-72 border-r-2 border-slate-100 p-3.5 flex flex-col bg-slate-50/50 overflow-y-auto">
              <div className="relative mb-2.5">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search chapters..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-white border border-slate-200 text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500 shadow-xs"
                />
              </div>

              <div className="space-y-1">
                {filteredChapters.map((ch: Chapter) => (
                  <button
                    key={ch.id}
                    onClick={() => setSelectedChapterId(ch.id)}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-between ${
                      selectedChapterId === ch.id
                        ? 'bg-indigo-50 border border-indigo-200 text-indigo-800 shadow-xs'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <span className="truncate">{ch.shortTitle}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-slate-200/80 text-slate-600">
                      Ch {ch.chapterNumber}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Chapter Detail View */}
            <div className="flex-1 p-6 overflow-y-auto space-y-4">
              <div>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-emerald-100 text-emerald-800 border border-emerald-200">
                  {currentChapter.category}
                </span>
                <h3 className="text-xl font-black text-slate-900 mt-1.5">
                  {currentChapter.title}
                </h3>
                <p className="text-xs text-slate-500 mt-1 font-medium">{currentChapter.description}</p>
              </div>

              {currentChapter.goldenRulesHighlight && (
                <div className="p-4 rounded-2xl bg-indigo-50/70 border-2 border-indigo-100 text-indigo-950 text-xs">
                  <span className="font-black text-indigo-700 block mb-1">💡 Golden Rule / Key Axiom:</span>
                  <p className="leading-relaxed font-semibold">{currentChapter.goldenRulesHighlight}</p>
                </div>
              )}

              <div>
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 mb-2">
                  Key Examination Takeaways & Concepts
                </h4>
                <div className="grid gap-2">
                  {currentChapter.keyConcepts.map((concept, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 rounded-2xl bg-white border border-slate-200 text-xs text-slate-700 flex items-start gap-2.5 shadow-xs font-medium"
                    >
                      <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                      <span>{concept}</span>
                    </div>
                  ))}
                </div>
              </div>

              {chapterGlossaryItems.length > 0 && (
                <div className="pt-2">
                  <h4 className="text-xs font-black uppercase tracking-wider text-indigo-700 mb-2 flex items-center justify-between">
                    <span>Chapter Key Accounting Terms & Rules</span>
                    <span className="text-xs text-slate-400 font-semibold">
                      {chapterGlossaryItems.length} Terms
                    </span>
                  </h4>
                  <div className="grid gap-2.5">
                    {chapterGlossaryItems.map((item) => (
                      <div
                        key={item.id}
                        className="p-4 rounded-2xl bg-white border border-slate-200 text-xs space-y-1.5 shadow-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-900 flex items-center gap-2">
                            {item.term}
                            <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-semibold">
                              {item.category}
                            </span>
                          </span>
                          {onOpenGlossaryTerm && (
                            <button
                              onClick={() => {
                                onOpenGlossaryTerm(item.term);
                                onClose();
                              }}
                              className="text-xs text-indigo-600 hover:text-indigo-800 flex items-center gap-1 font-bold"
                            >
                              <span>View Rule</span>
                              <ArrowUpRight className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                        <p className="text-slate-600 leading-relaxed text-xs font-medium">{item.definition}</p>
                        <div className="pt-1 text-[11px] text-indigo-600 font-mono font-bold">
                          Ref: {item.ncertGuideline}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 2: Golden Rules of Double Entry */}
        {activeTab === 'goldenRules' && (
          <div className="p-6 overflow-y-auto space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              {GOLDEN_RULES_SUMMARY.map((rule, idx) => (
                <div
                  key={idx}
                  className="p-5 rounded-2xl bg-white border-2 border-slate-100 hover:border-indigo-200 transition-all shadow-xs"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-black px-2.5 py-0.5 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700">
                      {rule.category}
                    </span>
                  </div>
                  <h4 className="text-sm font-black text-emerald-700 mb-2">
                    {rule.rule}
                  </h4>
                  <div className="space-y-2 text-xs text-slate-600 font-medium">
                    <p>
                      <strong className="text-slate-700">Covers:</strong> {rule.appliesTo}
                    </p>
                    <p className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-700">
                      <strong className="text-indigo-700">Example:</strong> {rule.examples}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-200 text-xs font-medium">
              <h4 className="font-black text-amber-900 mb-1">Exam Memory Tip: CLEAR Modern Approach</h4>
              <p className="text-amber-900 leading-relaxed">
                When using the American/Modern rule: <strong>C</strong>apital (Cr), <strong>L</strong>iabilities (Cr), <strong>E</strong>xpenses (Dr), <strong>A</strong>ssets (Dr), <strong>R</strong>evenue (Cr).
                Increases in Assets and Expenses are <strong>DEBITED</strong>. Increases in Liabilities, Capital, and Revenue are <strong>CREDITED</strong>.
              </p>
            </div>
          </div>
        )}

        {/* Tab 3: Core Formulas */}
        {activeTab === 'formulas' && (
          <div className="p-6 overflow-y-auto space-y-4 text-xs font-medium">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="p-5 rounded-2xl bg-white border-2 border-slate-100 shadow-xs">
                <span className="font-black text-indigo-700 text-sm block mb-1">Fundamental Accounting Equation</span>
                <code className="block p-3 rounded-xl bg-slate-50 border border-slate-200 font-mono text-emerald-700 font-bold my-2">
                  Assets = Liabilities + Capital
                </code>
                <p className="text-slate-500">
                  Expanded: Assets = Liabilities + Opening Capital + Additional Capital + Net Profit (or - Loss) - Drawings.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-white border-2 border-slate-100 shadow-xs">
                <span className="font-black text-indigo-700 text-sm block mb-1">Cost of Goods Sold (COGS)</span>
                <code className="block p-3 rounded-xl bg-slate-50 border border-slate-200 font-mono text-emerald-700 font-bold my-2">
                  COGS = Opening Stock + Net Purchases + Direct Expenses - Closing Stock
                </code>
                <p className="text-slate-500">
                  Alternatively: COGS = Net Sales - Gross Profit. Direct expenses include wages, carriage inwards, and factory power.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-white border-2 border-slate-100 shadow-xs">
                <span className="font-black text-indigo-700 text-sm block mb-1">Adjusted Sundry Debtors & Provision</span>
                <code className="block p-3 rounded-xl bg-slate-50 border border-slate-200 font-mono text-emerald-700 font-bold my-2">
                  Net Debtors = Gross Debtors - Further Bad Debts - Provision for Doubtful Debts
                </code>
                <p className="text-slate-500">
                  Always subtract further bad debts before calculating percentage provision on remaining good debtors!
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-white border-2 border-slate-100 shadow-xs">
                <span className="font-black text-indigo-700 text-sm block mb-1">Petty Cash Imprest Float</span>
                <code className="block p-3 rounded-xl bg-slate-50 border border-slate-200 font-mono text-emerald-700 font-bold my-2">
                  Reimbursement = Exact Vouched Petty Payments during the period
                </code>
                <p className="text-slate-500">
                  Head Cashier gives cash equal to total expenses to restore the petty cashier’s float back to the fixed imprest sum.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: All NCERT Glossary Terms */}
        {activeTab === 'glossary' && (
          <div className="p-6 overflow-y-auto space-y-3.5 text-xs">
            <div className="flex items-center justify-between pb-2 border-b-2 border-slate-100">
              <span className="font-black text-slate-800">
                All Course Accounting Terms & NCERT Guidelines ({GLOSSARY_TERMS.length})
              </span>
              <span className="text-xs text-slate-400 font-medium">
                Click any term to view its rule citations
              </span>
            </div>

            <div className="grid sm:grid-cols-2 gap-3.5">
              {GLOSSARY_TERMS.map((term) => (
                <div
                  key={term.id}
                  className="p-4 rounded-2xl bg-white border-2 border-slate-100 hover:border-indigo-200 transition-all flex flex-col justify-between space-y-2 shadow-xs"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <h4 className="font-black text-indigo-700 text-sm">{term.term}</h4>
                      <span className="text-[10px] px-2 py-0.5 rounded-md font-bold bg-slate-100 text-slate-600">
                        {term.category}
                      </span>
                    </div>
                    <p className="text-slate-600 leading-relaxed text-xs line-clamp-3 font-medium">
                      {term.definition}
                    </p>
                  </div>

                  <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] font-semibold">
                    <span className="text-slate-400 font-mono truncate max-w-[180px]">
                      {term.ncertGuideline}
                    </span>
                    {onOpenGlossaryTerm && (
                      <button
                        onClick={() => {
                          onOpenGlossaryTerm(term.term);
                          onClose();
                        }}
                        className="text-indigo-600 hover:text-indigo-800 font-bold flex items-center gap-1"
                      >
                        <span>Open Details</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t-2 border-slate-100 bg-slate-50/60 flex justify-end">
          <button
            onClick={onClose}
            className="btn-tactile px-5 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black border-b-4 border-indigo-800 active:border-b-0 shadow-sm"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
