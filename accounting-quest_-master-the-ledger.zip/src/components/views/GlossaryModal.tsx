import React, { useState, useMemo } from 'react';
import { GlossaryItem } from '../../types.ts';
import { GLOSSARY_TERMS } from '../../glossaryData.ts';
import { 
  X, 
  Search, 
  BookMarked, 
  ExternalLink, 
  FileText, 
  Sparkles, 
  Filter, 
  Play, 
  ChevronRight,
  Lightbulb,
  CheckCircle2,
  GraduationCap
} from 'lucide-react';

interface GlossaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectChapterAndPlay?: (level: 1 | 2 | 3 | 4) => void;
  onOpenStudyGuideWithChapter?: (chapterId: number) => void;
  initialTermQuery?: string;
}

export const GlossaryModal: React.FC<GlossaryModalProps> = ({
  isOpen,
  onClose,
  onSelectChapterAndPlay,
  onOpenStudyGuideWithChapter,
  initialTermQuery = '',
}) => {
  const [searchQuery, setSearchQuery] = useState<string>(initialTermQuery);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedChapterFilter, setSelectedChapterFilter] = useState<number | 'All'>('All');
  const [activeItem, setActiveItem] = useState<GlossaryItem>(GLOSSARY_TERMS[0]);

  // Sync if initialTermQuery changes
  React.useEffect(() => {
    if (initialTermQuery) {
      setSearchQuery(initialTermQuery);
      const matched = GLOSSARY_TERMS.find((t) =>
        t.term.toLowerCase().includes(initialTermQuery.toLowerCase())
      );
      if (matched) setActiveItem(matched);
    }
  }, [initialTermQuery]);

  const categories = useMemo(() => {
    const set = new Set(GLOSSARY_TERMS.map((t) => t.category));
    return ['All', ...Array.from(set)];
  }, []);

  const chaptersList = useMemo(() => {
    const map = new Map<number, string>();
    GLOSSARY_TERMS.forEach((t) => {
      if (!map.has(t.chapterId)) {
        map.set(t.chapterId, t.chapterName);
      }
    });
    return Array.from(map.entries());
  }, []);

  const filteredTerms = useMemo(() => {
    return GLOSSARY_TERMS.filter((item) => {
      const matchesSearch =
        item.term.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.definition.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.ncertGuideline.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.chapterName.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesCategory =
        selectedCategory === 'All' || item.category === selectedCategory;

      const matchesChapter =
        selectedChapterFilter === 'All' || item.chapterId === selectedChapterFilter;

      return matchesSearch && matchesCategory && matchesChapter;
    });
  }, [searchQuery, selectedCategory, selectedChapterFilter]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white border-2 border-indigo-100 rounded-[28px] w-full max-w-5xl h-[88vh] flex flex-col shadow-[0_20px_50px_rgba(0,0,0,0.15)] overflow-hidden text-slate-800">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b-2 border-slate-100 flex items-center justify-between bg-slate-50/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-indigo-50 border-2 border-indigo-100 text-indigo-700 shadow-xs">
              <BookMarked className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-slate-900">NCERT Accounting Glossary & Reference</h2>
                <span className="text-[11px] px-2.5 py-0.5 rounded-full font-black bg-indigo-100 text-indigo-700">
                  {filteredTerms.length} Terms
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Official definitions, dual effects, golden rules & chapter citations
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-400 hover:text-slate-700 border border-slate-200 transition-colors"
              title="Close Glossary"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="px-6 py-3 bg-slate-50/50 border-b-2 border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Search Input */}
          <div className="relative flex-1 min-w-[220px]">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search by term, concept, rule, or NCERT section..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-8 py-2 rounded-xl bg-white border border-slate-200 text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500 shadow-xs transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Category Filter Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto max-w-full">
            <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span className="text-slate-500 shrink-0 font-semibold">Category:</span>
            {categories.slice(0, 6).map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`btn-tactile px-3 py-1 rounded-xl text-xs font-bold transition-all ${
                  selectedCategory === cat
                    ? 'bg-indigo-600 text-white font-black shadow-xs'
                    : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Chapter Selector Dropdown */}
          <div className="flex items-center gap-1.5">
            <select
              value={selectedChapterFilter}
              onChange={(e) =>
                setSelectedChapterFilter(
                  e.target.value === 'All' ? 'All' : Number(e.target.value)
                )
              }
              className="px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-700 font-semibold focus:outline-none focus:border-indigo-500 text-xs shadow-xs"
            >
              <option value="All">All Chapters</option>
              {chaptersList.map(([id, title]) => (
                <option key={id} value={id}>
                  {title}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Master Detail View: List on left, Rich Card on right */}
        <div className="flex-1 flex flex-col md:flex-row min-h-0 overflow-hidden">
          {/* Left: Scrollable Term List */}
          <div className="w-full md:w-80 border-r-2 border-slate-100 bg-slate-50/40 overflow-y-auto p-3.5 space-y-2">
            {filteredTerms.length === 0 ? (
              <div className="p-6 text-center text-slate-400 text-xs font-medium">
                No matching accounting terms found.
              </div>
            ) : (
              filteredTerms.map((t) => {
                const isSelected = activeItem?.id === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => setActiveItem(t)}
                    className={`w-full text-left p-3.5 rounded-2xl border-2 transition-all duration-150 flex flex-col gap-1 ${
                      isSelected
                        ? 'bg-white border-indigo-500 text-indigo-950 shadow-sm ring-2 ring-indigo-500/10'
                        : 'bg-white/80 border-slate-100 hover:border-slate-300 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-xs truncate max-w-[180px]">
                        {t.term}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-md font-bold bg-slate-100 text-slate-600">
                        {t.category}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 truncate font-medium">
                      {t.chapterName}
                    </span>
                  </button>
                );
              })
            )}
          </div>

          {/* Right: Full Detail Content */}
          {activeItem ? (
            <div className="flex-1 p-6 sm:p-8 overflow-y-auto space-y-5">
              {/* Term Header & Badges */}
              <div className="space-y-3 pb-4 border-b-2 border-slate-100">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full text-xs font-black bg-indigo-100 text-indigo-800">
                      {activeItem.category} Account / Rule
                    </span>
                    <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-600">
                      Ch {activeItem.chapterId}
                    </span>
                  </div>

                  {activeItem.relatedLevel && onSelectChapterAndPlay && (
                    <button
                      onClick={() => {
                        onSelectChapterAndPlay(activeItem.relatedLevel!);
                        onClose();
                      }}
                      className="btn-tactile px-4 py-2 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-xs border-b-4 border-emerald-700 active:border-b-0 shadow-sm flex items-center gap-1.5"
                    >
                      <Play className="w-3.5 h-3.5 fill-white" />
                      <span>Practice in Level {activeItem.relatedLevel}</span>
                    </button>
                  )}
                </div>

                <h3 className="text-2xl sm:text-3xl font-black text-slate-900">
                  {activeItem.term}
                </h3>

                {/* Direct NCERT Guideline Link */}
                <div className="p-3 rounded-2xl bg-indigo-50/70 border border-indigo-100 flex items-center justify-between text-xs text-indigo-900 font-medium">
                  <div className="flex items-center gap-2 font-mono text-[11px] font-bold">
                    <GraduationCap className="w-4 h-4 text-indigo-600" />
                    <span>Official Reference: {activeItem.ncertGuideline}</span>
                  </div>

                  {onOpenStudyGuideWithChapter && (
                    <button
                      onClick={() => {
                        onOpenStudyGuideWithChapter(activeItem.chapterId);
                        onClose();
                      }}
                      className="text-xs font-bold text-indigo-600 hover:text-indigo-800 underline flex items-center gap-1"
                    >
                      <span>Read Chapter Summary</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Definition Box */}
              <div className="space-y-1.5">
                <span className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-indigo-600" />
                  Official Definition & Conceptual Essence
                </span>
                <p className="text-sm sm:text-base text-slate-800 leading-relaxed p-5 rounded-2xl bg-slate-50 border-2 border-slate-100 font-medium">
                  {activeItem.definition}
                </p>
              </div>

              {/* Golden Rule or Formula Highlight */}
              {activeItem.goldenRuleOrFormula && (
                <div className="p-4 sm:p-5 rounded-2xl bg-indigo-50/60 border-2 border-indigo-100 space-y-1.5">
                  <span className="text-xs font-black uppercase tracking-wider text-indigo-700 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                    Golden Rule / Mathematical Axiom
                  </span>
                  <p className="text-xs sm:text-sm font-bold text-indigo-950 font-mono">
                    {activeItem.goldenRuleOrFormula}
                  </p>
                </div>
              )}

              {/* Grid: Practical Example & Exam Warning */}
              <div className="grid sm:grid-cols-2 gap-4 text-xs font-medium">
                <div className="p-4 rounded-2xl bg-white border-2 border-emerald-100 shadow-xs space-y-1.5">
                  <span className="font-black text-emerald-700 flex items-center gap-1.5 text-xs uppercase tracking-wide">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Practical Working Example
                  </span>
                  <p className="text-slate-600 leading-relaxed text-xs">
                    {activeItem.practicalExample}
                  </p>
                </div>

                {activeItem.examTip && (
                  <div className="p-4 rounded-2xl bg-white border-2 border-amber-100 shadow-xs space-y-1.5">
                    <span className="font-black text-amber-700 flex items-center gap-1.5 text-xs uppercase tracking-wide">
                      <Lightbulb className="w-4 h-4 text-amber-500" />
                      CBSE / State Board Exam Tip
                    </span>
                    <p className="text-slate-600 leading-relaxed text-xs">
                      {activeItem.examTip}
                    </p>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center p-8 text-slate-400 text-xs">
              Select any term from the list to view its official NCERT definition and guideline.
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t-2 border-slate-100 bg-slate-50/60 flex items-center justify-between text-xs text-slate-500 font-medium">
          <span>NCERT Guidelines & Educational Reference Handbook</span>
          <button
            onClick={onClose}
            className="btn-tactile px-5 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs border-b-4 border-indigo-800 active:border-b-0 shadow-sm"
          >
            Close Glossary
          </button>
        </div>
      </div>
    </div>
  );
};
