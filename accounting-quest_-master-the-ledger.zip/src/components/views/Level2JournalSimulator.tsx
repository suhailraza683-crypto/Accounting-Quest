import React, { useState, useMemo } from 'react';
import { JournalQuestion, LifelineState } from '../../types.ts';
import { JOURNAL_QUESTIONS, CHAPTERS } from '../../data.ts';
import { 
  ArrowLeft, 
  HelpCircle, 
  SkipForward, 
  Percent, 
  CheckCircle, 
  XCircle, 
  Flame, 
  Award, 
  ChevronRight,
  FileSpreadsheet,
  Receipt,
  Lightbulb,
  BookMarked
} from 'lucide-react';

interface Level2JournalSimulatorProps {
  selectedChapterIds: number[];
  onReturnHome: () => void;
  recordAnswer: (isCorrect: boolean, baseScore?: number, baseExp?: number) => void;
  updateHighScore: (level: 'level2', score: number) => void;
  currentStreak: number;
  currentMultiplier: number;
  sound: {
    playCorrect: () => void;
    playWrong: () => void;
    playCombo: () => void;
    playClick: () => void;
  };
  onOpenGlossary?: (termQuery?: string) => void;
}

export const Level2JournalSimulator: React.FC<Level2JournalSimulatorProps> = ({
  selectedChapterIds,
  onReturnHome,
  recordAnswer,
  updateHighScore,
  currentStreak,
  currentMultiplier,
  sound,
  onOpenGlossary,
}) => {
  const questions: JournalQuestion[] = useMemo(() => {
    const filtered = JOURNAL_QUESTIONS.filter((q) => selectedChapterIds.includes(q.chapterId));
    return filtered.length > 0 ? filtered : JOURNAL_QUESTIONS;
  }, [selectedChapterIds]);

  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedDebit, setSelectedDebit] = useState<string | null>(null);
  const [selectedCredit, setSelectedCredit] = useState<string | null>(null);
  const [selectedVoucher, setSelectedVoucher] = useState<string | null>(null);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [levelScore, setLevelScore] = useState<number>(0);

  // Lifelines
  const [lifelines, setLifelines] = useState<LifelineState>({
    fiftyFiftyUsed: false,
    hintUsed: false,
    skipUsed: false,
  });
  const [showHint, setShowHint] = useState<boolean>(false);
  const [disabledOptions, setDisabledOptions] = useState<{
    debit: string[];
    credit: string[];
  }>({ debit: [], credit: [] });

  const currentQ = questions[currentIndex % questions.length];
  const currentChapter = CHAPTERS.find((c) => c.id === currentQ.chapterId);

  const isDebitCorrect = selectedDebit === currentQ.correctDebit;
  const isCreditCorrect = selectedCredit === currentQ.correctCredit;
  const isVoucherCorrect = selectedVoucher === currentQ.correctVoucher;
  const isAllCorrect = isDebitCorrect && isCreditCorrect && isVoucherCorrect;

  const handleSubmit = () => {
    if (!selectedDebit || !selectedCredit || !selectedVoucher || isSubmitted) return;
    setIsSubmitted(true);

    if (isAllCorrect) {
      sound.playCorrect();
      if ((currentStreak + 1) % 3 === 0) sound.playCombo();
      const earned = Math.round(250 * currentMultiplier);
      setLevelScore((prev) => {
        const next = prev + earned;
        updateHighScore('level2', next);
        return next;
      });
      recordAnswer(true, 250, 45);
    } else {
      sound.playWrong();
      recordAnswer(false);
    }
  };

  const handleNextQuestion = () => {
    sound.playClick();
    setSelectedDebit(null);
    setSelectedCredit(null);
    setSelectedVoucher(null);
    setIsSubmitted(false);
    setShowHint(false);
    setDisabledOptions({ debit: [], credit: [] });
    setCurrentIndex((prev) => prev + 1);
  };

  // Lifelines
  const useFiftyFifty = () => {
    if (lifelines.fiftyFiftyUsed || isSubmitted) return;
    sound.playClick();
    const wrongDebits = currentQ.optionsDebit.filter((d) => d !== currentQ.correctDebit).slice(0, 2);
    const wrongCredits = currentQ.optionsCredit.filter((c) => c !== currentQ.correctCredit).slice(0, 2);
    setDisabledOptions({ debit: wrongDebits, credit: wrongCredits });
    setLifelines((prev) => ({ ...prev, fiftyFiftyUsed: true }));
  };

  const useHint = () => {
    if (lifelines.hintUsed) return;
    sound.playClick();
    setShowHint(true);
    setLifelines((prev) => ({ ...prev, hintUsed: true }));
  };

  const useSkip = () => {
    if (lifelines.skipUsed) return;
    sound.playClick();
    setLifelines((prev) => ({ ...prev, skipUsed: true }));
    handleNextQuestion();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b-2 border-slate-200">
        <button
          onClick={onReturnHome}
          className="btn-tactile flex items-center gap-1.5 px-3.5 py-1.5 rounded-2xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold border-2 border-slate-200 border-b-4 border-b-slate-300 active:border-b-2 transition-all shadow-xs"
        >
          <ArrowLeft className="w-4 h-4 text-emerald-600" />
          <span>Back to Menu</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 rounded-2xl text-xs font-black bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1.5 shadow-xs">
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Level 2: Journal & Voucher Simulator</span>
          </span>
        </div>

        <div className="flex items-center gap-3 text-xs font-bold">
          {onOpenGlossary && (
            <button
              onClick={() => onOpenGlossary()}
              className="btn-tactile flex items-center gap-1 px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border-2 border-indigo-200 border-b-4 border-b-indigo-300 active:border-b-2 transition-all shadow-xs"
              title="Open Glossary & Reference"
            >
              <BookMarked className="w-3.5 h-3.5 text-indigo-600" />
              <span className="hidden sm:inline">Glossary</span>
            </button>
          )}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border-2 border-slate-200 text-slate-700 shadow-xs">
            <Award className="w-4 h-4 text-emerald-500" />
            <span className="text-slate-500 font-semibold">Score:</span>
            <span className="font-black text-slate-900">{levelScore}</span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 border-2 border-amber-200 text-amber-900 shadow-xs">
            <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span className="text-amber-700 font-semibold">Streak:</span>
            <span className="font-black text-amber-900">{currentStreak}</span>
          </div>
        </div>
      </div>

      {/* Lifelines Bar */}
      <div className="flex items-center justify-between p-3.5 rounded-2xl bg-white border-2 border-slate-200/80 shadow-xs text-xs font-bold">
        <span className="text-slate-600 font-extrabold flex items-center gap-1.5">
          <span>⚡ Tactical Lifelines:</span>
        </span>
        <div className="flex items-center gap-2">
          <button
            onClick={useFiftyFifty}
            disabled={lifelines.fiftyFiftyUsed || isSubmitted}
            className={`btn-tactile flex items-center gap-1.5 px-3 py-1.5 rounded-xl border-2 transition-all ${
              lifelines.fiftyFiftyUsed
                ? 'opacity-40 border-slate-200 bg-slate-100 text-slate-400 cursor-not-allowed'
                : 'bg-emerald-50 hover:bg-emerald-100 border-emerald-200 border-b-4 border-b-emerald-300 active:border-b-2 text-emerald-800 font-black shadow-xs'
            }`}
            title="Eliminate incorrect options"
          >
            <Percent className="w-3.5 h-3.5" />
            <span>50 / 50</span>
          </button>

          <button
            onClick={useHint}
            disabled={lifelines.hintUsed}
            className={`btn-tactile flex items-center gap-1.5 px-3 py-1.5 rounded-xl border-2 transition-all ${
              lifelines.hintUsed
                ? 'opacity-40 border-slate-200 bg-slate-100 text-slate-400 cursor-not-allowed'
                : 'bg-amber-50 hover:bg-amber-100 border-amber-200 border-b-4 border-b-amber-300 active:border-b-2 text-amber-800 font-black shadow-xs'
            }`}
            title="Show golden rule clues"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Hint</span>
          </button>

          <button
            onClick={useSkip}
            disabled={lifelines.skipUsed}
            className={`btn-tactile flex items-center gap-1.5 px-3 py-1.5 rounded-xl border-2 transition-all ${
              lifelines.skipUsed
                ? 'opacity-40 border-slate-200 bg-slate-100 text-slate-400 cursor-not-allowed'
                : 'bg-white hover:bg-slate-50 border-slate-200 border-b-4 border-b-slate-300 active:border-b-2 text-slate-700 font-black shadow-xs'
            }`}
            title="Skip without penalty"
          >
            <SkipForward className="w-3.5 h-3.5" />
            <span>Skip</span>
          </button>
        </div>
      </div>

      {/* Hint Alert */}
      {showHint && (
        <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-200 text-amber-900 text-xs flex items-start gap-3 animate-fadeIn shadow-xs">
          <Lightbulb className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <strong className="block font-black text-amber-950">Golden Rule Clue:</strong>
            <p className="font-medium">• Debit Clue: {currentQ.debitRule}</p>
            <p className="font-medium">• Credit Clue: {currentQ.creditRule}</p>
          </div>
        </div>
      )}

      {/* Transaction Scenario Card - Arcade Console */}
      <div className="card-bouncy p-6 sm:p-8 rounded-[28px] bg-white border-2 border-emerald-100 shadow-[0_12px_36px_-6px_rgba(16,185,129,0.12)] space-y-4">
        <div className="flex items-center justify-between text-xs font-bold">
          <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200 font-black">
            {currentChapter?.shortTitle || 'Class 11 Journal Entry'}
          </span>
          <span className="text-slate-500 font-mono">
            Transaction {(currentIndex % questions.length) + 1} of {questions.length}
          </span>
        </div>

        {/* Business Event Box */}
        <div className="p-5 rounded-2xl bg-slate-50 border-2 border-slate-200/80 space-y-2">
          <span className="text-xs font-black uppercase tracking-wider text-slate-500 block">
            Business Event / Transaction to Record:
          </span>
          <p className="text-lg sm:text-xl font-black text-slate-900 leading-snug">
            "{currentQ.transaction}"
          </p>
          <span className="inline-block text-xs font-bold px-3 py-1 rounded-lg bg-emerald-100 text-emerald-900 border border-emerald-200">
            Transaction Amount: {currentQ.amount}
          </span>
        </div>

        {/* Step-by-Step Selectors (Tactile 3D Buttons) */}
        <div className="grid md:grid-cols-3 gap-4 pt-2">
          {/* 1. Debit Account */}
          <div className="space-y-2">
            <label className="text-xs font-black text-slate-700 flex items-center justify-between">
              <span>1. Account to DEBIT (Dr.):</span>
              {isSubmitted && (
                isDebitCorrect ? (
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                ) : (
                  <XCircle className="w-4 h-4 text-rose-600" />
                )
              )}
            </label>
            <div className="space-y-2">
              {currentQ.optionsDebit.map((opt, i) => {
                const isSelected = selectedDebit === opt;
                const isDisabled = disabledOptions.debit.includes(opt);
                return (
                  <button
                    key={i}
                    disabled={isSubmitted || isDisabled}
                    onClick={() => {
                      sound.playClick();
                      setSelectedDebit(opt);
                    }}
                    className={`btn-tactile w-full text-left p-3 rounded-2xl text-xs font-bold border-2 transition-all ${
                      isSelected
                        ? isSubmitted
                          ? isDebitCorrect
                            ? 'bg-emerald-50 border-emerald-500 border-b-4 border-b-emerald-600 text-emerald-950 font-black animate-pop-correct'
                            : 'bg-rose-50 border-rose-500 border-b-4 border-b-rose-600 text-rose-950 font-black animate-shake-wrong'
                          : 'bg-indigo-50 border-indigo-500 border-b-4 border-b-indigo-700 text-indigo-950 font-black shadow-xs'
                        : isSubmitted && opt === currentQ.correctDebit
                        ? 'bg-emerald-50 border-emerald-400 text-emerald-900'
                        : isDisabled
                        ? 'opacity-30 border-slate-200 bg-slate-100 text-slate-400'
                        : 'bg-white hover:bg-slate-50 border-slate-200 border-b-4 border-b-slate-300 text-slate-800 shadow-xs'
                    }`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Credit Account */}
          <div className="space-y-2">
            <label className="text-xs font-black text-slate-700 flex items-center justify-between">
              <span>2. Account to CREDIT (Cr.):</span>
              {isSubmitted && (
                isCreditCorrect ? (
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                ) : (
                  <XCircle className="w-4 h-4 text-rose-600" />
                )
              )}
            </label>
            <div className="space-y-2">
              {currentQ.optionsCredit.map((opt, i) => {
                const isSelected = selectedCredit === opt;
                const isDisabled = disabledOptions.credit.includes(opt);
                return (
                  <button
                    key={i}
                    disabled={isSubmitted || isDisabled}
                    onClick={() => {
                      sound.playClick();
                      setSelectedCredit(opt);
                    }}
                    className={`btn-tactile w-full text-left p-3 rounded-2xl text-xs font-bold border-2 transition-all ${
                      isSelected
                        ? isSubmitted
                          ? isCreditCorrect
                            ? 'bg-emerald-50 border-emerald-500 border-b-4 border-b-emerald-600 text-emerald-950 font-black animate-pop-correct'
                            : 'bg-rose-50 border-rose-500 border-b-4 border-b-rose-600 text-rose-950 font-black animate-shake-wrong'
                          : 'bg-indigo-50 border-indigo-500 border-b-4 border-b-indigo-700 text-indigo-950 font-black shadow-xs'
                        : isSubmitted && opt === currentQ.correctCredit
                        ? 'bg-emerald-50 border-emerald-400 text-emerald-900'
                        : isDisabled
                        ? 'opacity-30 border-slate-200 bg-slate-100 text-slate-400'
                        : 'bg-white hover:bg-slate-50 border-slate-200 border-b-4 border-b-slate-300 text-slate-800 shadow-xs'
                    }`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3. Source Document / Voucher */}
          <div className="space-y-2">
            <label className="text-xs font-black text-slate-700 flex items-center justify-between">
              <span>3. Applicable Voucher / Source:</span>
              {isSubmitted && (
                isVoucherCorrect ? (
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                ) : (
                  <XCircle className="w-4 h-4 text-rose-600" />
                )
              )}
            </label>
            <div className="space-y-2">
              {currentQ.optionsVoucher.map((opt, i) => {
                const isSelected = selectedVoucher === opt;
                return (
                  <button
                    key={i}
                    disabled={isSubmitted}
                    onClick={() => {
                      sound.playClick();
                      setSelectedVoucher(opt);
                    }}
                    className={`btn-tactile w-full text-left p-3 rounded-2xl text-xs font-bold border-2 transition-all ${
                      isSelected
                        ? isSubmitted
                          ? isVoucherCorrect
                            ? 'bg-emerald-50 border-emerald-500 border-b-4 border-b-emerald-600 text-emerald-950 font-black animate-pop-correct'
                            : 'bg-rose-50 border-rose-500 border-b-4 border-b-rose-600 text-rose-950 font-black animate-shake-wrong'
                          : 'bg-indigo-50 border-indigo-500 border-b-4 border-b-indigo-700 text-indigo-950 font-black shadow-xs'
                        : isSubmitted && opt === currentQ.correctVoucher
                        ? 'bg-emerald-50 border-emerald-400 text-emerald-900'
                        : 'bg-white hover:bg-slate-50 border-slate-200 border-b-4 border-b-slate-300 text-slate-800 shadow-xs'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Receipt className="w-4 h-4 shrink-0 text-slate-400" />
                      <span className="truncate">{opt}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Action Button */}
        {!isSubmitted ? (
          <div className="pt-3 flex justify-end">
            <button
              onClick={handleSubmit}
              disabled={!selectedDebit || !selectedCredit || !selectedVoucher}
              className={`btn-tactile px-7 py-3 rounded-2xl font-black text-xs transition-all shadow-sm ${
                selectedDebit && selectedCredit && selectedVoucher
                  ? 'bg-emerald-500 hover:bg-emerald-600 text-white border-b-4 border-emerald-700 active:border-b-0'
                  : 'bg-slate-100 text-slate-400 cursor-not-allowed border-2 border-slate-200'
              }`}
            >
              Verify & Post Journal Entry 🚀
            </button>
          </div>
        ) : (
          /* Live Simulated Journal Ledger Table */
          <div className="pt-4 border-t-2 border-slate-100 space-y-4 animate-fadeIn">
            <div>
              <span className="text-xs font-black uppercase tracking-wider text-slate-600 block mb-2">
                Simulated Journal Book Entry:
              </span>
              <div className="overflow-x-auto rounded-2xl border-2 border-slate-200 bg-white shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b-2 border-slate-200 text-slate-600 font-mono text-[11px] font-bold">
                    <tr>
                      <th className="p-3 w-16">Date</th>
                      <th className="p-3">Particulars</th>
                      <th className="p-3 w-12 text-center">L.F.</th>
                      <th className="p-3 w-28 text-right">Debit ($)</th>
                      <th className="p-3 w-28 text-right">Credit ($)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    <tr>
                      <td className="p-3 text-slate-400">2024</td>
                      <td className="p-3 text-emerald-700 font-bold">
                        {currentQ.correctDebit} ...Dr.
                      </td>
                      <td className="p-3 text-slate-400 text-center">—</td>
                      <td className="p-3 text-right text-emerald-600 font-bold">{currentQ.amount}</td>
                      <td className="p-3 text-right text-slate-400">—</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-slate-400"></td>
                      <td className="p-3 text-indigo-700 font-bold pl-6">
                        To {currentQ.correctCredit}
                      </td>
                      <td className="p-3 text-slate-400 text-center">—</td>
                      <td className="p-3 text-right text-slate-400">—</td>
                      <td className="p-3 text-right text-indigo-600 font-bold">{currentQ.amount}</td>
                    </tr>
                    <tr className="bg-slate-50/60 text-[11px] text-slate-500 italic">
                      <td></td>
                      <td colSpan={4} className="p-2.5 pl-6">
                        (Being {currentQ.transaction})
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Explanation card */}
            <div
              className={`p-5 rounded-2xl border-2 space-y-2 text-xs font-medium ${
                isAllCorrect
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-950 animate-pop-correct'
                  : 'bg-amber-50 border-amber-300 text-amber-950 animate-shake-wrong'
              }`}
            >
              <div className="flex items-center gap-2">
                {isAllCorrect ? (
                  <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
                ) : (
                  <XCircle className="w-5 h-5 text-amber-600 shrink-0" />
                )}
                <h4 className="font-black text-sm sm:text-base">
                  {isAllCorrect
                    ? `🎉 Flawless Ledger Posting! +${Math.round(250 * currentMultiplier)} Points`
                    : '💡 Posting Analysis & Correction'}
                </h4>
              </div>

              <p className="leading-relaxed">{currentQ.explanation}</p>
              
              <div className="pt-1 text-[11px] space-y-0.5 font-mono text-slate-700 font-bold">
                <p>• Debit Rule: {currentQ.debitRule}</p>
                <p>• Credit Rule: {currentQ.creditRule}</p>
                <p>• Document: {currentQ.correctVoucher}</p>
              </div>

              {onOpenGlossary && (
                <div className="pt-2.5 border-t border-slate-200/80 flex flex-wrap items-center gap-2 text-[11px] font-bold">
                  <span className="text-slate-500">Glossary References:</span>
                  <button
                    onClick={() => onOpenGlossary(currentQ.correctDebit)}
                    className="btn-tactile px-2.5 py-1 rounded-xl bg-white hover:bg-slate-50 text-indigo-700 border border-indigo-200 shadow-xs"
                  >
                    Dr: {currentQ.correctDebit}
                  </button>
                  <button
                    onClick={() => onOpenGlossary(currentQ.correctCredit)}
                    className="btn-tactile px-2.5 py-1 rounded-xl bg-white hover:bg-slate-50 text-indigo-700 border border-indigo-200 shadow-xs"
                  >
                    Cr: {currentQ.correctCredit}
                  </button>
                  <button
                    onClick={() => onOpenGlossary(currentQ.correctVoucher)}
                    className="btn-tactile px-2.5 py-1 rounded-xl bg-white hover:bg-slate-50 text-emerald-700 border border-emerald-200 shadow-xs"
                  >
                    Voucher: {currentQ.correctVoucher}
                  </button>
                </div>
              )}
            </div>

            <div className="flex justify-end">
              <button
                onClick={handleNextQuestion}
                className="btn-tactile px-6 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs border-b-4 border-indigo-800 active:border-b-0 shadow-md flex items-center gap-2"
              >
                <span>Next Transaction</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
