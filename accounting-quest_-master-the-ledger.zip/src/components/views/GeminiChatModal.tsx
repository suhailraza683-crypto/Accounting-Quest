import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, GeminiModelId, ModelPersona } from '../../types.ts';
import { 
  X, 
  Send, 
  Bot, 
  User, 
  Sparkles, 
  RotateCcw, 
  Zap, 
  GraduationCap, 
  BrainCircuit,
  MessageSquare
} from 'lucide-react';

interface GeminiChatModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const MODEL_PERSONAS: ModelPersona[] = [
  {
    id: 'gemini-3.5-flash',
    name: 'Professor Ledger (General Tutor)',
    tag: 'Recommended',
    badgeColor: 'bg-emerald-100 text-emerald-800',
    description: 'Comprehensive NCERT Class 11 concept explanations, journal rules, and chapter doubts.',
    systemInstruction: 
      'You are Professor Ledger, a seasoned NCERT Class 11 Accounting Tutor and Chartered Accountant. Explain accounting concepts with utmost clarity, citing Golden Rules (Personal, Real, Nominal), accounting equation dual aspects, and NCERT curriculum examples. Provide step-by-step guidance, encouraging the student to think through the debit and credit logic.',
  },
  {
    id: 'gemini-3.1-flash-lite',
    name: 'Speed Ledger (Fast Lookups)',
    tag: 'Ultra-Fast',
    badgeColor: 'bg-sky-100 text-sky-800',
    description: 'Instant definitions, Golden Rule lookups, and quick voucher checks.',
    systemInstruction: 
      'You are Speed Ledger, an ultra-fast accounting terminology and golden rule dictionary. Give concise, direct answers with the exact classification (Asset, Liability, Capital, Expense, Revenue) and immediate debit/credit answer.',
  },
  {
    id: 'gemini-3.1-pro-preview',
    name: 'Master Auditor (Complex Reasoning)',
    tag: 'Advanced',
    badgeColor: 'bg-purple-100 text-purple-800',
    description: 'Complex financial statement adjustments, multi-sided error rectifications, and trial balance problems.',
    systemInstruction: 
      'You are Master Auditor, an expert in advanced Class 11 accounting mechanics: two-sided error rectifications via Suspense Account, multi-step final account adjustments (closing stock, bad debts, depreciation), and balance sheet marshalling. Provide deep analytical proofs and breakdown of both Trading/P&L and Balance Sheet impacts.',
  },
];

const INITIAL_MESSAGE: ChatMessage = {
  id: 'init-1',
  role: 'assistant',
  content: 
    "Greetings, aspiring accountant! I am **Professor Ledger**, your mentor for NCERT Class 11 Accounting. 📖\n\nAsk me anything: Golden Rules, debit/credit logic, journal entries, subsidiary books, trial balance errors, or final accounts adjustments!",
  timestamp: Date.now(),
  modelUsed: 'gemini-3.5-flash',
};

const SUGGESTED_QUESTIONS = [
  'Explain the 3 Golden Rules with examples',
  'Why is Capital shown on the Liabilities side?',
  'How do I calculate Provision for Doubtful Debts?',
  'Difference between Trade Discount & Cash Discount',
  'What is the Imprest System in Petty Cash?',
];

export const GeminiChatModal: React.FC<GeminiChatModalProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([INITIAL_MESSAGE]);
  const [inputPrompt, setInputPrompt] = useState<string>('');
  const [selectedModel, setSelectedModel] = useState<GeminiModelId>('gemini-3.5-flash');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  if (!isOpen) return null;

  const currentPersona = MODEL_PERSONAS.find((p) => p.id === selectedModel) || MODEL_PERSONAS[0];

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputPrompt).trim();
    if (!query || isLoading) return;

    setErrorMsg(null);
    setInputPrompt('');

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: query,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const historyPayload = messages.slice(-8).map((m) => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }],
      }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: selectedModel,
          systemInstruction: currentPersona.systemInstruction,
          history: historyPayload,
          message: query,
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || `Server returned error status ${res.status}`);
      }

      const data = await res.json();
      const assistantMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: data.reply || 'No response returned from the model.',
        timestamp: Date.now(),
        modelUsed: selectedModel,
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to communicate with tutor service.');
    } finally {
      setIsLoading(false);
    }
  };

  const resetChat = () => {
    setMessages([INITIAL_MESSAGE]);
    setErrorMsg(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white border-2 border-indigo-100 rounded-[28px] w-full max-w-3xl h-[88vh] flex flex-col shadow-[0_20px_50px_rgba(0,0,0,0.15)] overflow-hidden text-slate-800">
        {/* Header */}
        <div className="px-6 py-4 border-b-2 border-slate-100 flex items-center justify-between bg-slate-50/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-50 border-2 border-emerald-100 text-emerald-700 shadow-xs">
              <Bot className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-slate-900">Professor Ledger</h2>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-emerald-100 text-emerald-800">
                  AI Accounting Mentor
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Real-time explanations for NCERT Class 11 questions & rules
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={resetChat}
              className="p-2 rounded-xl bg-white hover:bg-slate-100 text-slate-400 hover:text-slate-700 border border-slate-200 transition-colors"
              title="Reset Conversation"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white hover:bg-slate-100 text-slate-400 hover:text-slate-700 border border-slate-200 transition-colors"
              title="Close Tutor"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Model Persona Selector Bar */}
        <div className="px-6 py-2.5 bg-slate-50/50 border-b-2 border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5 font-bold">
            <button
              onClick={() => setSelectedModel('gemini-3.5-flash')}
              className={`btn-tactile px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 ${
                selectedModel === 'gemini-3.5-flash'
                  ? 'bg-emerald-500 text-white font-black shadow-xs'
                  : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              <span>General Tutor</span>
            </button>

            <button
              onClick={() => setSelectedModel('gemini-3.1-flash-lite')}
              className={`btn-tactile px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 ${
                selectedModel === 'gemini-3.1-flash-lite'
                  ? 'bg-sky-500 text-white font-black shadow-xs'
                  : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Fast Rules</span>
            </button>

            <button
              onClick={() => setSelectedModel('gemini-3.1-pro-preview')}
              className={`btn-tactile px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 ${
                selectedModel === 'gemini-3.1-pro-preview'
                  ? 'bg-purple-600 text-white font-black shadow-xs'
                  : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200'
              }`}
            >
              <BrainCircuit className="w-3.5 h-3.5" />
              <span>Complex Pro</span>
            </button>
          </div>
        </div>

        {/* Scrollable Chat Thread */}
        <div className="flex-1 p-6 overflow-y-auto space-y-4">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 text-xs sm:text-sm ${
                  isUser ? 'justify-end' : 'justify-start'
                }`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-xl bg-emerald-100 border border-emerald-200 flex items-center justify-center shrink-0 text-emerald-700 mt-0.5 shadow-xs">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-2xl p-4 leading-relaxed whitespace-pre-wrap ${
                    isUser
                      ? 'bg-indigo-600 text-white shadow-sm font-medium'
                      : 'bg-slate-50 border-2 border-slate-100 text-slate-800 font-medium'
                  }`}
                >
                  <p>{msg.content}</p>
                  <div className="mt-1.5 text-[10px] opacity-60 flex items-center justify-end gap-1">
                    {msg.modelUsed && (
                      <span className="font-mono">{msg.modelUsed}</span>
                    )}
                    <span>
                      {new Date(msg.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-xl bg-indigo-100 border border-indigo-200 flex items-center justify-center shrink-0 text-indigo-700 mt-0.5 shadow-xs">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex gap-3 text-xs">
              <div className="w-8 h-8 rounded-xl bg-emerald-100 border border-emerald-200 flex items-center justify-center shrink-0 text-emerald-700 shadow-xs">
                <Bot className="w-4 h-4" />
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border-2 border-slate-100 text-slate-600 flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                <span className="font-semibold text-xs">Professor Ledger is analyzing accounting rules...</span>
              </div>
            </div>
          )}

          {errorMsg && (
            <div className="p-4 rounded-2xl bg-rose-50 border-2 border-rose-200 text-rose-800 text-xs font-semibold">
              <strong>Error:</strong> {errorMsg}
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Quick Prompts */}
        {messages.length <= 2 && (
          <div className="px-6 py-2.5 border-t-2 border-slate-100 bg-slate-50/50">
            <span className="text-[11px] text-slate-500 font-bold block mb-1.5">
              Quick Accounting Doubts:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {SUGGESTED_QUESTIONS.map((q, i) => (
                <button
                  key={i}
                  onClick={() => handleSendMessage(q)}
                  disabled={isLoading}
                  className="px-3 py-1.5 rounded-xl bg-white hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 text-xs font-semibold transition-colors flex items-center gap-1.5 border border-slate-200 shadow-xs"
                >
                  <MessageSquare className="w-3 h-3 text-indigo-600" />
                  <span>{q}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input Bar */}
        <div className="p-4 border-t-2 border-slate-100 bg-white">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              placeholder="Ask Professor Ledger any Class 11 accounting question or rule..."
              disabled={isLoading}
              className="flex-1 px-4 py-2.5 text-xs sm:text-sm rounded-2xl bg-slate-50 border-2 border-slate-200 text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500 shadow-xs font-medium"
            />

            <button
              type="submit"
              disabled={!inputPrompt.trim() || isLoading}
              className="btn-tactile px-5 py-2.5 rounded-2xl bg-emerald-500 hover:bg-emerald-600 disabled:bg-slate-200 disabled:text-slate-400 text-white font-black text-xs sm:text-sm border-b-4 border-emerald-700 active:border-b-0 transition-all flex items-center gap-1.5 shadow-sm"
            >
              <span>Ask</span>
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
