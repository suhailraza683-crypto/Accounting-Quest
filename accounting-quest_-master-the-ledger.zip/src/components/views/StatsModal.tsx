import React from 'react';
import { PlayerStats, RankTier } from '../../types.ts';
import { X, Award, Flame, Target, Trophy, ShieldCheck, RotateCcw } from 'lucide-react';

interface StatsModalProps {
  isOpen: boolean;
  onClose: () => void;
  stats: PlayerStats;
  rankInfo: { tier: RankTier; nextXp: number; progress: number; badgeColor: string };
  onResetProgress: () => void;
}

const BADGES = [
  { id: 'first_step', name: 'First Ledger Entry', desc: 'Answered your first accounting question', icon: '📝' },
  { id: 'streak_5', name: 'Hot Streak', desc: 'Achieved a streak of 5 correct answers', icon: '🔥' },
  { id: 'streak_10', name: 'Ledger Mastermind', desc: 'Achieved a streak of 10 correct answers', icon: '⚡' },
  { id: 'consistency_badge', name: 'Consistency Badge', desc: 'Hit a 7-day login streak of consistent learning', icon: '🗓️' },
  { id: 'rank_senior', name: 'Senior Accountant', desc: 'Reached 1,500+ XP', icon: '🎖️' },
  { id: 'rank_cfo', name: 'CFO League', desc: 'Reached 5,000+ XP', icon: '👑' },
  { id: 'boss_slayer', name: 'Audit Conqueror', desc: 'Defeated the Boss in Level 4 Time Attack', icon: '🛡️' },
];

export const StatsModal: React.FC<StatsModalProps> = ({
  isOpen,
  onClose,
  stats,
  rankInfo,
  onResetProgress,
}) => {
  if (!isOpen) return null;

  const accuracy = stats.totalAnswered > 0 ? Math.round((stats.totalCorrect / stats.totalAnswered) * 100) : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white border-2 border-indigo-100 rounded-[28px] w-full max-w-2xl max-h-[90vh] flex flex-col shadow-[0_20px_50px_rgba(0,0,0,0.15)] overflow-hidden text-slate-800">
        {/* Header */}
        <div className="px-6 py-4 border-b-2 border-slate-100 flex items-center justify-between bg-slate-50/60">
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded-2xl bg-indigo-50 border-2 border-indigo-100 text-indigo-700 shadow-xs`}>
              <Award className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <h2 className="text-lg font-black text-slate-900">{rankInfo.tier}</h2>
              <p className="text-xs text-slate-500 font-medium">Player Record & Performance Dashboard</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-400 hover:text-slate-700 border border-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 p-6 overflow-y-auto space-y-5">
          {/* XP & Progress Banner */}
          <div className="p-5 rounded-2xl bg-indigo-50/60 border-2 border-indigo-100">
            <div className="flex justify-between items-center text-xs mb-2 font-bold">
              <span className="text-slate-700">Rank Progression: {rankInfo.tier}</span>
              <span className="text-indigo-700 font-black">{stats.xp} / {rankInfo.nextXp} XP</span>
            </div>
            <div className="w-full h-3 bg-white rounded-full overflow-hidden p-0.5 border border-indigo-200">
              <div 
                className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 rounded-full transition-all duration-500"
                style={{ width: `${rankInfo.progress}%` }}
              />
            </div>
            <p className="text-xs text-slate-500 mt-2 font-medium">
              Solve questions with active streaks to earn multiplied XP and unlock higher accounting titles!
            </p>
          </div>

          {/* Quick Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-2xl bg-white border-2 border-slate-100 text-center shadow-xs">
              <div className="flex justify-center mb-1 text-indigo-600">
                <Target className="w-5 h-5" />
              </div>
              <span className="text-xl font-black text-slate-900">{accuracy}%</span>
              <span className="block text-xs text-slate-500 font-semibold">Accuracy</span>
            </div>

            <div className="p-4 rounded-2xl bg-amber-50/60 border-2 border-amber-100 text-center shadow-xs">
              <div className="flex justify-center mb-1 text-amber-500">
                <Flame className="w-5 h-5 fill-amber-500" />
              </div>
              <span className="text-xl font-black text-amber-900">{stats.highestStreak}</span>
              <span className="block text-xs text-amber-700 font-semibold">Best Streak</span>
            </div>

            <div className="p-4 rounded-2xl bg-emerald-50/60 border-2 border-emerald-100 text-center shadow-xs">
              <div className="flex justify-center mb-1 text-emerald-600">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <span className="text-xl font-black text-emerald-900">{stats.totalCorrect}</span>
              <span className="block text-xs text-emerald-700 font-semibold">Solved / {stats.totalAnswered}</span>
            </div>

            <div className="p-4 rounded-2xl bg-rose-50/60 border-2 border-rose-100 text-center shadow-xs">
              <div className="flex justify-center mb-1 text-rose-500">
                <Trophy className="w-5 h-5" />
              </div>
              <span className="text-xl font-black text-rose-900">{stats.bossesDefeated}</span>
              <span className="block text-xs text-rose-700 font-semibold">Bosses Beat</span>
            </div>
          </div>

          {/* High Scores By Level */}
          <div className="p-5 rounded-2xl bg-slate-50/80 border-2 border-slate-100">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-1.5">
              <Trophy className="w-4 h-4 text-amber-500" />
              High Scores By Mode
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-bold">
              <div className="p-3 rounded-xl bg-white border border-slate-200 shadow-xs">
                <span className="text-slate-400 block text-[11px]">Level 1: Matcher</span>
                <span className="text-base font-black text-indigo-700">{stats.levelHighScores.level1} pts</span>
              </div>
              <div className="p-3 rounded-xl bg-white border border-slate-200 shadow-xs">
                <span className="text-slate-400 block text-[11px]">Level 2: Journal</span>
                <span className="text-base font-black text-emerald-700">{stats.levelHighScores.level2} pts</span>
              </div>
              <div className="p-3 rounded-xl bg-white border border-slate-200 shadow-xs">
                <span className="text-slate-400 block text-[11px]">Level 3: Adjustments</span>
                <span className="text-base font-black text-sky-700">{stats.levelHighScores.level3} pts</span>
              </div>
              <div className="p-3 rounded-xl bg-white border border-slate-200 shadow-xs">
                <span className="text-slate-400 block text-[11px]">Level 4: Boss Time</span>
                <span className="text-base font-black text-rose-700">{stats.levelHighScores.level4} pts</span>
              </div>
            </div>
          </div>

          {/* Badges / Achievements */}
          <div>
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-1.5">
              <Award className="w-4 h-4 text-indigo-600" />
              Honors & Badges
            </h3>
            <div className="grid sm:grid-cols-2 gap-3">
              {BADGES.map((b) => {
                const isUnlocked = stats.unlockedBadges.includes(b.id) || (b.id === 'first_step' && stats.totalAnswered > 0);
                return (
                  <div
                    key={b.id}
                    className={`p-3.5 rounded-2xl border-2 flex items-center gap-3 transition-colors ${
                      isUnlocked
                        ? 'bg-white border-indigo-200 shadow-xs text-slate-900'
                        : 'bg-slate-50/70 border-slate-100 text-slate-400 opacity-60'
                    }`}
                  >
                    <span className="text-2xl p-2 rounded-xl bg-slate-100/70 shrink-0">{b.icon}</span>
                    <div className="min-w-0">
                      <h4 className="text-xs font-black truncate">{b.name}</h4>
                      <p className="text-[11px] text-slate-500 line-clamp-1 font-medium">{b.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t-2 border-slate-100 bg-slate-50/60 flex items-center justify-between">
          <button
            onClick={() => {
              if (window.confirm('Reset all saved game data and progress? This cannot be undone.')) {
                onResetProgress();
                onClose();
              }
            }}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-rose-600 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Data</span>
          </button>

          <button
            onClick={onClose}
            className="btn-tactile px-5 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black border-b-4 border-indigo-800 active:border-b-0 shadow-sm"
          >
            Close Dashboard
          </button>
        </div>
      </div>
    </div>
  );
};
