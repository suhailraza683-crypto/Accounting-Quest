import React, { useState } from 'react';
import { 
  CalendarDays, 
  Flame, 
  Award, 
  Check, 
  Sparkles, 
  FastForward, 
  Gift, 
  Lock, 
  CheckCircle2,
  Clock
} from 'lucide-react';

interface CalendarStreakVisualizerProps {
  loginStreak: number;
  unlockedBadges: string[];
  lastLoginDate: string;
  onAdvanceSimulationDay: () => void;
  onClaimDailyCheckIn: () => void;
}

export const CalendarStreakVisualizer: React.FC<CalendarStreakVisualizerProps> = ({
  loginStreak,
  unlockedBadges,
  lastLoginDate,
  onAdvanceSimulationDay,
  onClaimDailyCheckIn,
}) => {
  const [claimedToday, setClaimedToday] = useState<boolean>(false);

  const safeStreak = Math.max(1, loginStreak || 1);
  const cycleDay = ((safeStreak - 1) % 7) + 1; // 1 to 7 within current 7-day cycle
  const hasConsistencyBadge = unlockedBadges.includes('consistency_badge') || safeStreak >= 7;
  const progressPercent = Math.min(100, Math.round((cycleDay / 7) * 100));

  const daysOfWeek = ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'];

  const handleClaim = () => {
    if (claimedToday) return;
    setClaimedToday(true);
    onClaimDailyCheckIn();
  };

  return (
    <div className="card-bouncy rounded-3xl bg-white border-2 border-amber-200/90 p-5 sm:p-6 shadow-[0_10px_30px_-5px_rgba(245,158,11,0.12)] space-y-5">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b-2 border-slate-100">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-amber-50 border-2 border-amber-200 text-amber-600 shadow-xs">
            <CalendarDays className="w-6 h-6 text-amber-500" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-black text-slate-900">
                7-Day Calendar Streak
              </h3>
              <span className="px-3 py-0.5 rounded-full text-xs font-black bg-amber-100 border border-amber-300 text-amber-900 flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                <span>{safeStreak} Day{safeStreak !== 1 ? 's' : ''} Streak</span>
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              Log in daily to keep your streak glowing, earn bonus XP, and claim the Consistency Badge!
            </p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto text-xs">
          {!claimedToday ? (
            <button
              onClick={handleClaim}
              className="btn-tactile px-3.5 py-1.5 rounded-2xl bg-amber-400 hover:bg-amber-500 text-amber-950 font-black border-b-4 border-amber-600 active:border-b-0 shadow-sm flex items-center gap-1.5"
            >
              <Gift className="w-3.5 h-3.5" />
              <span>Claim Streak XP</span>
            </button>
          ) : (
            <span className="px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              <span>Checked in today</span>
            </span>
          )}

          <button
            onClick={() => {
              setClaimedToday(false);
              onAdvanceSimulationDay();
            }}
            className="btn-tactile px-3 py-1.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-black border-2 border-slate-200 border-b-4 border-b-slate-300 active:border-b-2 transition-all flex items-center gap-1.5 shadow-xs"
            title="Fast forward simulation to test streak progression and unlock badge"
          >
            <FastForward className="w-3.5 h-3.5 text-indigo-600" />
            <span>Simulate Next Day</span>
          </button>
        </div>
      </div>

      {/* 7-Day Animated Progress Bar */}
      <div className="space-y-2">
        <div className="flex justify-between items-center text-xs">
          <span className="font-bold text-slate-600 flex items-center gap-1.5">
            <span>Weekly Consistency Progress</span>
            <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-mono text-[11px] font-bold">
              {cycleDay} / 7 Days
            </span>
          </span>
          <span className="font-black text-amber-700 text-xs">
            {progressPercent}% Complete
          </span>
        </div>

        <div className="relative w-full h-4 bg-slate-100 rounded-full overflow-hidden p-0.5 border border-slate-200">
          <div
            className="h-full bg-gradient-to-r from-amber-400 via-orange-400 to-emerald-500 rounded-full transition-all duration-500 shadow-xs"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* 7-Day Day-by-Day Visualizer Grid */}
      <div className="grid grid-cols-7 gap-1.5 sm:gap-3">
        {daysOfWeek.map((dayLabel, idx) => {
          const dayNumber = idx + 1;
          const isCompleted = dayNumber <= cycleDay || (hasConsistencyBadge && safeStreak >= 7);
          const isCurrent = dayNumber === cycleDay;
          const isMilestone = dayNumber === 7;

          return (
            <div
              key={idx}
              className={`p-2 sm:p-3 rounded-2xl border-2 flex flex-col items-center justify-between text-center transition-all ${
                isCompleted
                  ? isMilestone
                    ? 'bg-gradient-to-br from-amber-50 to-emerald-50 border-emerald-400 shadow-sm'
                    : 'bg-amber-50/70 border-amber-300 shadow-xs'
                  : 'bg-slate-50/60 border-slate-200/80 text-slate-400'
              } ${isCurrent ? 'ring-2 ring-amber-400 ring-offset-1' : ''}`}
            >
              <span className={`text-[10px] sm:text-xs font-black ${
                isCompleted ? 'text-amber-900' : 'text-slate-400'
              }`}>
                {dayLabel}
              </span>

              <div className="my-1.5 sm:my-2">
                {isCompleted ? (
                  isMilestone ? (
                    <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-400 to-yellow-300 text-amber-950 flex items-center justify-center text-base shadow-xs animate-bounce">
                      🏆
                    </div>
                  ) : (
                    <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-amber-400 text-amber-950 flex items-center justify-center shadow-xs">
                      <Flame className="w-4 h-4 fill-amber-950 text-amber-950" />
                    </div>
                  )
                ) : isMilestone ? (
                  <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-slate-200/80 text-slate-400 flex items-center justify-center text-sm">
                    🏅
                  </div>
                ) : (
                  <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl border-2 border-dashed border-slate-300 flex items-center justify-center text-slate-300">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                )}
              </div>

              <span className={`text-[9px] sm:text-[10px] font-black truncate ${
                isCurrent 
                  ? 'px-1.5 py-0.2 rounded-md bg-amber-200 text-amber-900' 
                  : isCompleted 
                  ? 'text-emerald-700' 
                  : 'text-slate-400'
              }`}>
                {isCurrent ? 'Today' : isCompleted ? 'Done' : isMilestone ? 'Badge' : 'Next'}
              </span>
            </div>
          );
        })}
      </div>

      {/* Consistency Badge Award Showcase */}
      <div className={`p-4 rounded-2xl border-2 flex items-center justify-between gap-3 transition-all ${
        hasConsistencyBadge
          ? 'bg-gradient-to-r from-amber-50 via-emerald-50 to-teal-50 border-emerald-300 shadow-sm'
          : 'bg-slate-50 border-slate-200'
      }`}>
        <div className="flex items-center gap-3">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shrink-0 border-2 shadow-xs ${
            hasConsistencyBadge
              ? 'bg-gradient-to-tr from-amber-400 to-yellow-300 border-amber-300'
              : 'bg-slate-100 border-slate-200 opacity-60'
          }`}>
            🗓️
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-xs sm:text-sm font-black text-slate-900">
                Consistency Badge (7-Day Streak)
              </h4>
              {hasConsistencyBadge ? (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-emerald-600" />
                  Unlocked!
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-200 text-slate-600 flex items-center gap-1">
                  <Lock className="w-3 h-3 text-slate-500" />
                  {7 - cycleDay} days remaining
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-500 font-medium mt-0.5">
              {hasConsistencyBadge
                ? 'Outstanding habit! You conquered the 7-day consistency challenge and unlocked the Consistency Badge + 250 XP bonus.'
                : `Keep learning! Hit a 7-day consecutive streak to unlock this exclusive honor and earn +250 XP.`}
            </p>
          </div>
        </div>

        <div className="shrink-0 text-right hidden sm:block">
          <span className="text-xs font-black text-amber-700 block">+250 XP</span>
          <span className="text-[10px] text-slate-400 font-semibold">Special Reward</span>
        </div>
      </div>
    </div>
  );
};
