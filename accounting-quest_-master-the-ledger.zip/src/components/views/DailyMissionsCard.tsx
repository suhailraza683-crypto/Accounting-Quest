import React from 'react';
import { DailyMission } from '../../types.ts';
import { Target, CheckCircle2, Gift, Clock, Sparkles } from 'lucide-react';

interface DailyMissionsCardProps {
  missions: DailyMission[];
  completedCount: number;
  unclaimedCount: number;
  totalCount: number;
  onClaimReward: (missionId: string) => void;
  onClaimAllRewards: () => void;
}

export const DailyMissionsCard: React.FC<DailyMissionsCardProps> = ({
  missions,
  completedCount,
  unclaimedCount,
  totalCount,
  onClaimReward,
  onClaimAllRewards,
}) => {
  const percentComplete = Math.round((completedCount / totalCount) * 100);

  return (
    <div className="card-bouncy rounded-3xl bg-white border-2 border-indigo-100 p-5 sm:p-6 shadow-[0_10px_30px_-5px_rgba(99,102,241,0.08)] space-y-4">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b-2 border-slate-100">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-indigo-50 border-2 border-indigo-100 text-indigo-600 shadow-xs">
            <Target className="w-6 h-6 text-indigo-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-extrabold text-slate-900">
                Daily Ledger Quests
              </h3>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-indigo-100 text-indigo-800">
                {completedCount}/{totalCount} Completed
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              Complete daily accounting goals to earn bonus XP and power up your rank!
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto text-xs">
          <div className="flex items-center gap-1.5 text-slate-500 px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 font-medium">
            <Clock className="w-3.5 h-3.5 text-amber-500" />
            <span>Refreshes Daily</span>
          </div>

          {unclaimedCount > 0 && (
            <button
              onClick={onClaimAllRewards}
              className="btn-tactile flex items-center gap-1.5 px-3.5 py-1.5 rounded-2xl bg-amber-400 hover:bg-amber-500 text-amber-950 font-black text-xs border-b-4 border-amber-600 active:border-b-0 shadow-sm animate-pulse"
            >
              <Gift className="w-3.5 h-3.5 text-amber-950" />
              <span>Claim All ({unclaimedCount})</span>
            </button>
          )}
        </div>
      </div>

      {/* Progress Bar Header */}
      <div className="space-y-1.5">
        <div className="flex justify-between text-xs font-semibold text-slate-600">
          <span>Overall Daily Progress</span>
          <span className="font-extrabold text-indigo-600">{percentComplete}% Complete</span>
        </div>
        <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden p-0.5 border border-slate-200">
          <div
            className="h-full bg-gradient-to-r from-indigo-500 via-sky-400 to-emerald-400 rounded-full transition-all duration-500 shadow-xs"
            style={{ width: `${percentComplete}%` }}
          />
        </div>
      </div>

      {/* Missions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {missions.map((m) => {
          const progressPercent = Math.min(100, Math.round((m.current / m.target) * 100));

          return (
            <div
              key={m.id}
              className={`p-4 rounded-2xl border-2 flex flex-col justify-between transition-all duration-200 ${
                m.claimed
                  ? 'bg-slate-50/70 border-slate-200/80 text-slate-400'
                  : m.completed
                  ? 'bg-emerald-50/70 border-emerald-300 shadow-sm'
                  : 'bg-white border-slate-100 hover:border-indigo-200 shadow-xs hover:shadow-sm'
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span className="text-2xl shrink-0 p-1.5 rounded-xl bg-white shadow-xs border border-slate-100">
                      {m.icon}
                    </span>
                    <h4 className={`text-xs font-extrabold ${m.claimed ? 'text-slate-400' : 'text-slate-800'}`}>
                      {m.title}
                    </h4>
                  </div>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-xs font-black shrink-0 ${
                      m.claimed
                        ? 'bg-slate-200/70 text-slate-500'
                        : 'bg-amber-100 text-amber-800 border border-amber-200'
                    }`}
                  >
                    +{m.xpReward} XP
                  </span>
                </div>

                <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
                  {m.description}
                </p>
              </div>

              {/* Progress and Action */}
              <div className="mt-3.5 pt-3 border-t border-slate-100 space-y-2">
                <div className="flex justify-between items-center text-[10px] font-semibold text-slate-500">
                  <span>Progress</span>
                  <span className="font-mono text-slate-700">
                    {m.current} / {m.target}
                  </span>
                </div>

                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-300 rounded-full ${
                      m.completed ? 'bg-emerald-500' : 'bg-indigo-500'
                    }`}
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>

                <div className="pt-1 flex justify-end">
                  {m.claimed ? (
                    <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      Claimed
                    </span>
                  ) : m.completed ? (
                    <button
                      onClick={() => onClaimReward(m.id)}
                      className="btn-tactile px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-xs border-b-4 border-emerald-700 active:border-b-0 shadow-sm flex items-center gap-1.5"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-yellow-200" />
                      <span>Claim +{m.xpReward} XP</span>
                    </button>
                  ) : (
                    <span className="text-[11px] font-semibold text-slate-400">
                      In Progress ({m.current}/{m.target})
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
