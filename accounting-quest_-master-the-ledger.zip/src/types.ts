export type RankTier = 
  | 'Accounting Intern'
  | 'Junior Bookkeeper'
  | 'Senior Accountant'
  | 'Financial Controller'
  | 'Chief Financial Officer'
  | 'Master of the Ledger';

export interface Chapter {
  id: number;
  chapterNumber: number;
  title: string;
  shortTitle: string;
  category: 'Foundations' | 'Recording' | 'Ledger & Trial' | 'Final Accounts';
  description: string;
  goldenRulesHighlight?: string;
  keyConcepts: string[];
}

export type GoldenRuleType = 'Personal' | 'Real' | 'Nominal' | 'Asset' | 'Liability' | 'Capital' | 'Revenue' | 'Expense';

export interface TermQuestion {
  id: string;
  chapterId: number;
  term: string;
  question: string;
  options: string[];
  correctIndex: number;
  ruleCategory?: GoldenRuleType;
  explanation: string;
  ncertReference: string;
  flashcard: {
    definition: string;
    example: string;
    goldenRule: string;
    proTip: string;
  };
}

export interface JournalQuestion {
  id: string;
  chapterId: number;
  transaction: string;
  amount: string;
  correctDebit: string;
  correctCredit: string;
  correctVoucher: string;
  optionsDebit: string[];
  optionsCredit: string[];
  optionsVoucher: string[];
  debitRule: string;
  creditRule: string;
  explanation: string;
  ncertReference: string;
}

export interface AdjustmentQuestion {
  id: string;
  chapterId: number;
  title: string;
  scenario: string;
  question: string;
  options: string[];
  correctIndex: number;
  tradingOrPLImpact: string;
  balanceSheetImpact: string;
  calculationSnippet?: string;
  explanation: string;
  ncertReference: string;
}

export interface BossQuestion {
  id: string;
  chapterId: number;
  type: 'concept' | 'journal' | 'equation' | 'adjustment' | 'voucher';
  question: string;
  options: string[];
  correctIndex: number;
  timeLimitSec: number;
  bossDamage: number;
  explanation: string;
  ncertReference: string;
}

export interface PlayerStats {
  xp: number;
  score: number;
  currentStreak: number;
  highestStreak: number;
  totalAnswered: number;
  totalCorrect: number;
  levelHighScores: {
    level1: number;
    level2: number;
    level3: number;
    level4: number;
  };
  completedChapters: number[];
  bossesDefeated: number;
  unlockedBadges: string[];
  loginStreak: number;
  lastLoginDate: string;
  loginHistory: string[];
}

export interface LifelineState {
  fiftyFiftyUsed: boolean;
  hintUsed: boolean;
  skipUsed: boolean;
}

export type MissionType = 'answer_count' | 'streak_target' | 'play_level2' | 'play_level3' | 'boss_defeat';

export interface DailyMission {
  id: string;
  type: MissionType;
  title: string;
  description: string;
  target: number;
  current: number;
  xpReward: number;
  completed: boolean;
  claimed: boolean;
  icon: string;
}

export interface DailyMissionsData {
  lastUpdatedDate: string; // YYYY-MM-DD
  missions: DailyMission[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  modelUsed?: string;
}

export type GeminiModelId = 'gemini-3.5-flash' | 'gemini-3.1-pro-preview' | 'gemini-3.1-flash-lite';

export interface ModelPersona {
  id: GeminiModelId;
  name: string;
  tag: string;
  badgeColor: string;
  description: string;
  systemInstruction: string;
}

export interface GlossaryItem {
  id: string;
  term: string;
  category: 'Asset' | 'Liability' | 'Capital' | 'Revenue' | 'Expense' | 'Concept' | 'Document' | 'Process' | 'Book';
  chapterId: number;
  chapterName: string;
  ncertGuideline: string;
  definition: string;
  goldenRuleOrFormula?: string;
  practicalExample: string;
  examTip?: string;
  relatedLevel?: 1 | 2 | 3 | 4;
}

export type ToastType = 'xp_gain' | 'mission_completed' | 'rank_up' | 'streak_milestone' | 'info';

export interface ToastItem {
  id: string;
  type: ToastType;
  title: string;
  message?: string;
  xpAmount?: number;
  streak?: number;
  multiplier?: number;
  icon?: string;
  timestamp: number;
  durationMs?: number;
}

export interface FloatingXpItem {
  id: string;
  amount: number;
  multiplier?: number;
  streak?: number;
  label?: string;
  timestamp: number;
}

export interface XpGainEvent {
  amount: number;
  reason: string;
  streak?: number;
  multiplier?: number;
}
