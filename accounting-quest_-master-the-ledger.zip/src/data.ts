import { Chapter, TermQuestion, JournalQuestion, AdjustmentQuestion, BossQuestion } from './types.ts';

export const CHAPTERS: Chapter[] = [
  {
    id: 1,
    chapterNumber: 1,
    title: 'Meaning & Objectives of Accounting',
    shortTitle: 'Ch 1: Meaning & Objectives',
    category: 'Foundations',
    description: 'Definition, attributes of accounting, objectives, branches, and internal vs external users.',
    goldenRulesHighlight: 'Accounting is the art of recording, classifying, and summarizing in a significant manner.',
    keyConcepts: [
      'Identification of Financial Transactions',
      'Measurement in Terms of Money',
      'Recording (Journal) & Classifying (Ledger)',
      'Summarizing (Trial Balance & Final A/cs)',
      'Internal Users (Owners, Managers) vs External Users (Creditors, Banks, Tax Authorities)',
      'Branches: Financial, Cost, and Management Accounting'
    ]
  },
  {
    id: 2,
    chapterNumber: 2,
    title: 'Basic Accounting Terms',
    shortTitle: 'Ch 2: Basic Accounting Terms',
    category: 'Foundations',
    description: 'Assets, liabilities, capital, drawings, revenue, expense, trade discount, cash discount, debtors, and creditors.',
    goldenRulesHighlight: 'Assets = Capital + Liabilities; Capital is the owner’s claim against the enterprise.',
    keyConcepts: [
      'Current vs Non-Current Assets',
      'Tangible vs Intangible Assets',
      'Current vs Non-Current Liabilities',
      'Capital & Drawings (Drawings reduce Capital)',
      'Trade Discount (not recorded) vs Cash Discount (recorded in books)',
      'Debtors (Customers on credit) vs Creditors (Suppliers on credit)'
    ]
  },
  {
    id: 3,
    chapterNumber: 3,
    title: 'GAAP & Fundamental Assumptions',
    shortTitle: 'Ch 3: GAAP & Assumptions',
    category: 'Foundations',
    description: 'Fundamental accounting assumptions (Going Concern, Consistency, Accrual) and core accounting principles.',
    goldenRulesHighlight: 'Prudence/Conservatism: Anticipate no profit, but provide for all possible losses.',
    keyConcepts: [
      '3 Fundamental Assumptions: Going Concern, Consistency, Accrual',
      'Business Entity: Owner and business are distinct legal/accounting entities',
      'Money Measurement: Only financial events recorded',
      'Prudence / Conservatism: Provide for doubtful debts & stock at cost or net realizable value, whichever is lower',
      'Dual Aspect: Every transaction has equal debit and credit effect',
      'Matching Concept: Match revenues with expenses incurred to generate them'
    ]
  },
  {
    id: 4,
    chapterNumber: 4,
    title: 'Cash vs. Accrual Basis of Accounting',
    shortTitle: 'Ch 4: Cash vs. Accrual',
    category: 'Foundations',
    description: 'Differences in revenue and expense recognition, legal recognition, and true profit determination.',
    goldenRulesHighlight: 'Companies Act, 2013 mandates the Accrual Basis for all corporate entities.',
    keyConcepts: [
      'Cash Basis: Income recorded ONLY when received; expenses ONLY when paid',
      'Accrual Basis: Recognized when earned or incurred regardless of cash flow',
      'Accrual basis accounts for Prepaid, Outstanding, Accrued, and Unearned items',
      'Cash basis does not show true & fair view of financial position'
    ]
  },
  {
    id: 5,
    chapterNumber: 5,
    title: 'Accounting Equation',
    shortTitle: 'Ch 5: Accounting Equation',
    category: 'Recording',
    description: 'Assets = Liabilities + Capital. Dual aspect effects of purchase, sales, expenses, and drawings.',
    goldenRulesHighlight: 'Assets = Liabilities + Capital (A = L + C). In expanded form: Assets = Liabilities + Capital + Revenue - Expenses - Drawings.',
    keyConcepts: [
      'Capital changes with: Net Profit (+), Net Loss (-), Drawings (-), New Capital (+)',
      'Buying goods for cash: Cash decreases (-), Stock increases (+), Total assets unchanged',
      'Paying expenses: Cash decreases (-), Capital decreases (-)',
      'Selling goods at profit: Stock decreases at cost, Cash/Debtor increases at selling price, Capital increases by profit'
    ]
  },
  {
    id: 7,
    chapterNumber: 7,
    title: 'Source Documents & Vouchers',
    shortTitle: 'Ch 7: Documents & Vouchers',
    category: 'Recording',
    description: 'Cash memos, invoices, receipts, debit notes, credit notes, and voucher classification.',
    goldenRulesHighlight: 'A Voucher is written proof prepared by the accountant authorizing the recording of a transaction.',
    keyConcepts: [
      'Cash Memo: Source document for cash sales/purchases',
      'Invoice / Bill: Source document for credit sales/purchases',
      'Debit Note: Sent to supplier when goods are returned to them',
      'Credit Note: Sent to customer when goods are received back from them',
      'Debit Voucher (Payment Voucher): Prepared for cash payment',
      'Credit Voucher (Receipt Voucher): Prepared for cash received',
      'Transfer Voucher (Journal Voucher): Prepared for non-cash transactions (depreciation, credit purchase of fixed assets)'
    ]
  },
  {
    id: 10,
    chapterNumber: 10,
    title: 'Cash Book & Imprest System',
    shortTitle: 'Ch 10: Cash Book & Imprest',
    category: 'Recording',
    description: 'Single, double column cash books, contra entries, petty cash book, and imprest float.',
    goldenRulesHighlight: 'Cash column always has a Debit balance (or Nil); Bank column may have Credit (Overdraft) balance.',
    keyConcepts: [
      'Cash Book serves as both a Book of Original Entry (Journal) and a Ledger Account',
      'Contra Entries: Depositing cash into bank or withdrawing cash from bank for office use (denoted with "C")',
      'Petty Cash Book: Records small recurring payments (postage, cartage, stationery)',
      'Imprest System: Petty cashier is given a fixed sum (float); reimbursed exact amount spent at the end of period',
      'Cheques received but deposited later: First debited to "Cheques in Hand A/c"'
    ]
  },
  {
    id: 11,
    chapterNumber: 11,
    title: 'Subsidiary Books & Journal Proper',
    shortTitle: 'Ch 11: Subsidiary Books',
    category: 'Recording',
    description: 'Purchases book, sales book, returns books, and transactions entered in Journal Proper.',
    goldenRulesHighlight: 'Purchases Book records ONLY CREDIT purchases of GOODS (inventory), never cash purchases or asset purchases.',
    keyConcepts: [
      'Purchases Book: Credit purchase of goods for resale',
      'Sales Book: Credit sale of goods (trade inventory)',
      'Purchase of Machinery on Credit goes to Journal Proper (NOT Purchases Book)',
      'Purchases Return (Return Outward) & Sales Return (Return Inward) Books',
      'Journal Proper records: Opening entries, closing entries, rectifying entries, transfer entries, and non-cash asset transactions'
    ]
  },
  {
    id: 14,
    chapterNumber: 14,
    title: 'Trial Balance Rules & Errors',
    shortTitle: 'Ch 14: Trial Balance & Errors',
    category: 'Ledger & Trial',
    description: 'Preparation of Trial Balance, Debit vs Credit balances, errors disclosed and not disclosed, Suspense A/c.',
    goldenRulesHighlight: 'Debit: Assets, Expenses, Losses, Drawings. Credit: Liabilities, Incomes, Gains, Capital.',
    keyConcepts: [
      'Trial Balance tests the arithmetical accuracy of ledger postings',
      'Errors of Principle (e.g. treating capital expenditure as revenue) DO NOT affect Trial Balance agreement',
      'Errors of Complete Omission do not affect Trial Balance',
      'Compensating Errors do not affect Trial Balance',
      'One-sided errors cause disagreement; difference is temporarily placed in Suspense Account'
    ]
  },
  {
    id: 16,
    chapterNumber: 16,
    title: 'Provisions & Reserves',
    shortTitle: 'Ch 16: Provisions & Reserves',
    category: 'Ledger & Trial',
    description: 'Differences between provision and reserve, charge vs appropriation, revenue vs capital reserves.',
    goldenRulesHighlight: 'Provision is a CHARGE against profits (compulsory); Reserve is an APPROPRIATION of profits (optional).',
    keyConcepts: [
      'Provision: Created for a known liability whose amount cannot be determined with substantial accuracy (e.g. Provision for Bad Debts, Provision for Depreciation)',
      'Reserve: Retained earnings to strengthen financial health or meet unknown future losses',
      'Revenue Reserve: Created from normal trading profits, available for dividend distribution',
      'Capital Reserve: Created from capital profits (e.g. profit on sale of fixed assets, premium on issue of shares)',
      'Secret Reserve: Not disclosed on the balance sheet'
    ]
  },
  {
    id: 18,
    chapterNumber: 18,
    title: 'Financial Statements (Capital vs. Revenue)',
    shortTitle: 'Ch 18: Financial Statements',
    category: 'Final Accounts',
    description: 'Trading Account, Profit & Loss Account, Balance Sheet marshalling, and Capital vs Revenue expenditure.',
    goldenRulesHighlight: 'Direct expenses go to Trading A/c (Gross Profit); Indirect expenses go to P&L A/c (Net Profit).',
    keyConcepts: [
      'Capital Expenditure: Enduring benefit, increases earning capacity (e.g. purchase of plant, overhaul of second-hand machine to make it operational)',
      'Revenue Expenditure: Maintains earning capacity, benefit consumed within 1 year (e.g. repairs, factory wages, carriage inward)',
      'Trading A/c: Computes Gross Profit / Gross Loss (Sales - Cost of Goods Sold)',
      'Profit & Loss A/c: Computes Net Profit / Net Loss',
      'Marshalling of Balance Sheet: Order of Liquidity or Order of Permanence'
    ]
  },
  {
    id: 19,
    chapterNumber: 19,
    title: 'Financial Statement Adjustments',
    shortTitle: 'Ch 19: Adjustments',
    category: 'Final Accounts',
    description: 'Dual effects of Closing Stock, Outstanding/Prepaid Expenses, Accrued/Unearned Income, Bad Debts, and Provisions.',
    goldenRulesHighlight: 'Every adjustment outside the Trial Balance MUST have at least two effects: one in Trading/P&L and one in Balance Sheet.',
    keyConcepts: [
      'Closing Stock: Credit Trading A/c & Balance Sheet Asset side',
      'Outstanding Expenses: Add to expense in Trading/P&L & Balance Sheet Liability side',
      'Prepaid Expenses: Deduct from expense in Trading/P&L & Balance Sheet Asset side',
      'Accrued Income: Add to income in P&L & Balance Sheet Asset side',
      'Unearned Income: Deduct from income in P&L & Balance Sheet Liability side',
      'Provision for Doubtful Debts: Debit P&L & Deduct from Debtors in Balance Sheet',
      'Depreciation: Debit P&L & Deduct from Fixed Asset in Balance Sheet'
    ]
  }
];

export const TERM_QUESTIONS: TermQuestion[] = [
  {
    id: 't-1-1',
    chapterId: 1,
    term: 'Internal Users',
    question: 'Which of the following is classified as an INTERNAL user of accounting information according to NCERT?',
    options: ['Creditors & Suppliers', 'Chief Executive Officer (Management)', 'Tax Authorities', 'Prospective Investors'],
    correctIndex: 1,
    ruleCategory: 'Personal',
    explanation: 'Internal users include business owners, Board of Directors, Chief Executives, and Managers who have direct access to internal management accounts.',
    ncertReference: 'NCERT Ch 1: Users of Accounting Information',
    flashcard: {
      definition: 'Individuals within an organization who use financial information to plan, direct, and make strategic operating decisions.',
      example: 'Plant managers reviewing monthly cost variance reports to control production expenses.',
      goldenRule: 'Internal = Inside decision makers (Owners, Managers, Officers). External = Outside stakeholders (Banks, Tax authorities, Creditors).',
      proTip: 'Ask: "Does this person manage day-to-day operations from inside the firm?" If yes, they are an Internal user.'
    }
  },
  {
    id: 't-2-1',
    chapterId: 2,
    term: 'Fictitious Asset',
    question: 'What is a "Fictitious Asset" under basic accounting terminology?',
    options: [
      'Tangible property with market value',
      'Deferred revenue expenditure having no realisable sale value (e.g. heavy preliminary expenses)',
      'Money deposited in an offshore bank account',
      'Investments in high-risk stock markets'
    ],
    correctIndex: 1,
    ruleCategory: 'Asset',
    explanation: 'Fictitious assets are not real assets; they represent accumulated losses or deferred revenue expenses not yet written off, possessing zero resale value.',
    ncertReference: 'NCERT Ch 2: Classification of Assets',
    flashcard: {
      definition: 'Expenses and losses not written off during the accounting period in which they are incurred, having no physical existence or realisable market value.',
      example: 'Preliminary expenses incurred during company formation or huge initial advertisement campaign spread over 5 years.',
      goldenRule: 'Assets = Real claim or resource. Fictitious Asset = Unamortized expense carried forward on the asset side.',
      proTip: 'Fictitious assets cannot be converted into cash; they are gradually written off to the Profit & Loss Account.'
    }
  },
  {
    id: 't-2-2',
    chapterId: 2,
    term: 'Trade Discount vs Cash Discount',
    question: 'How is a TRADE DISCOUNT treated in the books of account according to standard accounting rules?',
    options: [
      'Recorded on the Debit side of Cash Book',
      'Deducted directly from the invoice price and NOT recorded separately in books of account',
      'Recorded in the Journal Proper as an expense',
      'Credited to the Trade Discount Account in the Ledger'
    ],
    correctIndex: 1,
    ruleCategory: 'Nominal',
    explanation: 'Trade discount is allowed by wholesale sellers on bulk purchases. It is deducted on the invoice directly, and purchases/sales are recorded at net value. No separate account is opened for Trade Discount.',
    ncertReference: 'NCERT Ch 2: Discounts & Allowances',
    flashcard: {
      definition: 'Trade Discount: Reduction allowed by seller on catalog price for bulk purchases; never recorded in books. Cash Discount: Allowed for prompt payment; recorded as Discount Allowed/Received.',
      example: 'Goods list price $10,000 sold at 10% trade discount. Sales recorded at $9,000 directly.',
      goldenRule: 'Trade discount never touches ledger accounts. Cash discount is a Nominal A/c (Debit expense / Credit income).',
      proTip: 'Remember: "Trade = Invoice markdown only. Cash = Payment incentive recorded in books."'
    }
  },
  {
    id: 't-3-1',
    chapterId: 3,
    term: 'Prudence / Conservatism Principle',
    question: 'The valuation of closing inventory at "Cost or Net Realisable Value (Market Value), whichever is lower" is an application of which concept?',
    options: ['Cost Concept', 'Prudence (Conservatism) Concept', 'Consistency Assumption', 'Money Measurement Concept'],
    correctIndex: 1,
    ruleCategory: 'Real',
    explanation: 'The Prudence/Conservatism concept dictates that all anticipated losses must be provided for, but unrealized profits should not be anticipated.',
    ncertReference: 'NCERT Ch 3: Accounting Principles - Prudence',
    flashcard: {
      definition: 'The convention of prudence requires providing for all prospective losses and liabilities while recognizing gains only when realized.',
      example: 'Creating a Provision for Doubtful Debts or valuing closing stock at lower of cost and net realizable value.',
      goldenRule: '"Anticipate no profits, but provide for all possible losses."',
      proTip: 'Whenever you see "providing for expected future losses" or "lower of cost or market", the answer is almost always Prudence/Conservatism.'
    }
  },
  {
    id: 't-3-2',
    chapterId: 3,
    term: 'Business Entity Concept',
    question: 'Owner’s personal drawings are deducted from Capital in the balance sheet primarily because of which fundamental concept?',
    options: ['Going Concern Concept', 'Business Entity Concept', 'Dual Aspect Concept', 'Accounting Period Concept'],
    correctIndex: 1,
    ruleCategory: 'Personal',
    explanation: 'The Business Entity concept treats the business and its owner as two distinct entities. Capital is a liability owed by the business to the owner, and drawings reduce this liability.',
    ncertReference: 'NCERT Ch 3: Business Entity Assumption',
    flashcard: {
      definition: 'For accounting purposes, the business enterprise is treated as an entity completely separate and distinct from its owner(s).',
      example: 'If owner deposits personal cash into business, it is Capital. If owner withdraws cash for family groceries, it is Drawings.',
      goldenRule: 'Owner = Creditor to the extent of their invested capital.',
      proTip: 'This is why Capital appears on the Liabilities side of the business balance sheet!'
    }
  },
  {
    id: 't-4-1',
    chapterId: 4,
    term: 'Accrual Basis Recognition',
    question: 'Under the Accrual Basis of accounting, when should revenue from sales be recognized?',
    options: [
      'Only when cash is deposited into the bank account',
      'When the sale is made and legal title/risk transfers, whether cash is received or not',
      'At the close of the financial year during audit',
      'When the customer sends a purchase inquiry'
    ],
    correctIndex: 1,
    ruleCategory: 'Nominal',
    explanation: 'Under Accrual Basis, revenue is recognized in the period in which goods are delivered and earned, regardless of when cash is collected.',
    ncertReference: 'NCERT Ch 4: Bases of Accounting',
    flashcard: {
      definition: 'Accrual Basis records revenues when earned and expenses when incurred, matching them to the relevant accounting period.',
      example: 'Services performed in March 2024 are recognized as 2023-2024 income even if payment is received in May 2024.',
      goldenRule: 'Revenue earned + Expenses incurred = True Profit (irrespective of cash timing).',
      proTip: 'Accrual basis is compulsory for companies under the Indian Companies Act 2013.'
    }
  },
  {
    id: 't-5-1',
    chapterId: 5,
    term: 'Accounting Equation Effect',
    question: 'Goods costing $5,000 were sold for $6,500 in cash. What is the net impact on the Accounting Equation (A = L + C)?',
    options: [
      'Assets +$6,500, Capital +$6,500',
      'Assets net increase +$1,500 (Cash +$6,500, Stock -$5,000) and Capital +$1,500 (Profit)',
      'Assets +$1,500 and Liabilities +$1,500',
      'No change in total assets'
    ],
    correctIndex: 1,
    ruleCategory: 'Asset',
    explanation: 'Cash increases by $6,500, Stock decreases by $5,000 (net asset change +$1,500). Profit of $1,500 increases Capital by +$1,500. Equation balances perfectly!',
    ncertReference: 'NCERT Ch 5: Accounting Equation',
    flashcard: {
      definition: 'Accounting Equation: Assets = Liabilities + Capital. Every transaction impacts at least two elements to maintain equality.',
      example: 'Sale of goods at profit increases total assets by profit amount and increases capital by the same profit amount.',
      goldenRule: 'Assets (Dr) = Liabilities (Cr) + Capital (Cr).',
      proTip: 'Always split sale into 3 parts: Cost reduces Stock, Selling price adds to Cash/Debtor, Difference adjusts Capital.'
    }
  },
  {
    id: 't-7-1',
    chapterId: 7,
    term: 'Credit Note vs Debit Note',
    question: 'When a customer returns damaged goods to us, which source document do we prepare and dispatch to them?',
    options: ['Debit Note', 'Credit Note', 'Cash Memo', 'Pay-in Slip'],
    correctIndex: 1,
    ruleCategory: 'Personal',
    explanation: 'We send a Credit Note to the customer informing them that their account has been credited in our books (reducing their debtor balance) for goods returned.',
    ncertReference: 'NCERT Ch 7: Source Documents & Vouchers',
    flashcard: {
      definition: 'Credit Note: Document prepared when goods are returned by customer or when an allowance is given to them, indicating their account is credited.',
      example: 'Customer returning $500 of defective clothing receives a Credit Note.',
      goldenRule: 'Customer is a Debtor (Debit balance). When they return goods, we CREDIT their account -> Send Credit Note.',
      proTip: 'Buyer sends Debit Note to supplier; Seller sends Credit Note to customer.'
    }
  },
  {
    id: 't-10-1',
    chapterId: 10,
    term: 'Petty Cash Imprest System',
    question: 'In a Petty Cash Book maintained on the Imprest System, what does the "Imprest Amount" represent?',
    options: [
      'The total salary of the head accountant',
      'A predetermined fixed float of cash given to the petty cashier to meet small day-to-day payments',
      'The bank overdraft limit',
      'The profit earned from petty sales'
    ],
    correctIndex: 1,
    ruleCategory: 'Real',
    explanation: 'The imprest system provides a fixed sum (float) to the petty cashier. At the end of the period, after verifying vouchers, the chief cashier reimburses the exact amount spent so the float is restored.',
    ncertReference: 'NCERT Ch 10: Cash Book - Imprest System',
    flashcard: {
      definition: 'Imprest System: System where petty cashier is provided an advance (imprest) at start of period and reimbursed exact expenses at end.',
      example: 'Float of $2,000. Petty cashier spends $1,650 on stationery & tea. Head cashier pays $1,650 to restore float to $2,000.',
      goldenRule: 'Petty Cash is an asset account. Float is restored periodically.',
      proTip: 'Key advantage: Prevents fraud, saves time of main cashier, and controls petty overheads.'
    }
  },
  {
    id: 't-11-1',
    chapterId: 11,
    term: 'Subsidiary Books Scope',
    question: 'An enterprise purchased Office Furniture worth $15,000 on credit from Supreme Furniture Ltd. In which book of original entry should this be recorded?',
    options: ['Purchases Book', 'Cash Book', 'Journal Proper', 'Sales Book'],
    correctIndex: 2,
    ruleCategory: 'Real',
    explanation: 'The Purchases Book records ONLY credit purchases of GOODS (inventory meant for resale). Credit purchase of capital assets like furniture must be recorded in the Journal Proper.',
    ncertReference: 'NCERT Ch 11: Subsidiary Books & Journal Proper',
    flashcard: {
      definition: 'Journal Proper: The book of original entry used to record transactions that cannot be entered in any other subsidiary book.',
      example: 'Credit purchase of machinery/furniture, opening entries, closing entries, rectifying entries, bad debts.',
      goldenRule: 'Purchases Book = Goods only. Assets on credit = Journal Proper.',
      proTip: 'Watch out for "furniture", "machinery", or "computer" purchased on credit in exams! It never goes to Purchases Book!'
    }
  },
  {
    id: 't-14-1',
    chapterId: 14,
    term: 'Errors of Principle',
    question: 'Treating the installation wages for newly purchased machinery ($2,500) as revenue wages instead of capitalizing it to Machinery Account is an example of:',
    options: ['Error of Omission', 'Error of Commission', 'Error of Principle', 'Compensating Error'],
    correctIndex: 2,
    ruleCategory: 'Nominal',
    explanation: 'An Error of Principle occurs when an entry violates fundamental accounting principles (such as wrongly classifying capital expenditure as revenue expenditure). Because both sides have equal debits and credits, the Trial Balance still agrees!',
    ncertReference: 'NCERT Ch 14: Classification of Accounting Errors',
    flashcard: {
      definition: 'Error of Principle: Error committed by breaking fundamental principles of accounting, such as misallocating capital vs revenue items.',
      example: 'Debiting Repairs A/c instead of Building A/c for major extension, or debiting Wages instead of Machinery for installation.',
      goldenRule: 'Trial balance still agrees despite Error of Principle because debits equal credits!',
      proTip: 'Classic exam question: "Which error does NOT affect Trial Balance agreement?" Answer: Error of Principle!'
    }
  },
  {
    id: 't-16-1',
    chapterId: 16,
    term: 'Provision vs Reserve',
    question: 'Which of the following statements correctly distinguishes a Provision from a Reserve?',
    options: [
      'A provision is created only when there is excess profit, whereas a reserve is compulsory',
      'A provision is a CHARGE against profit (compulsory even in loss), while a reserve is an APPROPRIATION of profit (created only if profit exists)',
      'Provisions can be freely distributed to shareholders as dividends',
      'Reserves are created for known liabilities of exact amounts'
    ],
    correctIndex: 1,
    ruleCategory: 'Nominal',
    explanation: 'A Provision is a charge against profit to cover a known liability/loss of uncertain amount (e.g. provision for depreciation). A Reserve is an appropriation of divisible profit to strengthen financial resilience.',
    ncertReference: 'NCERT Ch 16: Provisions and Reserves',
    flashcard: {
      definition: 'Provision = Charge against profit (mandatory). Reserve = Appropriation of profit (retained earnings).',
      example: 'Provision for Doubtful Debts is created before calculating net profit; General Reserve is set aside from net profit.',
      goldenRule: 'Provision reduces net profit. Reserve is an allocation of net profit.',
      proTip: 'If business suffers a net loss, provisions MUST still be made; reserves CANNOT be made!'
    }
  }
];

export const JOURNAL_QUESTIONS: JournalQuestion[] = [
  {
    id: 'j-1',
    chapterId: 2,
    transaction: 'Started business introducing cash $50,000 and goods worth $20,000.',
    amount: '$70,000 Total',
    correctDebit: 'Cash A/c ($50,000) & Stock A/c ($20,000)',
    correctCredit: 'Capital A/c ($70,000)',
    correctVoucher: 'Credit Voucher (Cash Receipt Voucher) + Transfer Voucher',
    optionsDebit: [
      'Cash A/c ($50,000) & Stock A/c ($20,000)',
      'Capital A/c ($70,000)',
      'Drawings A/c ($70,000)',
      'Bank A/c ($70,000)'
    ],
    optionsCredit: [
      'Capital A/c ($70,000)',
      'Cash A/c ($50,000) & Stock A/c ($20,000)',
      'Sales A/c ($70,000)',
      'Creditors A/c ($70,000)'
    ],
    optionsVoucher: [
      'Credit Voucher (Cash Receipt Voucher) + Transfer Voucher',
      'Debit Voucher (Payment Voucher)',
      'Sales Invoice',
      'Debit Note'
    ],
    debitRule: 'Real Accounts: Debit what comes into business (Cash & Stock increase).',
    creditRule: 'Personal Account: Credit the giver (Proprietor represented by Capital A/c).',
    explanation: 'Cash and Stock are assets coming into the business (Debit). The owner is providing resources to the business, represented by Capital Account (Credit).',
    ncertReference: 'NCERT Ch 2 & 5: Recording of Capital'
  },
  {
    id: 'j-2',
    chapterId: 7,
    transaction: 'Purchased second-hand machinery for $25,000 from Apex Ltd on credit and paid $2,000 cash for immediate installation.',
    amount: '$27,000 Total',
    correctDebit: 'Machinery A/c ($27,000)',
    correctCredit: 'Apex Ltd ($25,000) & Cash A/c ($2,000)',
    correctVoucher: 'Transfer Voucher (for credit part) & Debit Voucher (for cash part)',
    optionsDebit: [
      'Machinery A/c ($27,000)',
      'Purchases A/c ($25,000) & Wages A/c ($2,000)',
      'Apex Ltd ($25,000) & Installation A/c ($2,000)',
      'Cash A/c ($27,000)'
    ],
    optionsCredit: [
      'Apex Ltd ($25,000) & Cash A/c ($2,000)',
      'Machinery A/c ($27,000)',
      'Capital A/c ($27,000)',
      'Purchases A/c ($27,000)'
    ],
    optionsVoucher: [
      'Transfer Voucher (for credit part) & Debit Voucher (for cash part)',
      'Credit Voucher only',
      'Pay-in Slip',
      'Debit Note'
    ],
    debitRule: 'Capital Expenditure: All expenses incurred to bring an asset into working condition are capitalized to Machinery A/c.',
    creditRule: 'Personal A/c (Apex Ltd) is the giver (Credit). Real A/c (Cash) goes out (Credit).',
    explanation: 'Installation charges on new/second-hand machinery are capital expenditure and must be debited to Machinery A/c, NOT Wages A/c! Credit the supplier for credit portion and Cash for immediate payment.',
    ncertReference: 'NCERT Ch 7 & 18: Capital vs Revenue Expenditure'
  },
  {
    id: 'j-3',
    chapterId: 10,
    transaction: 'Cash deposited into business bank account $12,000.',
    amount: '$12,000',
    correctDebit: 'Bank A/c',
    correctCredit: 'Cash A/c',
    correctVoucher: 'Contra Entry (Pay-in Slip as source document)',
    optionsDebit: ['Bank A/c', 'Cash A/c', 'Capital A/c', 'Drawings A/c'],
    optionsCredit: ['Cash A/c', 'Bank A/c', 'Suspense A/c', 'Sales A/c'],
    optionsVoucher: [
      'Contra Entry (Pay-in Slip as source document)',
      'Credit Voucher only',
      'Debit Note',
      'Journal Proper Transfer Voucher'
    ],
    debitRule: 'Personal/Asset: Bank is the receiver of funds (Debit).',
    creditRule: 'Real Account: Cash goes out of the cash box (Credit).',
    explanation: 'This is a classic CONTRA ENTRY in a double-column cash book. Debit Bank column (money goes in) and Credit Cash column (cash goes out). Marked with "C". The source document is the counterfoil of Pay-in Slip.',
    ncertReference: 'NCERT Ch 10: Cash Book Contra Entries'
  },
  {
    id: 'j-4',
    chapterId: 11,
    transaction: 'Goods worth $4,000 withdrawn by the proprietor for personal household use.',
    amount: '$4,000',
    correctDebit: 'Drawings A/c',
    correctCredit: 'Purchases A/c',
    correctVoucher: 'Transfer Voucher (Journal Proper)',
    optionsDebit: ['Drawings A/c', 'Purchases A/c', 'Sales A/c', 'Household Expense A/c'],
    optionsCredit: ['Purchases A/c', 'Drawings A/c', 'Stock In Hand A/c', 'Capital A/c'],
    optionsVoucher: [
      'Transfer Voucher (Journal Proper)',
      'Debit Voucher (Payment)',
      'Credit Voucher',
      'Cheque Counterfoil'
    ],
    debitRule: 'Personal Account: Proprietor is the receiver of goods for personal benefit (Debit Drawings).',
    creditRule: 'Nominal/Goods Account: Cost of goods available for sale reduces (Credit Purchases A/c at cost).',
    explanation: 'When proprietor withdraws goods for personal use, Drawings A/c is debited and Purchases A/c is credited (at cost price, not selling price). This is recorded in Journal Proper via a Transfer Voucher.',
    ncertReference: 'NCERT Ch 11: Journal Proper Special Entries'
  },
  {
    id: 'j-5',
    chapterId: 10,
    transaction: 'Cash withdrawn from bank $3,500 for office use.',
    amount: '$3,500',
    correctDebit: 'Cash A/c',
    correctCredit: 'Bank A/c',
    correctVoucher: 'Contra Entry (Cheque counterfoil as source document)',
    optionsDebit: ['Cash A/c', 'Bank A/c', 'Drawings A/c', 'Office Expenses A/c'],
    optionsCredit: ['Bank A/c', 'Cash A/c', 'Capital A/c', 'Creditor A/c'],
    optionsVoucher: [
      'Contra Entry (Cheque counterfoil as source document)',
      'Credit Voucher',
      'Invoice',
      'Debit Note'
    ],
    debitRule: 'Real Account: Cash comes into office cash drawer (Debit).',
    creditRule: 'Personal Account: Bank is the giver of funds (Credit).',
    explanation: 'Withdrawing cash for OFFICE use increases Cash in Hand (Dr) and decreases Bank balance (Cr). Contra entry denoted with "C" in Cash Book.',
    ncertReference: 'NCERT Ch 10: Double Column Cash Book'
  },
  {
    id: 'j-6',
    chapterId: 14,
    transaction: 'Purchased goods on credit from Rohan for $8,000, wrongly recorded in Sales Book as $8,000.',
    amount: '$8,000 (Error Rectification)',
    correctDebit: 'Purchases A/c ($8,000) & Sales A/c ($8,000)',
    correctCredit: 'Rohan’s A/c ($16,000)',
    correctVoucher: 'Rectification Entry in Journal Proper (Transfer Voucher)',
    optionsDebit: [
      'Purchases A/c ($8,000) & Sales A/c ($8,000)',
      'Rohan’s A/c ($16,000)',
      'Suspense A/c ($16,000)',
      'Cash A/c ($8,000)'
    ],
    optionsCredit: [
      'Rohan’s A/c ($16,000)',
      'Purchases A/c ($8,000) & Sales A/c ($8,000)',
      'Suspense A/c ($16,000)',
      'Capital A/c ($16,000)'
    ],
    optionsVoucher: [
      'Rectification Entry in Journal Proper (Transfer Voucher)',
      'Debit Voucher',
      'Credit Voucher',
      'Pay-in Slip'
    ],
    debitRule: 'Debit Purchases A/c to record genuine purchase; Debit Sales A/c to cancel wrongful credit.',
    creditRule: 'Credit Rohan with $16,000 ($8,000 to undo wrongful debit + $8,000 to give him proper credit as creditor).',
    explanation: 'A two-sided error of recording in wrong book. Purchases must be debited ($8,000), wrongful Sales credit must be cancelled by debiting Sales ($8,000), and Rohan credited with double ($16,000).',
    ncertReference: 'NCERT Ch 14: Rectification of Two-Sided Errors'
  }
];

export const ADJUSTMENT_QUESTIONS: AdjustmentQuestion[] = [
  {
    id: 'adj-1',
    chapterId: 19,
    title: 'Closing Stock Adjustment',
    scenario: 'Trial Balance shows Purchases $1,20,000 and Sales $1,80,000. Additional Information: Closing Stock on 31st March is valued at Cost $24,000 and Market Value $20,000.',
    question: 'How should Closing Stock be treated in the final accounts and at what value?',
    options: [
      'At Cost ($24,000): Credit Trading A/c & Asset side of Balance Sheet',
      'At Market Value ($20,000): Credit Trading A/c & Asset side of Balance Sheet (Prudence Principle)',
      'At Cost ($24,000): Debit Trading A/c and Liability side of Balance Sheet',
      'At Average ($22,000): In Profit & Loss Account only'
    ],
    correctIndex: 1,
    tradingOrPLImpact: 'Credit Trading Account with $20,000',
    balanceSheetImpact: 'Shown under Current Assets on Balance Sheet with $20,000',
    calculationSnippet: 'Lower of Cost ($24,000) or Net Realisable Value ($20,000) = $20,000',
    explanation: 'According to AS-2 and the Prudence concept, inventory is valued at Cost or Net Realisable Value, whichever is lower. Adjustment appears on Credit side of Trading A/c and Asset side of Balance Sheet.',
    ncertReference: 'NCERT Ch 19: Adjustment 1 - Closing Stock'
  },
  {
    id: 'adj-2',
    chapterId: 19,
    title: 'Outstanding Wages Adjustment',
    scenario: 'Wages paid during the year as per Trial Balance: $18,000. Adjustment: Wages for the month of March amounting to $2,000 are still outstanding.',
    question: 'What is the correct dual presentation for Outstanding Wages in final accounts?',
    options: [
      'Deduct $2,000 from Wages in Trading A/c; show on Asset side of Balance Sheet',
      'Add $2,000 to Wages in Trading A/c ($20,000 total); show $2,000 as Current Liability in Balance Sheet',
      'Debit $2,000 to Profit & Loss A/c; ignore in Balance Sheet',
      'Deduct $2,000 from Capital in Balance Sheet only'
    ],
    correctIndex: 1,
    tradingOrPLImpact: 'Add $2,000 to Wages on Debit side of Trading A/c (Total Wages = $20,000)',
    balanceSheetImpact: 'Shown under Current Liabilities on Liabilities side of Balance Sheet ($2,000)',
    calculationSnippet: '$18,000 (Paid) + $2,000 (Outstanding) = $20,000 total expense for the period',
    explanation: 'Under the Accrual concept, expenses belonging to the current year must be charged against current year revenue whether paid or not. Outstanding wages is a current liability.',
    ncertReference: 'NCERT Ch 19: Adjustment 2 - Outstanding Expenses'
  },
  {
    id: 'adj-3',
    chapterId: 19,
    title: 'Prepaid Insurance Premium',
    scenario: 'Trial Balance shows Insurance Premium paid $6,000. Adjustment: Insurance includes $1,500 paid in advance for the next financial year.',
    question: 'How is Prepaid Insurance treated in the Profit & Loss A/c and Balance Sheet?',
    options: [
      'Deduct $1,500 from Insurance in P&L A/c ($4,500 net); show $1,500 under Current Assets in Balance Sheet',
      'Add $1,500 to Insurance in P&L A/c; show under Current Liabilities in Balance Sheet',
      'Credit $1,500 to Trading A/c; deduct from Capital',
      'Ignore until cash is refunded'
    ],
    correctIndex: 0,
    tradingOrPLImpact: 'Deduct $1,500 from Insurance on Debit side of P&L A/c (Net charge = $4,500)',
    balanceSheetImpact: 'Shown under Current Assets on Balance Sheet ($1,500)',
    calculationSnippet: '$6,000 (Total Paid) - $1,500 (Prepaid/Advance) = $4,500 Current Year Expense',
    explanation: 'Prepaid expense relates to the future accounting period. By the Matching Concept, it must be subtracted from current expenses in P&L and shown as a Current Asset (benefit to be received in future).',
    ncertReference: 'NCERT Ch 19: Adjustment 3 - Prepaid Expenses'
  },
  {
    id: 'adj-4',
    chapterId: 19,
    title: 'Provision for Doubtful Debts Calculation',
    scenario: 'Sundry Debtors in Trial Balance: $52,000. Adjustments: (i) Write off Bad Debts $2,000; (ii) Create a Provision for Doubtful Debts at 5% on remaining debtors.',
    question: 'What is the amount of new Provision to be debited to P&L, and what is the net Sundry Debtors in the Balance Sheet?',
    options: [
      'Provision: $2,600; Net Debtors in Balance Sheet: $47,400',
      'Provision: $2,500; Net Debtors in Balance Sheet: $47,500 ($52,000 - $2,000 - $2,500)',
      'Provision: $2,500; Net Debtors in Balance Sheet: $50,000',
      'Provision: $2,000; Net Debtors in Balance Sheet: $48,000'
    ],
    correctIndex: 1,
    tradingOrPLImpact: 'Debit P&L A/c with Bad Debts $2,000 + New Provision $2,500 = $4,500 total charge',
    balanceSheetImpact: 'Sundry Debtors $52,000 - Further Bad Debts $2,000 - Provision $2,500 = Net $47,500',
    calculationSnippet: 'Debtors after bad debts = $52,000 - $2,000 = $50,000. Provision = 5% of $50,000 = $2,500.',
    explanation: 'Crucial rule: First deduct further bad debts from debtors ($52,000 - $2,000 = $50,000), THEN calculate the 5% provision on good remaining debtors (5% × $50,000 = $2,500). Net debtors shown in Balance Sheet = $47,500.',
    ncertReference: 'NCERT Ch 19: Adjustment 6 - Bad Debts & Provision for Doubtful Debts'
  },
  {
    id: 'adj-5',
    chapterId: 19,
    title: 'Depreciation on Plant & Machinery',
    scenario: 'Plant & Machinery per Trial Balance: $80,000. Adjustment: Charge depreciation at 10% p.a. on written down value.',
    question: 'What are the two accounting treatments for this depreciation?',
    options: [
      'Credit Trading A/c with $8,000 and add to Capital in Balance Sheet',
      'Debit P&L A/c with $8,000 and deduct $8,000 from Plant & Machinery in Balance Sheet Asset side ($72,000 net)',
      'Deduct $8,000 from Sales in Trading A/c and show as liability',
      'Credit P&L A/c with $8,000'
    ],
    correctIndex: 1,
    tradingOrPLImpact: 'Debit P&L A/c under Operating Expenses with $8,000',
    balanceSheetImpact: 'Deduct $8,000 from Plant & Machinery under Fixed Assets (Net Asset = $72,000)',
    calculationSnippet: '10% of $80,000 = $8,000 depreciation expense',
    explanation: 'Depreciation is a non-cash business expense representing loss in value of fixed assets due to wear, tear, and obsolescence. Debited to P&L A/c and subtracted from respective asset in Balance Sheet.',
    ncertReference: 'NCERT Ch 19: Adjustment 5 - Depreciation'
  }
];

export const BOSS_QUESTIONS: BossQuestion[] = [
  {
    id: 'b-1',
    chapterId: 3,
    type: 'concept',
    question: 'Which accounting convention ensures that contingent liabilities are shown as a footnote below the Balance Sheet rather than in the ledger columns?',
    options: ['Full Disclosure Convention', 'Materiality Principle', 'Historical Cost Concept', 'Conservatism Principle'],
    correctIndex: 0,
    timeLimitSec: 15,
    bossDamage: 25,
    explanation: 'The Full Disclosure Convention mandates that all significant financial information and contingent commitments must be disclosed in notes to the financial statements.',
    ncertReference: 'NCERT Ch 3: Convention of Full Disclosure'
  },
  {
    id: 'b-2',
    chapterId: 5,
    type: 'equation',
    question: 'A business has Assets of $1,50,000 and External Liabilities of $60,000. What is the Capital of the firm according to the Accounting Equation?',
    options: ['$2,10,000', '$90,000', '$60,000', '$1,50,000'],
    correctIndex: 1,
    timeLimitSec: 12,
    bossDamage: 25,
    explanation: 'Accounting Equation: Assets = Liabilities + Capital. Therefore, Capital = Assets - Liabilities = $1,50,000 - $60,000 = $90,000.',
    ncertReference: 'NCERT Ch 5: Fundamental Equation'
  },
  {
    id: 'b-3',
    chapterId: 11,
    type: 'journal',
    question: 'Which of the following transactions must be recorded in the SALES BOOK (Sales Day Book)?',
    options: [
      'Cash sale of inventory goods $5,000',
      'Credit sale of trading inventory goods $12,000 to M/s Gupta Bros',
      'Credit sale of old office computer $3,000',
      'Sale of goods for promissory note discounted at bank'
    ],
    correctIndex: 1,
    timeLimitSec: 15,
    bossDamage: 25,
    explanation: 'Sales Book strictly records CREDIT SALES OF GOODS (inventory). Cash sales go to Cash Book; sale of old office equipment on credit goes to Journal Proper!',
    ncertReference: 'NCERT Ch 11: Subsidiary Books - Sales Book'
  },
  {
    id: 'b-4',
    chapterId: 14,
    type: 'concept',
    question: 'Which of the following errors will cause the Trial Balance total to DISAGREE (not tally)?',
    options: [
      'Complete omission of credit purchase from the books',
      'Posting an entry of $5,000 to the Debit of Wages A/c as $500 while properly crediting Cash with $5,000',
      'Purchasing office machinery and debiting Purchases Account (Error of Principle)',
      'Compensating errors of equal debit and credit undercast'
    ],
    correctIndex: 1,
    timeLimitSec: 18,
    bossDamage: 30,
    explanation: 'A one-sided error where different amounts are posted to debit and credit ($500 Dr vs $5,000 Cr) creates a difference of $4,500 that forces the Trial Balance to disagree and requires a Suspense A/c.',
    ncertReference: 'NCERT Ch 14: Errors Disclosed by Trial Balance'
  },
  {
    id: 'b-5',
    chapterId: 16,
    type: 'concept',
    question: 'A Capital Reserve can be created out of which of the following sources?',
    options: [
      'Normal everyday sales of trading goods',
      'Profit on sale of fixed assets or profit on forfeiture of shares',
      'Collection of outstanding debts from customers',
      'Interest received on short-term bank savings account'
    ],
    correctIndex: 1,
    timeLimitSec: 15,
    bossDamage: 25,
    explanation: 'Capital reserves are created out of capital profits (such as profit on sale of fixed assets, premium on shares/debentures, or profit on forfeiture of shares), not normal operating profits.',
    ncertReference: 'NCERT Ch 16: Capital Reserves'
  },
  {
    id: 'b-6',
    chapterId: 18,
    type: 'adjustment',
    question: 'Cost of Goods Sold (COGS) is calculated by which standard accounting formula?',
    options: [
      'Opening Stock + Net Purchases + Direct Expenses - Closing Stock',
      'Net Sales + Gross Profit',
      'Opening Stock + Total Expenses - Net Sales',
      'Purchases + Indirect Expenses - Closing Stock'
    ],
    correctIndex: 0,
    timeLimitSec: 15,
    bossDamage: 25,
    explanation: 'COGS = Opening Stock + Net Purchases + Direct Expenses (wages, carriage inward, freight) - Closing Stock. Alternatively, COGS = Net Sales - Gross Profit.',
    ncertReference: 'NCERT Ch 18: Trading Account Formulas'
  },
  {
    id: 'b-7',
    chapterId: 19,
    type: 'adjustment',
    question: 'If Accrued Interest on Investments ($1,200) appears in the Additional Information (Adjustments), where does it appear in final accounts?',
    options: [
      'Credit P&L A/c and Asset side of Balance Sheet',
      'Debit P&L A/c and Liability side of Balance Sheet',
      'Credit Trading A/c and deduct from Capital',
      'Debit Trading A/c only'
    ],
    correctIndex: 0,
    timeLimitSec: 15,
    bossDamage: 25,
    explanation: 'Accrued interest is income earned but not yet received. It is added to interest income on the Credit side of P&L A/c and shown under Current Assets on the Balance Sheet.',
    ncertReference: 'NCERT Ch 19: Accrued Income Adjustment'
  },
  {
    id: 'b-8',
    chapterId: 4,
    type: 'concept',
    question: 'Under the Indian Companies Act, 2013, which accounting basis is legally compulsory for preparing company accounts?',
    options: ['Cash Basis only', 'Accrual Basis (Mercantile Basis)', 'Hybrid Basis', 'Single Entry System'],
    correctIndex: 1,
    timeLimitSec: 12,
    bossDamage: 25,
    explanation: 'Section 128(1) of the Indian Companies Act, 2013 strictly requires books of accounts to be kept on the Accrual (Mercantile) basis using the double entry system.',
    ncertReference: 'NCERT Ch 4: Statutory Legal Requirements'
  }
];

export const GOLDEN_RULES_SUMMARY = [
  {
    category: 'Personal Accounts',
    rule: 'Debit the Receiver, Credit the Giver',
    appliesTo: 'Persons, Firms, Companies, Debtors, Creditors, Capital, Drawings, Bank.',
    examples: 'Paid to Rahul: Dr Rahul (receiver); Received from Anil: Cr Anil (giver).'
  },
  {
    category: 'Real Accounts',
    rule: 'Debit What Comes In, Credit What Goes Out',
    appliesTo: 'Tangible & Intangible assets: Cash, Land, Building, Machinery, Furniture, Goodwill, Patents.',
    examples: 'Bought Machinery for cash: Dr Machinery (comes in), Cr Cash (goes out).'
  },
  {
    category: 'Nominal Accounts',
    rule: 'Debit All Expenses & Losses, Credit All Incomes & Gains',
    appliesTo: 'Rent, Salaries, Wages, Commission, Discount, Interest, Depreciation, Bad Debts.',
    examples: 'Paid Rent: Dr Rent (expense); Received Interest: Cr Interest (income).'
  },
  {
    category: 'Modern Classification',
    rule: 'CLEAR Rule: Capital, Liabilities, Expenses, Assets, Revenue',
    appliesTo: 'Debit increases Assets & Expenses; Credit increases Liabilities, Capital & Revenue.',
    examples: 'Assets & Expenses: +Dr, -Cr. Liabilities, Capital & Revenues: +Cr, -Dr.'
  }
];
